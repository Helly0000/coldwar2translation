﻿<?php

// EVTS MINEURS 1977

$annee77evt1="扎伊尔：安哥拉游击队进入沙巴省";
$annee77evt1detail="一场新的加丹加-更名为沙巴的战争-刚刚开始";

$annee77evt2="扎伊尔：摩洛哥向沙巴派遣军队";
$annee77evt2detail="一支摩洛哥特遣队帮助该政权";

$annee77evt3="埃塞俄比亚：红色恐怖";
$annee77evt3detail="地方民兵正在猎捕！";

$annee77evt4="莫桑比克内战";
$annee77evt4detail="由南非武装的叛军进入该国";

$flso="西索马里解放阵线";
$oromolf="奥罗莫解放阵线";

$annee77evt4="埃塞俄比亚：吉布提和亚的斯亚贝巴之间的铁路被叛军切断";
$annee77evt4detail="一支游击队团体宣布西索马里独立";

$annee77evt5="埃及与利比亚边境事件";
$annee77evt5detail="无效果：战斗迅速停止";

$annee77evt6="秘鲁：社会动荡加剧";
$annee77evt6detail="稳定度下降（-1）";

$annee77evt7="越柬冲突";
$annee77evt7detail="红色高棉军队进入越南！";

$annee77evt8="暴力骚乱在埃及";
$annee77evt8detail="稳定度剧烈下降（-2）";

$annee77evt9="中东和平：埃及向以色列迈出重要一步";
$annee77evt9detail="埃及稳定度下降（-1），以色列稳定度上升（+1）";

$annee77evt10="捷克斯洛伐克：知识分子批评政权（《七七宪章》）";
$annee77evt10detail="稳定度下降（-1），斯大林主义也是如此！（-1）";

$annee77evt11="埃塞俄比亚和索马里于欧加登交战";
$annee77evt11detail="这只是一条沙带，不是吗？";

$annee77evt12="美国：吉米·卡特总统";
$annee77evt12detail="这就是你在核对决中一直梦寐以求的领袖！";








?>