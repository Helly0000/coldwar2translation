﻿<?php

$achoisi="CHOSE: ";

// Original: $aidedefcon="The lower DEFCON is, the more unstable the situation is and risks degenerating into nuclear conflict.";

$aidedefcon="DEFCON（战备等级）越低，国际局势就越不稳定，爆发核战争的风险就越大.";


$armeeliberation="国家解放军";
$berlinairlift="西柏林空援";
$blocusberlin="西柏林封锁";

$brasdefer="核威慑对决"; 

$ceder="认输";

$cederceder="两次妥协";

$cederdetail="你输掉对决，但是你的分数损失减半.";

$complexemilitaroindustriel="军工复合体";
// Original: $complexemilitaroindustrieldetail="Bonus to military aid actions";

$complexemilitaroindustrieldetail="军事援助效率提升";
$defaite="失败!";

$doctrinetruman="杜鲁门主义";
// Original: $doctrinetrumandetail="Bonus to economic aid actions";

$doctrinetrumandetail="经济援助效率提升";
$israel="以色列";

$palestine="巴勒斯坦";



// Original: $telexbombeA="This country equips itself with A-bomb!";
// Original: $telexbombeH="This country equips itself with H-bomb!";
// Original: $telexmic="This country equips itself with Intercontinental Ballistic Missiles!";
// Original: $telexmictm="This country equips itself with Multiple Independtly Targeted Reentry Vehicles (MIRVs)!";
// Original; $telexsatellite="This country sent a satellite into space!";
// Original: $telexsnle="This country equips itself with Ballistic Missiles Submarines";
// Original: $telexids="Star Wars is now operational!";
// Original: $telexhommeespace="This country sent a man into space!";
// Original: $telexlune="Explorers on the moon!";
// Original: $telexstation="The space station is operational!";

$telexbombeA="这个国家试爆了第一颗原子弹!";
$telexbombeH="这个国家成功研发了氢弹!";
$telexmic="这个国家研制出了洲际导弹!";
$telexmictm="这个国家研制出了分导多弹头导弹(MIRVs)!";
$telexsatellite="这个国家发射了一颗卫星!";
$telexsnle="这个国家拥有了第一艘核导弹潜艇";
$telexids="这个国家拥有了反导系统!";
$telexhommeespace="这个国家成功完成了载人航天!";
$telexlune="探索月球!";
$telexstation="这个国家拥有了空间站!";

$txtprestige="荣誉 ";

// Original: $txtputchreussi=" a coup overthrows the government";
$txtputchreussi=" 一场政变推翻了政府";
$txtputchreussititle="政府更迭与稳定度改变";

$txtaccordeco="经济协定";
$txtaccorddef="防御协定";

$txtannulaccordeco="取消了经济协定 来自 ";
$txtannulaccorddef="取消了防御协定 来自 ";

$txtbase="军事基地";

$txtbravache="外强中干";
// Original: $txtbravachedetail="这个领袖喜欢虚张声势但是会在真正的危险前退缩";

$txtbravachedetail="这位领袖喜欢虚张声势但是会在真正的危险前退缩";
$txtdanssphere="该国在其影响范围内";

$txtfaucon="鹰派";
// Original: $txtfaucondetail="This leader is looking for confrontation and is at ease in power relations";

$txtfaucondetail="这位领袖在冲突中能保持冷静，并渴求对峙";
$txtfermeturebase="军事基地关闭";

$txtbluffeur="暗牌";
// Original: $txtbluffeurdetail="This leader could be a poker champion, definitely an asset in a nuclear showdown";

$txtbluffeurdetail="这位领袖玩桥牌一定很好，以至于他的暗牌令人措手不及";
$txtbombea="原子弹";
$txtbombeh="氢弹";
$txtbombedetail="这个科技在核威胁对峙时提供加成";

$txteuromissiles="欧洲导弹";
// Original: $txteuromissilesdetail="能够造成外科手术打击的导弹已被部署";

$txteuromissilesdetail="能够造成外科手术式打击的导弹已被部署";
$txtcolombe="鸽派";
$txtcolombedetail="这位领袖信奉大国间的建设性谈判，并不擅长对峙";

// Original: $txtdefcon3="Forces of the two great powers are on high alert, the situation could run out of control at any time.";

$txtdefcon3="两个超级大国的部队全面警戒，随时有可能失控";
$txtdefcon2="核战争逼近了";

// Original: $txtdefcon1="The world is at the very brink of abyss, civilitian populations are fleeing major urban centres in hysterical panic.";

$txtdefcon1="世界正处在毁灭的边缘，城市正在疯狂的疏散人口";

// Original: $txtdialoguerdialoguer="Each of the two superpowers made a gesture and reserved talks are being established: there is a modest but nonetheless real hope to end this crisis.";

$txtdialoguerdialoguer="双方达成了部分共识，也许可以结束这场危机";
// Original: $txtdialoguermenacer="A reserved attempt of talks met a flow of threats and an uncomprimising stance from the other side...";

$txtdialoguermenacer="一次试图达成共识的谈话受到了对方的威胁和强硬态度...";
$txtfauconsconfrontation="鹰派鼓励对立";
$txtfauconsconfrontationtitle="这位领袖不会那么迅速地屈服";

$txtnerfacier="钢铁意志";
$txtnerfacierdetail="这位领袖特别不容易屈服";

$txtpasimportant="这个国家不是战略重点";
// Original: $txtpayspasimportanttitle="This great power could concede more easily";

$txtpayspasimportanttitle="这个超级大国可能会更早地屈服";
$txtpaysimportanttitle="这个国家对于超级大国而言至关重要——不会轻易屈服";

$txtids="战略防御计划";

$txtimpotent="病弱";
// Original: $txtimpotentdetail="This leader is no more than a shadow of the man he once was";

$txtimpotentdetail="这位领袖已经衰弱，不再是以前的他了";
$txtimprevisible="不可预测";
$txtimprevisibledetail="你难以预测这位领袖的行动，与他对峙是累人的.";

$txtmenacermenacer="在双方的互相谴责中，局势并没有下降";


$txtmenacermenacer="两个国家保持了强硬的威胁，国际紧张局势正在急剧上升";
$txtmic="洲际导弹";
$txtmictm=" 分导多弹头导弹";

$txtnonuke="无核力量";
// Original: $txtnonukedetail="This power does not have the atomic bomb, which a real impedidement in the current crisis";

$txtnonukedetail="在原子时代，这个无核国家在超级大国前像孩子一样";
$txtpragmatique="实用主义";
// Original: $txtpragmatiquedetail="这位领袖的理性使他更倾向于发挥自己的优势";


$txtpragmatiquedetail="这位领袖的理性使他更倾向于发挥自己的优势";
$txtmissiles="已部署核导弹";

$txtround="Round";

$txtsnle="核导弹潜艇";

$txttroupesgarnison="驻军";
// Original: $txttroupesgarnisontitle="This country has troops on the spot and will yield less easily";

$txttroupesgarnisontitle="这个国家部署驻军，不会轻易屈服";

$victoire="胜利!";


// Original: $gouvernementrenverse="This country fell in turmoil and its government sank!";
$gouvernementrenverse="国家陷入混乱，政府倒台了!";
$gouvernementrenversedetail="新政府";

$menacer="威胁";
$menacerdetail="坚定你的立场，减少DEFCON（战备等级），可能招致核战争.";

$negocier="谈判";
$negocierdetail="减少紧张局势，增加DEFCON（战备等级）但可能被反制.";

$nomrebellesloyalistes="前政府复国军";

$notreinvasionpasacceptee="我们的入侵不能被接受 来自 ";

$nousprotestonsinvasion="我们谴责这次入侵 始作俑者 ";
$nousprotestonscriseiranienne="苏联拒绝撤离伊朗并在该国北部建立社会主义国家.";
$nousprovoquonscriseiranienne="我们拒绝撤离伊朗，这会让我国的南翼易受攻击，但是美国不接受我们的立场.";

$pointsprestige="荣誉点";
$prestige="荣誉";



$recule="妥协";
$recoursnucleaire="危机非常严重，可能已考虑动用核武器!";

$txtannexionmah="伊朗：吞并马哈巴德";
$txtannexionmahdetail="马哈巴德消失";
$txtannexionazi="伊朗：吞并南阿塞拜疆";
$txtannexionmandchou="中国：东北回归";
$txtannexionmandchoudetail="中国：东北回归";

$txtannexionazidetail="南阿塞拜疆消失";

$txtcederceder="两个超级大国决定妥协!<br>
双方达成了显著共识，甚至在最后谈判开始之前<br>
世界松了一口气，但双方的鹰派都被激怒了.";


$txtcontingentcolonial="增援殖民特遣队";

$txtcontreattaque="该国进入反攻!";

$txtdefaite="战争结束，该国战败";

$txtenjeu="筹码";

$txtfrontcalme="前线小规模交火";
$txtfrontcalmetitle="无事发生!";


$txtguerillaaupouvoir=" 推翻政府，夺权!";
$txtguerillaaupouvoirtitle="政府更迭!";
$txtguerillaloyaliste="旧政府军士兵开始逃跑";
$txtguerillaloyalistetitle="新游击队出现";
$txtvictoiresecessionnistes="巩固其自治地位";
$txtvictoiresecessionnistestitle="该自治地区有朝一日将被视为真正的国家";

$txtjaugenerves="当值到达0，你屈服";
$txtjaugenervesadversaire="当他们的值到达0，他们屈服";

$txtnerves="镇定度:";

$txtproclameindependence=" 宣布独立!";
$txtproclameindependencetitle=" 游击队宣布建国";

$accedeindependance=" 独立";
$accedeindependancedetail="这个国家现在独立了";

// Original: $texterevoltenationale="The revolt degenerated into a real liberation fight against the colonial yoke! The metropole send troops in urgency to restore law and order.";

$texterevoltenationale="这次叛乱演变成了一次真正的反抗殖民枷锁的独立战争！城市紧急派遣部队以重建秩序。";
$txtrenforcementarmee=" 军事力量增加";

$txtretraitinvasion="今天入侵部队撤离";

$txtsuccescontreinsurrection="成功的反游击队战争 (人口大规模流失)";

$txtabois="游击队陷入绝望";

$txtattentat="恐怖主义袭击 来自 ";
$txtattentatdetail="一场恐怖袭击震惊了这个国家";
$txtattentatreussi="政府无力反击极端团体(稳定度 -1) / 来自 ";

$txtechecguerilla="政府军阻止了叛军的大规模攻势";


$txtevacuation="紧急撤离部队 因为 ";
$titletxtevacuation="丢失了名誉!";

$txteguerillaaneantie="游击队被全歼!";

$txtguerillarecrute="游击队实力增强";

$txtlutteguerillapietine="对抗游击队的战争毫无进展";

$txtpaixnegociee=" 游击队决定放下武器!";
$txtpaixnegocieetitle="游击队消失，稳定度增加";
$txtpaixnegocieeencours="正在与游击队谈判";

$txtperceeguerilla="叛军打到了首都门口!";
$titletxtperceeguerilla="该国的稳定度崩溃了!";

$txtperceegouvernement="政府军从游击队手中夺回了几个战略要地";
// Original:$titletxtperceegouvernement="This country\'s stability increases, the guerrilla suffers from countless casualties";

$titletxtperceegouvernement="稳定度上升，游击队伤亡惨重";
$txtperteleader="一位叛军首领死亡";


$txtnego="游击队寻求达成双方都同意的谈判协议";


$txtrupturenego="与游击队谈判破裂";

$txtsanglanteguerretranchee="血腥的前线战争";

$txtseveredefaite="前线失守！入侵部队前进.";
$txtseveredefaitetitle="稳定度下降，伤亡惨重";

// Original: $txtstabilisefront="stabilising front: invasion forces are stopped.";
$txtstabilisefront="前线陷入僵局：入侵部队被阻击了.";
$txtstabilisefronttitle="该国稳定度上升";

// Original: $txtsuccesguerilla=" The guerrilla captures ground and governmental troops are retreating";
$txtsuccesguerilla=" 游击队拿下据点，政府军撤退";
$txtsuccesguerillatitle="该国稳定度下降";

// Original: $txtsuccesdefensifguerilla=" governmental troops wear themselves out in vain assaults against the rebel stronghold";
$txtsuccesdefensifguerilla=" 政府军围剿游击队却被反围剿！";
$txtsuccesdefensifguerillatitle="惨!";

$txtsuccesmoyengouvernement=" 游击队节节败退";

$txtvictoire="战争胜利！可以重建国家了";
$txtvictoireecrasante="前线崩溃!敌军进入首都的大门前！";

$txtviolentscombatsentreguerilla=" 叛军中的暴力冲突 ";
$txtviolentscombatsentreguerillatitle=" 两支游击队受到严重损害";

$usarecule="帝国主义胆怯了! <br>美帝国主义不过是纸老虎!";
$usarecule="帝国主义胆怯了! <br>美帝国主义不过是纸老虎!";
$urssrecule="布尔什维克胆怯了!<br> 自由世界的胜利!";
$chinerecule="中国人胆怯了!<br> 现在谁是纸老虎呢?";

/* Original: $victoireiran1="
The Iranian State understands that the Red Army is in the country for a long time and made important concessions.
A petroleum company under Soviet control is under preparation (URSS prestige + 50)
<br>
The Britons, disappointed by the American passivity, withdrew from the country: the future of the Anglo-Iranian Company is no longer guaranteed and this will poison relations between the two allies. The British government is already preparing its counterattack.
<br>Bolstered by the presence of the Red Army, the Tudeh Party of Iran is growing more confident as are the communist ministers, whom the Iranians were forced to give an important position in the government.
(the USSR gains an opposition in Iran and improves its relations with the country)
";
*/

$victoireiran1="
伊朗政府已经对红军在这里的长期驻扎表示理解，作出了重大让步。
一家由苏联控股的石油公司正在筹备之中。 (苏联荣誉 + 50)
<br>
英国人，出于对美国盟友的不作为，感到非常失望——英伊石油公司的计划泡汤了，这将毒害两个盟国之间的关系。英国政府正在谋求反攻
<br>在红军的支持下，伊朗人民党获得了更多的影响力，而伊朗在威逼利诱之下给予他们重要的职位
(苏联提升与伊朗的关系并获得亲苏反对派)
";


$vousreculez="你在核威胁面前退缩了!";

// MAj CHINE

$txtcontreattaquekrs="北朝鲜的部队撤退，南韩的部队发起反击! ";

// MAJ 1953

$txtogre1="<br>为寻求庇护，该国与你的对手靠近了.";
$txtogre2="<br>该国宣布紧急状态并且动员了预备役.";
$txtogre3="<br>紧急法被通过：不同政见者被软禁了.";
$txtogre4="<br>为了面对威胁，政权开始全力扩充军备.";

// MAJ 1953-1955

$pccondamnemao=" 谴责中国分裂国际共运";
$pccondamnemaodetail="与北京关系大幅度恶化";


$terresvierges="处女地运动";

/* Original: $victoirechinedetroits55="
You eventually backed down: the Unites States of America cannot drop  the nuclear bomb on an Asian country once again: the global opinion would never forgive it.<br>
Anyway, without a shade of doubt, the current American stock of nuclear weapons would not have been enough anyway to frighten an adversary which does not seem to care very much for the lives of its people.";
*/

$victoirechinedetroits55="
你最终屈服了：美国不能再在亚洲扔下核武器了.<br>
不管如何，美国目前的核武器已不再能威慑一个人口大国了，不是吗？";

$victoireurss56="美国最终决定与埃及妥协：帝国主义势力紧急的撤离了他们的财产，而埃及人在苏伊士运河庆祝他们的获得的自由.";

$victoireusa56="美国认为不能与埃及妥协，在核保护伞掩护下英法以部队与埃及军队交火";

$criseegypte56="美国宣布支持埃及的帝国主义势力!<br>
殖民时代已经终结了：苏联威胁核武器打击!";

/*Original: $victoireusa56b="苏联应该明白中东是我们的地盘!<br>
我们盟友的介入应该能保证苏伊士运河的中立性.";
*/

$victoireusa56b="苏联应该明白中东是我们的地盘!!<br>
我们盟友的介入应该能保证苏伊士运河的中立性.";
// Original: $victoireurss56b="We backed off faced with the threat: nobody in Washington was willing to go for a nuclear war in order to support an European colonial adventure";

$victoireurss56b="我们屈服于他们的威胁了：华盛顿没人愿意冒着核战风险去支持一场欧洲殖民冒险";
// 1954-1959

$rupturesinosov1=": 谴责苏联修正主义";
$rupturesinosov1detail="与苏联的防御协定破裂，与莫斯科关系恶化";
$pcmao=": 当地共产党选择毛主义路线";
$pcmaodetail=" 亲苏反对派消失";

// Original: $criseberlin1958="The Soviets blocked again the accesses to Berlin and warned Washington that any Western aeroplane attempting to supply the city would be shot down. Washington threathens Moscow with nuclear reprisals if the blockade goes on.";

$criseberlin1958="苏联再一次封锁了西柏林并且宣布了禁飞区，华盛顿威胁如果禁运继续将考虑核打击.";

$victoireurssberlin58="政治局的沉稳让西方人明白了柏林广大人民群众希望一个统一的柏林.<br>
只有一个柏林！欢呼的人群证明了我们事业的公正";

$victoireusaberlin58="我们在这里打桥牌但是对手似乎技高一筹.<br>
下一次，我们会玩象棋的!<br>
柏林依然分裂，而我们的封锁不得不结束。";

$criseturque57="土耳其在美国的默许下要入侵叙利亚.<br>
苏联和埃及宣布如果入侵继续将采取报复打击";

/*Original: $victoireusaturquie57="The USSR yielded faced with the risk of escalation.<br>
The Turkish troops swarm into Syria, decided to put an anticommunist government in charge";
*/

$victoireusaturquie57="害怕局势升温，苏联屈服了.<br>
土耳其部队蜂拥进入叙利亚，希望扶持一个反共的土耳其的傀儡";
$victoireurssturquie57="害怕局势升温，入侵叙利亚的计划被放弃了.";

$nomseparatistes="分离主义团体";

// Original: $txtemulesseparatistes=": 分离主义游击队正在鼓动群众";

$txtemulesseparatistes=": 分离主义暴乱";
$txtemultinationaleseparatistes=" 一个跨国公司与分离主义叛军达成贸易协议";
$txtemultinationaleseparatistesdetail="稳定度下降";

// Original:$txteplaideonureconnaissance="分离主义团体领袖在联合国讲话.";

$txteplaideonureconnaissance="分离主义团体领袖在联合国就民族自决权讲话.";
$txteplaideonureconnaissancedetail="稳定度下降";



// 1959

// Original: $txtdoctrinelemaytitle="The USA believe nuclear war is inevitable and they are ready for it";
$txtdoctrinelemaytitle="美国人认为核战争不可避免，并且已经做好准备";
$txtdoctrinelemay="勒梅主义";

/* Original: $txtcrisecuba1="The American aviation bombed Soviet facilities in Cuba. The Department of State claims it has prevented an imminent nuclear strike against the US territory.<br>
The world in on the brink of World War 3.";
*/

$txtcrisecuba1="美国空军轰炸了古巴的苏联设施，美国国务院宣称已经阻止了对美国本土可能的核威胁.<br>
世界处于第三次世界大战的边缘。";

/*Original: $txtcrisecuba2="The Soviet installed nuclear ballistic missiles in Cuba that directly threatens the US territory.<br>
Washington demands the immediate withdrawal of these ballistic missiles.";
*/

$txtcrisecuba2="苏联在古巴安装了可直接威胁美国本土的核导弹.<br>
华盛顿要求立即撤离这些导弹.";

/* Original: $victoireusacuba62="Cuba was vital for the American interests and a world conflict would have been certain should the USSR have persisted...<br>
No Soviet ballistic missile will ever be deployed in Cuba again as America emerges stronger from this showdown.
";
*/

$victoireusacuba62="古巴对于美国利益至关重要，难以想象如果苏联坚持会发生什么事...<br>
随着美国在这场对决中更具优势，苏联在古巴的核导弹撤出了。
";

/* Original: $victoireursscuba62="The American gesticulations failed to sway Moscow.<br>
The Soviet troops are present at the initiative of a sovereign State, whether the USA like it or not!<br>
The popularity of the US President comes out of this confrontation ruined.<br>
In the USA, the fear of nuclear holocaust gives a serious boost to pacifist movements.";
*/

$victoireursscuba62="美国没能吓倒莫斯科.<br>
不管美国喜欢与否，苏联已经在一个主权国家的要求下驻军了!<br>
美国的声望因这次彻底失败而毁于一旦.<br>
同样，这也增长了美国内部的反战情绪.";

/* Original: $matchnulcuba62="The two superpowers agreed to withdraw their ballistic missiles, respectively from Cuba and Turkey.<br>
Reason prevailed.<br>
";
*/

$matchnulcuba62="两个大国同意分别从古巴和土耳其撤出核弹头.<br>
理性胜出了.<br>
";
//1963

$raidpalestinien="以色列：致命的巴勒斯坦迫击炮袭击";
$raidpalestiniendetail="稳定度下降";
$raidcontrepalestinien=": 以色列空袭巴解组织阵地";
$raidcontrepalestiniendetail="稳定度下降";
// Original: $shoresofsantodomingo="海地：革命党人渗透";
$shoresofsantodomingo="海地：革命起义！";
$shoresofsantodomingodetail=游击队出现在海地";
$VCneverdies="...直到北越重新激活它";

// 1966

// Original: $txtdevoiringerence=": 非政府组织谴责正规军的屠杀";
$txtdevoiringerence=":非政府组织谴责正规军的屠杀";
$txtdevoiringerencedetail="军队的行动受到非政府组织阻扰";

// Original: $txtdevoiringerenceepuration=": the NGOs are denouncing a genocide committed by the regular army (prestige -5)";
$txtdevoiringerenceepuration=": 非政府组织谴责正规军的种族灭绝罪行 (荣誉 -5)";
$txtdevoiringerenceepurationdetail="你应该在选择盟友时三思!";

$txtdevoiringerencearrivee=": 据非政府组织所称，一场人道主义灾难正在逼近.";
// Original: $txtdevoiringerencearriveedetail="The NGOs arrrive in this country";

$txtdevoiringerencearriveedetail="非政府组织抵达该国";
// Original: $txtfindevoiringerence=": the targetted NGOs leave the country";
$txtfindevoiringerence=":非政府组织因安全原因离开这个国家";
$txtfindevoiringerencedetail="屠杀依然会进行";

// Original: $txtfindevoiringerenceespion=": the NGOs ordered to leave the country";
$txtfindevoiringerenceespion=": 非政府组织被命令离开这个国家";
$txtfindevoiringerenceespiondetail="这群境外势力!";

$txtdeploiementonu=" : 部署联合国维和部队";
// Original:$txtdeploiementonudetail="They will interpose to prevent massacres";

$txtdeploiementonudetail="他们会介入以阻止屠杀";
$txtonucible=" :维和部队被锁定为目标!";
$txtonucibledetail="看来军阀们真的很想让他们离开!";

// Original: $raidpalestinien2="Israel: the people brought together facing terrorism";
$raidpalestinien2="以色列：面对恐怖主义，人们团结";
$raidpalestinien2detail="稳定度大幅增加";

$revoltearabiedetail="阿拉伯部落不接受新政权";
$revoltearabie="他们将为自己的权利而战 !";

$abosomalie="奥罗莫解放阵线";

$txtgolan="叙利亚收复戈兰高地";
$txtgolandetail="终于!";

$txtsinai="埃及收复西奈半岛";
$txtsinaidetail="终于!";

// MODE FRANCE

$perteprestigeaccedeindependance="这种独立使你失去荣誉: ";
// Original:$perteprestigeaccedeindependancedetail="They will not get throught without us!";

$perteprestigeaccedeindependancedetail="没有我们的同意，他们是不能独立的!";

//MOD MGS

$sigint="Sigint";
$halo="HALO jump";
$paramedic="Para-Medic";
$osp="OSP";
$xof="XOF";
$activesonar="Active Sonar";
$snakeeater="Snake Eater";
$fakedeathpill="Fake Death Pill";
$shagohod="Shagohod";
$txtfoxevasion="Agent Snake managed to escape! He is debriefing with Major Zero";
$txtfoxevasiontitle="Snake is operational anew";

$txtfoxguerison="Agent Snake is back on his feet!";
$txtfoxguerisontitle="Snake is operational anew";

$snakecapture="Snake has been taken prisoner";
$snakecapturedetail="Snake is unavailable for missions";

$snakeblesse="Snake is injured";
$snakeblessedetail="Snake is unavailable for missions";

$sokolov="Sokolov";
// Original: $sokolovdetail="You have a bonus to develop the Shagohod";
$sokolovdetail="Your Shagohod research is greatly accelerated";

// MODE FRANCE

$perteprestigeaccedeindependance=" 这种独立使我们失去荣誉:: ";
// Original: $perteprestigeaccedeindependancedetail="没有我们，他们活不了的!";

$perteprestigeaccedeindependancedetail="没有我们，他们活不了的!";
//1970

$txteescadronaneantioppositionurss="亲苏反对派消失";
// Original: $txteescadronaneantioppositionursstitle="The socialist opposition, hunted, massively emigrates";
$txteescadronaneantioppositionursstitle="面对死亡或监狱威胁，社会主义反对派大规模逃离了这个国家";

$txteescadronaneantioppositionusa="亲美反对派消失";
// Original: $txteescadronaneantioppositionusatitle="The liberal opposition, hunted, massively emigrates (or is killed)";

$txteescadronaneantioppositionusatitle="面对死亡或监狱威胁，自由主义反对派大规模逃离了这个国家";
$txteescadronaneantioppositionautre="你控制的反对派消失";
// Original:$txteescadronaneantioppositionautretitle="The opposition, hunted, massively emigrates";

$txteescadronaneantioppositionautretitle="面对死亡或监狱威胁，你控制的反对派大规模逃离了这个国家";
/*Original: $txtcriseyomkippour="
The Israeli forces are beating the Arab armies.<br>
Supported by Washington, they want to press their advantage despite the Soviet warnings.
";
*/

$txtcriseyomkippour="
以色列军队已经打垮了阿拉伯人。<br>
在美国的鼓励下，他们不顾苏联的警告希望乘胜追击.
";

/*Original: $yomkippourvictoireus="
Firmly supported by the USA, the Israeli forces continue their methodical obliteration of the Arab armies.<br>
The 3rd Egyptian Army, encircled and cut from supply routes, should be the next one on the list...<br>
Moscow did not put its threat of direct intervention into action, losing part of its prestige in the Arab world.<br>
Anti-Americanism is at its highest in the region.
(The relations of Egypt, Syria, Jordan, Iraq and Lebanon with both the USA and the USSR deteriorate)
";
*/

$yomkippourvictoireus="
在美国的坚定支持下，以色列军队继续有条不紊地消灭阿拉伯军。<br>
埃及第三军，被包围并切断补给，将会是下一个被歼灭的受害者...<br>
莫斯科没有将其威胁付诸行动，使其在阿拉伯国家中失信.<br>
反美情绪在这块地区上升.
(埃及，叙利亚，约旦，伊拉克和黎巴嫩与美苏两国的关系下降)
";
$victoireurssyomkippour="
因水门事件而声名狼藉的总统和反战者的不懈努力迫使美国放弃了中东的计划.<br>
莫斯科在阿拉伯世界中的声望如日中天.
(埃及，叙利亚，约旦，伊拉克和黎巴嫩与苏联关系上升)
";

$txtdiscreditedetail="一桩重大丑闻降低了这位领袖的政治影响力，导致该领袖无法冒险.";
$txtdiscredite="失信";

//1980

$chuteregimeargentin="阿根廷：战败导致政府垮台";

$chuteregimeargentin="阿根廷：战败导致政局动荡";

//MOD MGS Côté Russe

$techinterrogatoire="Advanced interrogation techniques";
$equipmodulaire="Modular equipement";
$formmediccbt="Battlefield medicine training";
$milmi24="Modified Mil-Mi 24";
$krokodil="Krokodil team";
$gidolocator="Gidolokator";
$rationsirp="IRP rations";
$bouclierhumain="Human shield";

$ocelotblesse="Ocelot is injured";
$ocelotblessedetail="Ocelot is currently unavailable for missions";

$txtocelotevasion="Major Ocelot managed to escape! He is debriefing at the GRU's HQ.";
$txtocelotevasiontitle="Ocelot is operational anew";

$txtocelotguerison="Major Ocelot is back on his feet!";
$txtocelotguerisontitle="Ocelot is operational anew";

//1989

$txtcrisehongrie89="华盛顿警告莫斯科不要武装干预匈牙利";
$crisehongrie89victoireurss="美国的故作姿态不能阻止我们拯救我们的友好盟友.<br>
世界将会看到我们不会因这种威胁屈服.<br>
边境被迅速关闭，匈牙利社工党被清洗重组以剔除不稳定因素.
";
$crisehongrie89victoireurss="美国的故作姿态不能阻止我们拯救我们的盟友.<br>
世界将会看到我们不会因这种威胁而屈服.<br>
边境被迅速关闭，匈牙利社工党被清洗重组以剔除不稳定因素.
";

/*Original:$crisehongrie89victoireusa="Refugees from the East are flocking into the West where they are welcomed with flowers and signs in Hungarian and Czech. Donations are flooding in, in a clear euphoria.<br>
This little breach in the Iron Curtain could very well end up in a true tsunami...<br>
The Politburo took the American warnings seriously and the Red Army did eventually not intervene.<br>
<span style=\"font-style:italic;\">
==> Stalinism: -5 <br>
==> Stability of Austria, Czechoslovakia and Hungary -1<br>
</span><br>
";
*/

$crisehongrie89victoireusa="来自东方的难民如潮水般疯狂涌入西方，他们收到鲜花与捷匈语标语的欢迎.<br>
铁幕上的这个小裂口可能会导致真正的海啸…<br>
在美国的严厉警告下，政治局决定不武力干涉.<br>
<span style=\"font-style:italic;\">
==> 斯大林主义: -5 <br>
==> 奥地利，捷克和匈牙利的稳定度： -1<br>
</span><br>
";
?>