﻿<?php

$annee61evt1="美国：反歧视自由乘车运动（Freedom Rides）";
$annee61evt1detail="民权抗议增长";

$annee61evt2="埃塞俄比亚：厄立特里亚抵抗运动";
$annee61evt2detail="一支游击队出现";

$annee61evt3="伊拉克：库尔德起义";
$annee61evt3detail="一支游击队出现";

$annee61evt4="解散阿拉伯联合共和国";
$annee61evt4detail="阿拉伯联合共和国的终结";


$annee61evt5="安哥拉：独立战争";
$annee61evt5detail="三支游击队出现";

$annee61evt6="安哥拉：葡萄牙殖民军的镇压与屠杀";
$annee61evt6detail="稳定度上升和殖民地军队增加，游击队获得民众支持特质";

$annee61evt7="北罗得西亚：大规模公民抗命运动";
$annee61evt7detail="稳定度下降";

$annee61evt8="阿尔及利亚：秘密军组织出现";
$annee61evt8detail="一支新的游击队出现";

$annee61evt9="印度：印度军队收回葡萄牙在印度的殖民地";
$annee61evt9detail="印度稳定度大幅上升，葡萄牙稳定度下降";

$kennedy="约翰·肯尼迪";


$annee61evt10="美国：约翰·菲茨杰拉德·肯尼迪当选";
$annee61evt10detail="他有一头非常漂亮的发型";

?>