﻿<?php

$annee57evt1=": 美国认为该国对他们的利益至关重要";
$annee57evt1detail="该国进入美国势力范围";

$annee57evt2="美国：艾森豪威尔诠释其中东政策";
$annee57evt2detail="一些国家进入美国势力范围";

$annee57evt3="阿尔及利亚：阿尔及尔之战";
$annee57evt3detail="游击队损失力量，但获得民众支持特质";

$annee57evt4="联邦德国：抗议人才外流至美国";
$annee57evt4detail="结束回形针行动";

$annee57evt5="美国：结束回形针行动";
$annee57evt5detail="结束回形针行动";

$annee57evt6="哥伦比亚：政治转型";
$annee57evt6detail="该国转变为代议共和政体";

$annee57evt7="古巴：马埃斯特腊山宣言";
$annee57evt7detail="这支鲜为人知的游击队消去小型游击队特质，获得偏远游击队和民众支持特质";

$annee57evt8="海地：固定选举";
$annee57evt8detail="该国转变或保持独裁政体";

$annee57evt9="阿尔及利亚：法国特勤局的“蓝色阴谋”";
$annee57evt9detail="民族解放阵线获得内部分歧特质";

$annee57evt10="西撒哈拉：伊夫尼战争";
$annee57evt10detail="摩洛哥解放军反对西班牙殖民者";

$annee57evt11="中国：百花齐放运动";
$annee57evt11detail="稳定度下降";

$annee57evt12="中国：反右运动";
$annee57evt12detail="稳定度显著上升";

$annee57evt13="柬埔寨：宣布该国中立";
$annee57evt13detail="柬埔寨变为中立国";


$annee57evt14="约旦：政局不稳";
$annee57evt14detail="稳定度急剧上升，共产主义反对派出现";

$annee57evt15="印度尼西亚：全民斗争宪章成立";
$annee57evt15detail="一支新的游击队！";

// evts mineurs France 1957

$annee57evt16="法国：新政府终于来了！";
$annee57evt16detail="一切皆变，一切如故：政变风险增加10%";

$annee57evt17="法国：政局不稳：政府在跳华尔兹舞！（声望-5）";
$annee57evt17detail="政变风险增加20%";

$annee57evt18="法国：费利克斯·加亚尔组建新政府";
$annee57evt18detail="这一个看起来像个严肃高效的小伙子：重建进度+1%，政变风险增加10%";


?>