﻿<?php


$titreuchronie45a="千年帝国（替代历史）";
$texteuchronie45a="
谁能料想到德国的科学家在研发核武器方面会取得如此迅速的成就？
<br>
当第一颗原子弹在伦敦投下时，整个世界都在恐惧中颤抖。<br>
当第二颗原子弹在波兰的苏军总部爆炸时，很明显战争的趋势已经逆转了……<br>
美军可以用自己的核项目进行反击，但这将以其英国盟友的毁灭为代价。<br>
于是，一份与第三帝国的停火协议勉强签署了：盟军如此接近！<br>

";

$titreuchronie45a1="千年帝国（替代历史）";
$texteuchronie45a1="
<span style =\"font-style:italic;\">
--> 纳粹德国仍然存在
--> 纳粹德国拥有核武器
</span>

";

$choix1uchronie45a="他们会得到他们应得的……";
$choix1uchronie45atitle="帝国仍然屹立……并且它拥有核武器！";

$troisiemreich="第三帝国";

// UCHRONIE JAPON IMPERIAL

$titreuchronie45b="没落行动（替代历史）";
$texteuchronie45b="
在长久的犹豫后，美国总统最终拒绝使用原子弹：这种武器实在太可怕了。<br>
抗日战争还在继续，但这是一场漫长而不确定的战役。
总参谋部担忧登陆日本列岛的尝试，但这是粉碎这个帝国的必经之路！<br>
“没落行动”（入侵日本）准备在年底前开始。

";

$choix1uchronie45b="战争将持续很久";
$choix1uchronie45btitle="日本还没有投降";

$titreuchronie45b1="没落行动（替代历史）";
$texteuchronie45b1="
<span style =\"font-style:italic;\">
--> 对抗日本帝国的战争仍在进行中
</span>

";

// UCHRONIE PAS D'URSS EN MANDCHOURIE

$titreuchronie45c="互不侵犯条约（替代历史）";
$texteuchronie45c="
与他们对盟国的承诺相反，苏联从未对日本宣战，因此遵守了两国在1941年签署的互不侵犯条约。<br>


";

$choix1uchronie45c="我们必须遵守签署的条约";
$choix1uchronie45ctitle="苏联没有进入中国东北";

$titreuchronie45c1="互不侵犯条约（替代历史）";
$texteuchronie45c1="
<span style =\"font-style:italic;\">
--> 苏联在中国东北与北朝鲜没有军事存在
</span>
";


// MAQUIS COMMUNISTE EN FRANCE

$titreuchronie45d="法共游击队没有放下武器（替代历史）";
$texteuchronie45d="
共产党游击队从未放下武器，拒绝参与民主生活……<br>
他们在他们控制的城镇和村庄建立苏维埃，并拒绝与法兰西第四共和国临时政府的代表接触。<br>
美国军队还没有介入：法国的事务似乎非常复杂，正在进行敏感的谈判以解决目前的局势。


";

$choix1uchronie45d="为什么他们拒绝玩民主游戏？";
$choix1uchronie45dtitle="是啊，为什么呢？";


$titreuchronie45d1="法共游击队没有放下武器（替代历史）";
$texteuchronie45d1="
<span style =\"font-style:italic;\">
--> 法国的初始稳定度较低<br>
--> 在法国有一支共产党游击队
</span>
";

// GUERRE CIVILE EN GRECE

$titreuchronie45e="在希腊的战争（替代历史）";
$texteuchronie45e="
希腊共产党游击队夺取政权，宣布希腊人民共和国成立。<br>
英军已经进行了8个月的大规模军事行动以驱逐共产主义者，但却一无所得。<br>
希共军队大部分武装缴获自德国的装备（其提供者的身份是个谜……）并拥有包括坦克在内的重武器，。<br>
美英之间的关系处于最低点；英国人尤为愤愤不平地指责美国让他们在希腊半岛的反共斗争中孤军奋战。<br>
艾德礼政府正试图摆脱这场由其前任温斯顿·丘吉尔挑起的不受欢迎的冲突（这实际上是他的竞选承诺之一）。<br> 


";

$choix1uchronie45e="这场战争令人沮丧";
$choix1uchronie45etitle="这场战斗已经输了吗？";

$royalistes="保王党";

$titreuchronie45e1="在希腊的战争（替代历史）";
$texteuchronie45e1="
<span style =\"font-style:italic;\">
--> 希腊是人民民主制<br>
--> 在希腊有一支保王党游击队<br>
--> 希腊和联合王国处于战争状态<br>
</span>


";

// GUERRE CIVILE EN YOUGOSLAVIE

$titreuchronie45f="在南斯拉夫的战争（替代历史）";
$texteuchronie45f="
英国支持切特尼克运动反对铁托的游击队，并在战争结束后，扶植彼得二世重登南斯拉夫王位。<br>
共产党人决不接受国王的回归，南斯拉夫岌岌可危的平衡很快就被粉碎了。
";

$choix1uchronie45f="局势令人担忧……";
$choix1uchronie45ftitle="这场战斗已经输了吗？";



$partisansyougoslaves="南斯拉夫人民解放军";

$titreuchronie45f1="在南斯拉夫的战争（替代历史）";
$texteuchronie45f1="
<span style =\"font-style:italic;\">
--> 南斯拉夫是君主制<br>
--> 在南斯拉夫有一支非常活跃的共产党游击队<br>
--> 英军在与该国共同作战<br>
--> 南斯拉夫的初始稳定度较低
</span>
";

// ROOSEVELT PRESIDENT

$titreuchronie45g="神采奕奕的总统（替代历史）";
$texteuchronie45g="
关于美国总统中风后健康状况的谣言在他病愈后已经不攻自破！<br>
诚然罗斯福总统仍在康复状态中，但他觉得自己已经有能力继续领导国家，他的奉献精神着实令人钦佩。<br>

";

$roosevelt="富兰克林·罗斯福";

$titreuchronie45g1="神采奕奕的总统（替代历史）";
$texteuchronie45g1="
<span style =\"font-style:italic;\">
--> 罗斯福总统仍然在任<br>
--> 他在核对决中的特质不如哈里·杜鲁门的好。

</span>

";

$choix1uchronie45g="总统万岁！";
$choix1uchronie45gtitle="他看起来还有点虚弱，不是吗？";

// INDE NON PARTITIONNEE

$titreuchronie49h="印度统一受威胁（替代历史）";
$texteuchronie49h="
当印度获得独立时，甘地所倡导的印度次大陆的统一还远远没有得到保障。<br>
幸运的是，理性占了上风，这个国家成功地实现了其独立后的统一，而不是被分治为两个印度教和穆斯林实体。<br>
而今，各族之间不稳定的平衡被打破了，一场真正的游击战争正在震动该国的北部地区。<br>
";

$choix1uchronie49h="一场肮脏的内战";
$choix1uchronie49htitle="一支强大的游击队出现在印度北部";

$titreuchronie49h1="印度统一受威胁（替代历史）";
$texteuchronie49h1="
--> 印度的初始稳定度非常低<br>
--> 在印度存在一支分离主义游击队，可以导向巴基斯坦的独立
";


// DEWEY PRESIDENT

$titreuchronie49i="托马斯·杜威是总统（替代历史）";
$texteuchronie49i="
自从托马斯·杜威在1948年选举中战胜杜鲁门总统以来，美利坚合众国一直由他统治。<br>
他接管了一个正在向和平经济转型但已经深陷冷战的国家。<br>
事实证明，他的住所政策不受欢迎，而他的人望直线下降。<br>
据一些和他关系密切的人的说法，他甚至设想不谋求连任第二任期！
<br>
尽管如此，他希望通过在国际关系中的坚定和战斗态度，在历史上留下自己的印记。
";

$choix1uchronie49i="我们已经过了中期";
$choix1uchronie49ititle="杜威是总统";

$dewey="托马斯·杜威";

$titreuchronie49i1="托马斯·杜威是总统（替代历史）";
$texteuchronie49i1="
--> 美国总统是托马斯·杜威（而不是哈里·杜鲁门）
";


// GUERRE CIVILE CHINOISE EN COURS

$titreuchronie49j="中国内战还没结束！（替代历史）";
$texteuchronie49j="
中华人民共和国宣告成立，但外国观察家认为此举有点为时过早。<br>
国民革命军仍然控制着南方的大片领土，并得到美国的长期可靠支持。<br>
在国民党控制的海港上岸的物资流源源不断，一场大型反攻正在预备！
";

$choix1uchronie49j="中央王国反击！";
$choix1uchronie49jtitle="这场内战的趋势还能逆转吗？";

$titreuchronie49j1="中国内战还没结束！（替代历史）";
$texteuchronie49j1="
--> 在中国有一支非常庞大的反共游击队
";

// FÉDÉRATION BALKANIQUE

$titreuchronie49k="巴尔干联邦（替代历史）";
$texteuchronie49k="
自希腊共产党夺权以来，铁托得以把他建立巴尔干联邦的梦想化为现实。<br>
与莫斯科的关系非常紧张，而巴尔干共产主义激励了世界越来越多的反殖民运动。<br>
保加利亚和罗马尼亚，尽管感觉受到铁托主义的吸引，但仍然留在苏联的东欧阵营中。
";

$choix1uchronie49k="铁托主义：共产主义的一种新模式";
$choix1uchronie49ktitle="斯大林是震怒的！";

$titreuchronie49k1="巴尔干联邦（替代历史）";
$texteuchronie49k1="
--> 希腊、阿尔巴尼亚和南斯拉夫是中立或不结盟国家，与莫斯科和华盛顿的关系非常低<br>
--> 希腊是人民民主制<br>
--> 南斯拉夫和阿尔巴尼亚不在苏联的势力范围内
";


// LES BASES SOVIETIQUES DU BOSPHORE

$titreuchronie49l="苏维埃在博斯普鲁斯（替代历史）";
$texteuchronie49l="
苏联对土耳其的持续施压最终得到了回报，苏联在博斯普鲁斯海峡建立了海军基地。<br>
这个基地使苏联海军得以安全出入地中海。<br>
红海军还未给人留下深刻印象，但这个海军基地已经深刻地改变了地区地缘政治。

";

$choix1uchronie49l="我们在同一条船上吗？";
$choix1uchronie49ltitle="苏联在博斯普鲁斯海峡有一个海军基地";

$titreuchronie49l1="苏维埃在博斯普鲁斯（替代历史）";
$texteuchronie49l1="
--> 土耳其是中立国<br>
--> 苏联在土耳其设有军事基地

";

// BERLIN A BOUT DE SOUFFLE

$titreuchronie49m="奄奄一息的柏林（替代历史）";
$texteuchronie49m="
自1948年6月以来，柏林一直处于红军的封锁之下，并由强大的空运物资补给。<br>
这座城市已经奄奄一息，它的居民营养不良，而且缺乏煤炭来迎接即将到来的冬天……<br>
莫斯科和华盛顿之间谁会首先屈服，结束柏林人民的痛苦？

";

$choix1uchronie49m="柏林，苦难之城";
$choix1uchronie49mtitle="这场危机已经持续一年了！";


$titreuchronie49m1="奄奄一息的柏林（替代历史）";
$texteuchronie49m1="
--> 苏联与联邦德国的关系是濒临战争<br>
--> 柏林封锁仍在进行中

";

// 1958

// UNE CORÉE

$titreuchronie49n="朝鲜半岛重归统一（替代历史）";
$texteuchronie49n="
北朝鲜赢得了朝鲜战争。<br>
美国国务院为避免与苏联和中国直接对决所做的努力，让美国的地区盟友感到担忧。<br>
一个大亚太联盟的创立是应对共产主义威胁的答案。
";

$choix1uchronie49n="紧张局势处于最高点！";
$choix1uchronie49ntitle="全世界都疯了吗？";

$titreuchronie49n1="朝鲜半岛重归统一（替代历史）";
$texteuchronie49n1="
--> 只有一个朝鲜，而它是社会主义的<br>
--> 美国在日本、印度尼西亚和台湾设有军事基地<br>
--> 美国在这些国家有额外驻军<br>
--> 美国与日本、印度尼西亚、台湾、澳大利亚和新西兰签订了防御协议<br>
--> 战备等级（DEFCON）设定为1
";


// LE ROYAUME HACHEMITE

$titreuchronie49o="哈希姆王国（替代历史）";
$texteuchronie49o="
伊拉克和约旦的王冠联合起来，使这两个王国成为一体！<br>
尽管如此，新王国仍然受到许多内部敌人的威胁：共产主义者、复兴主义者、库尔德活动家、泛阿拉伯支持者和穆斯林兄弟会。<br>
一场政变刚刚失败，王室试图重新控制国家。<br>
联合王国甚至派遣了一支特遣队帮助稳定国家，这一行动使人民更加不满。<br>
在一些观察家看来，哈希姆王朝的日子已经屈指可数。
";

$choix1uchronie49o="这个国家处于混乱的边缘";
$choix1uchronie49otitle="通过巧妙地进行派系制衡，这个君主国应该能够长久统治下来";

$titreuchronie49o1="哈希姆王国（替代历史）";
$texteuchronie49o1="
--> 约旦和伊拉克是一个统一的国家<br>
--> 伊拉克的稳定度非常低<br>
--> 联合王国在该国部署5驻军<br>
--> 该国有一个共产主义反对派<br>
--> 该国有一个复兴党游击队<br>
";

// PERMESTA

$titreuchronie49p="四分五裂的印度尼西亚（替代历史）";
$texteuchronie49p="
在印度尼西亚的东西部地区，分离主义运动正在削弱中央政府的力量。<br>
其中一个武装运动，全民斗争宪章（Permesta），得到了美国的大力支持，在战斗中节节胜利，逐渐转变为一支旨在推翻印尼政府的正规军。<br>
全民斗争宪章不仅拥有重型武器，而且拥有一支不容小觑的空军力量。<br>

";

$choix1uchronie49p="这个国家处于混乱的边缘";
$choix1uchronie49ptitle="中央政府会崩溃吗？";

$titreuchronie49p1="四分五裂的印度尼西亚（替代历史）";
$texteuchronie49p1="
--> 全民斗争宪章游击队具有重武器和反共的特质<br>
--> 全民斗争宪章游击队受美国渗透<br>
--> 印度尼西亚的武装力量设定为20<br>

";

// BUDAPEST 56

$titreuchronie49q="布达佩斯的另一种走向（替代历史）";
$texteuchronie49q="
1956年，作为对民众骚乱的回应，纳吉政府站在示威者一边，宣布结束一党制和组织选举。<br>
自这项决定以来，他一直在实施自愿经济改革。<br>
他甚至要求红军撤出匈牙利领土，而政治局接受了这一要求。<br>
东欧各国屏吸静气，仔细观察这场“匈牙利革命”……<br>
改革的结果似乎证明莫斯科是正确的：恶性通货膨胀和高失业率重返匈牙利。

";

$choix1uchronie49q="这个国家处于混乱的边缘";
$choix1uchronie49qtitle="政府会崩溃吗？";

$titreuchronie49q1="布达佩斯的另一种走向（替代历史）";
$texteuchronie49q1="
--> 斯大林主义设定为-10（东欧处于内爆的边缘）<br>
--> 匈牙利的稳定度很低，并实行市场经济<br>
--> 苏联不再在匈牙利驻军<br>

";

// EVT R

//==> 1970

$titreuchronie49r="在太空肩并肩（替代历史）";
$texteuchronie49r="
登月竞赛正在如火如荼地进行！ <br>
肯尼迪和勃列日涅夫向各自的人民承诺抢先登上月球，两国的计划已经接近成功。 <br>
不会有两个第一次登上月球的人，自从苏联宣布在今年年底前进行首次试飞和登月以来，原本认为苏联的计划进展不会如此迅速的美国队正在更加努力地赢得这场竞赛。 <br>
<br>


";

$choix1uchronie49r="谁将赢得登月竞赛？";
$choix1uchronie49rtitle="苏联和美国在登月竞赛中旗鼓相当";

$titreuchronie49r1="在太空肩并肩（替代历史）";
$texteuchronie49r1="
==> 美国登月研究进展：90%<br>
==> 苏联登月研究进展：90%<br>
<br>
";

// KOSSYGUINE

$titreuchronie49s="阿列克谢·柯西金（替代历史）";
$texteuchronie49s="
新任苏共总书记有改革苏联经济的意愿，并受到经济学家叶甫西·利别尔曼的启发。
如果他的计划成功付诸实施，经济将转向轻工业和消费品生产。<br>
他的一些计划应该给予苏联企业一些管理自主权，这已经让党内最保守的派系感到担忧。
<br>


";

$choix1uchronie49s="这是苏联的改革吗？";
$choix1uchronie49stitle="斯大林主义指数非常低";

$titreuchronie49s1="阿列克谢·柯西金（替代历史）";
$texteuchronie49s1="
==> 阿列克谢·柯西金是苏联领导人<br>
==> 战备等级（DEFCON）+2<br>
==> 斯大林主义-4<br>
<br>
";
$kossyguine="阿列克谢·柯西金";

// LE PRINTEMPS DE PRAGUE

$titreuchronie49t="濒临混乱的布拉格（替代历史）";


$texteuchronie49t="
在布拉格，杜布切克重新引入了新闻自由以及言论和示威自由。<br>
其经济政策是建设“具有人道面孔的社会主义”，旨在改革社会主义。 <br>
这些政治事态发展在整个东欧受到高度关注。<br>
边境甚至向西开放，几个月内该国失去了相当一部分优秀知识分子。 <br>
但人民现在要求更多了，他们想要自由和多党选举！ <br>
捷克斯洛伐克政府现在正在放慢改革，但要减缓这一进程可能为时已晚。 <br>
自布达佩斯以来的时代已经改变，由华沙公约介入解决捷克斯洛伐克国内政策的问题是不可能的。
";

$choix1uchronie49t="具有人道面孔的社会主义？";
$choix1uchronie49ttitle="斯大林主义指数现在真的很低";

$titreuchronie49t1="濒临混乱的布拉格（替代历史）";


$texteuchronie49t1="
==> 捷克斯洛伐克的稳定度是非常虚弱 <br>
==> 与美国的关系为好 <br>
==> 在捷克斯洛伐克有一个西方反对派 <br>
==> 斯大林主义指数： -6 <br>

";






// EVT U

$titreuchronie49u="两个希腊（替代历史）";


$texteuchronie49u="
随着希腊共产党夺取政权，国王乔治二世在英军庇护下流亡到克里特岛。 <br>
皇家海军和仍然忠实于君主制的希腊海军，保护着这个王国的残余，包括克里特岛和地中海的一些岛屿。 <br>
反攻希腊大陆似乎遥不可及：这种将希腊分成两个实体的局面预计将持续很长一段时间。 <br>
受到这些事件的打击，乔治二世悲惨地死去了。<br>
希腊的新国王保罗一世大半辈子都在流亡中度过，世界各地的政要都在推测，他是否有在逆境中领导这个流亡王国的必要意志。
<br> 
<br>
<hr> 
<br>
<span style=\"font-style:italic;text-align:right;\">
这一替代历史事件是由Lars您提议的
</span>
";

$choix1uchronie49u="希腊将永远战胜！";
$choix1uchronie49utitle="对，但是哪个希腊？";

$titreuchronie49u1="两个希腊（替代历史）";


$texteuchronie49u1="
==> 克里特是一个独立的君主制政权<br>
==> 希腊是人民民主制<br>
<br> 
";

// EVT V

$titreuchronie49v="埃及的最后一位苏丹（替代历史）";


$texteuchronie49v="
在脱离了1952年的政变后，埃及苏丹法鲁克继续执掌这个漂泊不定的埃及政权。<br>
这位君主奢华的生活方式被埃及民众视为一种侮辱，以色列战败的打击、英军对该国的占领，以及埃及政权普遍存在的腐败，这些合在一起，彻底摧毁了政府的公信力。 <br>
每周都会发生一些针对政府官员或普通公民的致命袭击。 <br>
<br>
";

$choix1uchronie49v="埃及处在深渊的边缘";
$choix1uchronie49vtitle="这就是终结";

$titreuchronie49v1="埃及的最后一位苏丹（替代历史）";


$texteuchronie49v1="

==> 埃及是一个腐败国家，其稳定度非常虚弱 <br>
==> 在埃及的英国驻军额外+5 <br>
==> 极端组织在大街上撕裂
<br> 
";
$pcegypte="共产主义活动家";
$orgaspecialefreres="特殊组织";
$offnatsegypte="民族主义军官团";

//EVT W

$titreuchronie49w="胡志明小道地狱（替代历史）";

$texteuchronie49w="
为了终止越共的补给和渗透，约翰逊政府决定使用核武器“摧毁胡志明小道”！ <br>
声名狼藉的轻型核弹头“戴维·克罗克特”是这一大胆战略的工具。 <br>
结果充其量是令人失望的，越共的坚毅战士们一直在丛林中不断开拓新的通道。 <br>
每周使用的核弹头数量迅速超过10枚，直到新弹头的生产供不应求。 <br>
在越共于春节攻势中将俘获的一枚核弹头用于对付美军后，该计划被永久废止。 <br>
由于越南战争似乎依然看不到尽头，美国各地的和平主义抗议活动日复一日的增多。
<br>
<hr> 
<br>
<span style=\"font-style:italic;text-align:right;\">
这一替代历史事件是由Snake您提议的
</span>
";

$choix1uchronie49w="整个世界憎恶美国";
$choix1uchronie49wtitle="美国人自己也是如此";

$titreuchronie49w1="胡志明小道地狱（替代历史）";

$texteuchronie49w1="
==> 美国与老挝、柬埔寨和日本的关系是非常坏。 <br>
==> 越共战力降低（-50%） <br>
==> 美国的和平主义示威更为强烈（+15） <br>
==> 国际紧张局势提升（DEFCON-2）
<br> 

";

// EVT X

$titreuchronie49x="巴伐利亚堡垒（替代历史）";

$texteuchronie49x="
巴伐利亚的阿尔卑斯山已被改造成了堡垒要塞，最后的纳粹分子在此负隅顽抗，誓死不降。 <br>
美军在党卫军的激烈抵抗面前受挫，这些狂热的党卫军决心为他们的元首而死。 <br>
（显然这场战争已经打赢了，谁也不想死） <br>
似乎没有人知道阿道夫·希特勒身处何方，或者他是死是活：也许他就在这个著名的巴伐利亚堡垒里？ <br>

<br>
<hr> 
<br>
<span style=\"font-style:italic;text-align:right;\">
这一替代历史事件是由more red than my blood您提议的
</span>
";

$choix1uchronie49x="他们的斗争是无望的";
$choix1uchronie49xtitle="而在此期间阿道夫悄悄地逃到了阿根廷？";

$titreuchronie49x1="巴伐利亚堡垒（替代历史）";

$texteuchronie49x1="
==> 在德国有一场残酷的纳粹游击战争 <br>
（这场游击战被认为是非本土的，因为没有人再支持纳粹了。）
<br> 
";

// EVT Y

$titreuchronie49y="保皇委员会（替代历史）";

$texteuchronie49y="
在埃塞俄比亚，尼格斯政权仍前途未卜。<br>
饥荒和社会纠纷引起的问题导致了声势浩大的总罢工。<br>
甚至军队看起来也并不可靠，叛乱者数不胜数。<br>
政权决定依靠武装军队、警察和属地军队协调委员会（Derg）以恢复法律和秩序。<br>
军队各级领导内的大清洗使军队内部的混乱得以结束。<br>
镇压是血腥的，但这个国家似乎已经平静下来。<br>
马列主义运动依然强大，但在委员会（Derg）支持下的军队组织追捕下，它必须潜入地下。
尼格斯开始着手改革他的国家：饥荒被正式承认，土地改革也已宣布。<br>
";

$choix1uchronie49y="亚的斯阿贝巴老独裁者的幸运星已黯然失色";
$choix1uchronie49ytitle="该国局势仍不明朗";

$titreuchronie49y1="保皇委员会（替代历史）";

$texteuchronie49y1="
==> 埃塞俄比亚的稳定度是强大的。<br>
==> 死亡小队在这个国家肆虐。<br>
==> 埃塞俄比亚仍然是君主制国家。<br>
==> 埃塞俄比亚与世界其他地区的关系为坏。<br>
==> 该政权是偏执的。
";

// EVT Z

$titreuchronie49z="蒙主赐福之（替代历史）";

$texteuchronie49z="
在阿拉伯世界，自1973年埃及-叙利亚战胜以色列以来的喜悦之情依然高涨！<br>
如果超级大国不进行干预以迫使停火，阿拉伯国家的战果还会更大。<br>
阿拉伯领导人享有非凡的声望，他们的政权比以往任何时候都要稳固。<br>
在以色列，政治危机和人民对国防军战力的不信任似乎将持续很长一段时间。
";

$choix1uchronie49z="阿拉伯世界重建其荣耀";
$choix1uchronie49ztitle="这次胜利的长期影响会是什么？";

$titreuchronie49z1="蒙主赐福之（替代历史）";

$texteuchronie49z1="
==> 叙利亚和埃及的稳定度为样本。<br>
==> 以色列的稳定度为虚弱。<br>
==> 西奈半岛和戈兰高地不再被以色列占领。<br>
==> 1973年石油危机从未发生
";

// EVT AA

$titreuchronie49aa="在孟加拉的肮脏战争（替代历史）";

$texteuchronie49aa="
自1971年以来，孟加拉陷入了一场血腥的内战。<br>
由新德里地下指挥的孟加拉分离主义游击队战士似乎还没有准备放下武器。<br>
巴基斯坦军队只能有效控制城市<br>
镇压叛乱的行动伴随着大规模屠杀和大量难民涌向印度。<br>
对美国来说，公开支持他们的巴基斯坦盟友变得越来越微妙，一些参议员现在公开支持对巴基斯坦的制裁。
 
";

$choix1uchronie49aa="多么残酷的战争…";
$choix1uchronie49aatitle="没有解决方案";

$titreuchronie49aa1="孟加拉的肮脏战争（替代历史）";

$texteuchronie49aa1="
==> 巴基斯坦和美国的关系是不信任的<br>
==> 孟加拉是巴基斯坦的殖民地<br>
==> 在孟加拉有一支游击队<br>
==> 在印度有非政府组织（NGOs）活动";

// EVT AB

$titreuchronie49ab="达乌德汗（替代历史）";

$texteuchronie49ab="
刚刚挫败了共产主义分子的政变企图，达乌德汗重新夺回了他的国家。<br>
镇压极为残酷，大多数共产主义者已被处决或监禁<br>
由于不信任苏联（有充分的理由），也无法获得美国和邻国的大力支持，这位阿富汗强人转向海湾君主国，并取得了一定的成功。
<br>然而，在联美抗苏（反之亦然）的时候，这个政权将被焚毁。
<br>阿富汗人现在强烈声称在这场新的伟大比赛中宣布绝对中立。

 
";

$choix1uchronie49ab="这个国家将永远是两个阵营之间的缓冲区";
$choix1uchronie49abtitle="是这样吗？";

$titreuchronie49ab1="达乌德汗（替代历史）";

$texteuchronie49ab1="
==> 阿富汗是芬兰化的<br>
==> 阿富汗是中立国<br>
==> 它与美苏的关系为坏<br>
==> 该国获得“偏执”特质<br>
==> 该国没有亲苏反对派<br>
";

// EVT AC

$titreuchronie49ac="旧的独夫（替代历史）";

$texteuchronie49ac="
伊朗的君主制已经穷途末路<br>
生病的沙阿刚刚经历了一段民众不满时期，并授权野蛮镇压。<br>
许多国内外的政治对手都被谋杀了。然而，德黑兰的秩序充其量只能说是脆弱的。<br>
美国政府谴责伊朗政权的血腥镇压，并开始将其在该地区的旧盟友视为一种负担。<br>
利用伊朗的虚弱，其伊拉克邻国正在为库尔德斯坦省和胡兹斯坦省的游击队提供金援，其最终目的是迫使沙阿重新谈判有关阿拉伯河的航运协定。<br> 
";

$choix1uchronie49ac="伊朗的前途未卜";
$choix1uchronie49actitle="政权可能无法维持对局势的控制";

$titreuchronie49ac1="旧的独夫（替代历史）";

$texteuchronie49ac1="
==> 伊朗是君主制<br>
==> 伊朗的稳定度非常虚弱。<br>
==> 伊美关系是不信任的<br>
==> 该国有“偏执”特质<br>
==> 该国受到两支游击队的困扰<br>
";

$arabeskhouz="胡兹斯坦阿拉伯部落";


// EVT AD

$titreuchronie49ad="高效刺客（替代历史）";

$texteuchronie49ad="
自从他的前任在1981年3月的一个下午被刺杀以来，乔治·H·W·布什一直掌管着美利坚合众国。<br>
被刺杀的总统，罗纳德·里根，成为一个传奇，令他的许多崇拜者感到遗憾的是，他的任期提早终止：
有谁知道，如果能给他时间，这样一位拥有超凡魅力和坚定意志的总统本可以提供什么？<br>

";

$choix1uchronie49ad="有时一个人的死亡可以改变一切";
$choix1uchronie49adtitle="乔治·布什是美国总统，而里根总统任内的一些举措从未发生过";

$titreuchronie49ad1="高效刺客（替代历史）";

$texteuchronie49ad1="

==> 乔治·布什是美国总统<br>
==> 杜勒斯主义和里根主义失效<br>
==> 军备竞赛预算降低（美苏各-10$）<br>
A/N: 如果在游戏中，你在某个事件的插图中看到了罗纳德·里根，请努力想象你所看到的是乔治·布什。<br>
如果我擅长Photoshop，你早就注意到我的技巧了。
";


// EVT AE

$titreuchronie49ae="被炸毁的铁娘子（替代历史）";

$texteuchronie49ae="
联合王国仍然处于这场可怕恐怖袭击所带来的震惊中，恐怖袭击炸毁了布莱顿大酒店的一部分，造成首相玛格丽特·撒切尔夫人和其他许多受害者丧生。<br>
由爱尔兰共和军宣称负责的这起袭击事件在英国引起了一场激烈震荡，至今尚未从其后果中恢复过来，使原本震惊整个国家的尖锐社会紧张局势黯然失色。<br>
执政的保守党放慢了自由主义改革的步伐，把重点放在反恐事务上。

";

$choix1uchronie49ae="在联合王国的情况再也不一样了";
$choix1uchronie49aetitle="是这样吗？";

$titreuchronie49ae1="被炸毁的铁娘子（替代历史）";

$texteuchronie49ae1="
==> 联合王国获得偏执特质<br>
==> 一些小型事件不会发生<br>

";

// EVT AF

$titreuchronie49af="伊拉克伊斯兰共和国（替代历史）";

$texteuchronie49af="
无人能预料到伊拉克在与其强邻的战争中会如此迅速地崩溃。<br>
伊拉克伊斯兰共和国在旧复兴社会党政权的废墟上宣告成立，在这个动荡地区敲响了警钟。<br>
区域国家发起了一场军备竞赛，并正在加强其安全服务，以抗击什叶派原教旨主义的蔓延。<br>
无论是美国还是苏联都不能阻止这一突如其来的转变。<br>
在中东，未来是黑暗和不确定的。

";

$choix1uchronie49af="中东的混乱正在形成巨大的规模";
$choix1uchronie49aftitle="赶快点击以查看损害情况";

$titreuchronie49af1="伊拉克伊斯兰共和国（替代历史）";

$texteuchronie49af1="
==> 伊拉克是原教旨神权国家。<br>
==> 伊拉克与美苏有坏的关系。<br>
==> 伊拉克获得偏执和流氓国家特质。<br>
==> 在伊拉克有一支伊朗特遣队<br>
==> 在沙特阿拉伯和科威特有一支美国特遣队<br>
==> 全球恐怖主义更加活跃<br>
==> 沙特阿拉伯、科威特和约旦获得偏执特质。<br>
==> 沙特阿拉伯、科威特和约旦的当前武装力量和武装力量上限各+2。<br>
==> 在伊拉克出现一支庞大的部落游击队<br>
==> 阿富汗的什叶派游击队当前力量为最大值<br>
==> 阿富汗的什叶派游击队获得重武器特质<br>

";

// EVT AI

$titreuchronie89ai="在雅尔塔的纷争（替代历史）";

$texteuchronie89ai="
在雅尔塔，美国、英国和苏联之间普遍存在不信任。尽管还存在共同的敌人，每一个国家都想取得最有利的地位，而对于战后的欧洲以及每个国家的势力范围，双方无法达成任何协议，甚至是秘密的协议。 <br>
占领区实际上是根据每个国家军队的前进里程来界定的，在这场竞赛中，苏联是最残酷的，不惜牺牲以控制尽可能多的领土。 <br> 而现在最悲观的专家们认为，美苏之间的下一场战争只需要一点火花就可以引燃。
<br> <br> <i> 这一替代历史事件是在Magnum建议的基础上建立起来的 </i>

";

$choix1uchronie89ai="到目前为止，一切都很好…";
$choix1uchronie89aititle="欧洲会再次成为战场吗？";

$titreuchronie89ai1="在雅尔塔的纷争（替代历史）";

$texteuchronie89ai1="
<span style=\"font-style:italic;\">
==> 奥地利只由苏联控制 <br>
==> 没有西柏林 <br>
==> 东德的荣誉价值为50点 <br>
==> 西德的荣誉价值为30点 <br>
==> 战备等级（DEFCON）为 1
</ Span>
<br> <i> 注：德国的边界并没有被重新划定，因为游戏作者只是个懒惰的人 </i>
";

// EVT AJ


$titreuchronie89aj="HAKKAA PÄÄLLE（替代历史）";

$texteuchronie89aj="
克里姆林宫决心不宽恕芬兰跟随德国参与侵略战争的罪行。 <br>
无条件投降和军事占领是苏联对其北方邻国的计划。 <br>
随着芬兰工业作为对战争损失的赔偿被拆除，一批批芬兰战士在该国最不适宜居住的地区避难。<br>
苏联宣传宣称，当冬天来临的时候，这些死硬的纳粹分子会在树林里饥寒交迫地死去。
然而，这一问题不容忽视，因为这些匪徒养成了对苏联领土发动劫掠、切断通往摩尔曼斯克的铁路线的习惯。
";

$choix1uchronie89aj="这里依然有法西斯！";
$choix1uchronie89ajtitle="游击队在芬兰活动";

$titreuchronie89aj1="HAKKAA PÄÄLLE（替代历史）";

$texteuchronie89aj1="
<span style = \"font-style: italic; \">
==> 有一支游击队在芬兰<br>
==> 芬兰是亲苏的，并没有芬兰化<br>
==> 瑞典是芬兰化的<br>
==> 苏联在芬兰部署5驻军
</ Span>
";

// EVT AK


$titreuchronie89ak="红色朝鲜（替代历史）";

$texteuchronie89ak="
美国试图与苏联就朝鲜的未来保持建设性会谈，但他们的提议遭到拒绝。<br>
苏联并没有沿着三八线分治朝鲜，而是继续进军朝鲜半岛，席卷整个南方。<br>
对美国来说幸运的是，日本在苏联取得更多进展之前投降了，但木已成舟：朝鲜将统一在一个人民共和国之下。
<br><br><span style = \"font-style: italic; \">这一替代历史事件是由red_jars您提议的</ Span>
";

$choix1uchronie89ak="朝鲜红！";
$choix1uchronie89aktitle="一个分裂的朝鲜是如此荒唐可笑！";

$titreuchronie89ak1="红色朝鲜（替代历史）";

$texteuchronie89ak1="
<span style = \"font-style: italic; \">
--> 只有一个朝鲜，而它是社会主义的<br>
--> 战备等级（DEFCON） - 1
</ Span>
";


// EVT AG

$titreuchronie89ag="崛起之人（替代历史）";

$texteuchronie89ag="
承诺的改革迟迟未能实现，同时国家的经济形势日益恶化。<br>
改革和开放仍处于规划阶段。<br>
在总书记浪费时间在枯燥乏味的会议上为尼龙或其他琐事制定生产目标时，
由鲍里斯·叶利钦领导的革新卫队宣布了他们的要求：<br>
最后启动经济改革，并给予苏联加盟国更多的自主权。<br>
知识分子赞许！
";


$choix1uchronie89ag="让我们按照要求进行改革";
$choix1uchronie89agtitle="民族主义上升，激活改革和开放，降低斯大林主义";

$choix2uchronie89ag="为什么要改变？一切都很好！";
$choix2uchronie89agtitle="加剧腐败";

$choix3uchronie89ag="让抗议者安静下来";
$choix3uchronie89agtitle="增长斯大林主义和民族主义抗议";

$titreuchronie89ag1="崛起之人（替代历史）";

$texteuchronie89ag1="
<br>
<span style=\"font-style:italic;\">
==> 激活改革和开放<br>
==> 苏联各共和国的民族主义：+1<br>
==> 斯大林主义-2
</span>	
";

$titreuchronie89ag2="崛起之人（替代历史）";

$texteuchronie89ag2="
<br>
<span style=\"font-style:italic;\">
==> 腐败+10$ <br>
</span>	
";

$titreuchronie89ag3="崛起之人（替代历史）";

$texteuchronie89ag3="
<br>
<span style=\"font-style:italic;\">
==> 民族主义：+5<br>
==> 斯大林主义+2
</span>	
";


// EVT AH

$titreuchronie89ah="渗透圣战者（替代历史）";

$texteuchronie89ah="
在许多观察家看来，苏联已经输掉了阿富汗战争。<br>
这个例子唤醒了苏联南部加盟共和国的民族主义和宗教主义情绪。<br>
在一些地区，民族主义和伊斯兰主义运动拿起武器，公开鼓吹叛乱。<br>
在大城市中心，人们不再害怕示威游行，而在遥远的南方，境外的敌对圣战者已经渗透进来，扩大叛乱队伍。<br>
";


$choix1uchronie89ah="局势已经得到控制……";
$choix1uchronie89ahtitle="外围地区受到威胁";

$titreuchronie89ah1="渗透圣战者（替代历史）";

$texteuchronie89ah1="
<span style=\"font-style:italic;\">
==> 反叛组织出现在塔吉克斯坦<br>
==> 哈萨克斯坦、塔吉克斯坦和乌兹别克斯坦的稳定度下降<br>
==> 哈萨克斯坦和塔吉克斯坦的民族主义增加2
</span>
";
$brigandsinfiltres="渗透圣战者";


/*
XXXXXXXXXXXX
1964 US ELECTIONS MOD
XXXXXXXXXXXX
*/

$titreuchronie89al="软泥巫师（替代历史）";

$texteuchronie89al="
共和党的保守派决定放弃参议员巴里·戈德沃特，转而推举伊利诺伊州参议院少数党领袖、强大的演说家埃弗雷特·德克森。<br>
当他接受提名时，无人认为他有机会与约翰逊总统对抗，但通过他的魅力以及在中西部地区的声望，他得以取得险胜。<br>
现任总统德克森的目标是使国家朝着更加保守的方向发展，同时也寻求执行他帮助参议院通过的民权法案。<br>
他还致力于保持美国对共产主义的警惕，在越南和其他地方……<br>

<br><br><span style = \"font-style: italic; \">这一替代历史事件是由Devin2204您提议的</ Span>

";

$choix1uchronie89al="埃弗雷特·德克森总统！";
$choix1uchronie89altitle="美国有一位新的替代历史总统";

$titreuchronie89al1="软泥巫师（替代历史）";

$texteuchronie89al1="
<span style = \"font-style: italic; \">
-->埃弗雷特·德克森是美国总统，具有鹰派和实用主义特质。<br>
-->社会开支减少至5$
</ Span>
";

$everett="埃弗雷特·德克森";

// AM

$titreuchronie89am="在你心里，你知道他是个疯子（替代历史）";

$texteuchronie89am="
尽管困难重重，亚利桑那州参议员、共和党保守派领袖巴里·戈德华特拿下了总统宝座！
<br>这主要是因为约翰逊总统的福利和民权立法遭到强烈反对，以及在越南对共产党的进攻性不足。<br>
戈德华特总统增大了在越南的兵力，以及与苏联的紧张关系。
<br>他也开始着手削减约翰逊的社会项目。所有这些都大大加剧了美国的抗议活动。


<br><br><span style = \"font-style: italic; \">这一替代历史事件是由Devin2204您提议的</ Span>

";

$choix1uchronie89am="巴里·戈德华特总统！";
$choix1uchronie89amtitle="美国有一位新的替代历史总统";

$titreuchronie89am1="在你心里，你知道他是个疯子（替代历史）";

$texteuchronie89am1="
<span style = \"font-style: italic; \">
-->巴里·戈德华特是美国总统，具有鹰派、不可预测和钢铁意志特质。<br>
-->紧张局势已经上升到战备等级（DEFCON）1<br>
-->社会支出为0<br>
-->美国在南越部署部队增加10<br>
-->社会示威和民权示威活动急剧增加<br>

</ Span>
";

$barry="巴里·戈德华特";

// AN


$titreuchronie89an="一无所有，却控制一切（替代历史）";

$texteuchronie89an="
在共和党自由派领袖、纽约州州长纳尔逊·洛克菲勒成为共和党提名人之后，保守派已经到了穷途末路的地步。
<br>在他赢得总统职位后更是如此。
<br>他打算在很大程度上保持约翰逊政府的社会和经济政策不变。<br>
在国际上，洛克菲勒已经决定（目前）停止干涉拉丁美洲的政治，同时给予他们援助，试图引导他们在冷战中站在美国一边。
<br>然而，他也坚决要求干涉越南，试图遏制亚洲的共产主义。


<br><br><span style = \"font-style: italic; \">这一替代历史事件是由Devin2204您提议的</ Span>

";

$choix1uchronie89an="纳尔逊·洛克菲勒总统！";
$choix1uchronie89antitle="美国有一位新的替代历史总统";

$titreuchronie89an1="一无所有，却控制一切（替代历史）";

$texteuchronie89an1="
<span style = \"font-style: italic; \">
-->纳尔逊·洛克菲勒是美国总统，具有实用主义和外强中干特质。<br>
-->种族主义示威有所增加 <br>
-->对进步联盟的资助有所增加<br>


</ Span>
";

$nelson="纳尔逊·洛克菲勒";

// AO


$titreuchronie89ao="生还者（替代历史）";

$texteuchronie89ao="
他几乎做到了！<br>
1963年11月22日，肯尼迪总统在达拉斯遭到枪击。幸运的是，他没有被杀死，很快从养伤中恢复过来。
<br>据信是一名共产主义者枪击了他，但肯尼迪已经开始牵连他自己圈子里的人。
<br>头骨中枪对总统健康的影响也尚不得而知。
<br>他越来越依赖他的哥哥罗伯特的建议，有时甚至是他唯一咨询的人…


<br><br><span style = \"font-style: italic; \">这一替代历史事件是由Devin2204您提议的</ Span>

";

$choix1uchronie89ao="肯尼迪总统！";
$choix1uchronie89aotitle="美国有一位新的替代历史总统";

$titreuchronie89ao1="生还者（替代历史）";

$texteuchronie89ao1="
<span style = \"font-style: italic; \">
-->肯尼迪从暗杀中生还，并连任总统<br>
-->他获得病弱特质 <br>
-->他开始不信任中情局，这导致颠覆行动的大幅减成<br>
</ Span>
";

$kennedy="约翰·肯尼迪";


?>
