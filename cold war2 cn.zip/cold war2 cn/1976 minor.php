﻿<?php

// EVTS MINEURS 1976

$annee76evt1="西撒哈拉边界摩擦";
$annee76evt1detail="摩洛哥和阿尔及利亚很快就要开战了？";

$annee76evt2="阿尔及利亚武装波利萨里奥阵线战士";
$annee76evt2detail="西撒哈拉游击队的力量+2，并获得“民众支持”特质'";

$annee76evt3="南非：索韦托骚乱";
$annee76evt3detail="稳定度下降";

$annee76evt4="中非共和国：让·贝德尔·博卡萨登基称帝";
$annee76evt4detail="该国转变为君主政体";

$annee76evt5="危地马拉地震：超过2万人死亡，7万人受伤";
$annee76evt5detail="该国经济受到大量不必要粮食援助的严重破坏：稳定度-1和NGO出现";

$annee76evt6="阿根廷：魏地拉将军发表政变宣言";
$annee76evt6detail="该国转变为独裁政体，其稳定度提高两级";

$annee76evt7="美国：吉米·卡特当选";
$annee76evt7detail="他将于明年一月就职";

$annee76evt8="柬埔寨：红色高棉巩固政权";
$annee76evt8detail="该国变得偏执";

$annee76evt9="泰国：血腥镇压学生示威";
$annee76evt9detail="稳定度下降";

$annee76evt10="黎巴嫩：不同宗教间暴力激化";
$annee76evt10detail="稳定度下降";

$annee76evt11="黎巴嫩：黎巴嫩军队内爆";
$annee76evt11detail="军队力量最大上限崩溃至2，政府军组成了三个新团体";

$annee76evt12="黎巴嫩：叙利亚推动停火";
$annee76evt12detail="大多数派系获得“谈判”特质";

$annee76evt13="黎巴嫩：叙利亚军队进驻";
$annee76evt13detail="不是对所有人都是件好事";

$annee76evt14="黎巴嫩：一位叙利亚支持的新总统";
$annee76evt14detail="黎巴嫩对美苏关系和叙利亚相一致，稳定度+1，该国转变为代议共和政体";

$annee76evt15="黎巴嫩：埃及与叙利亚外交破裂";
$annee76evt15detail="在黎巴嫩，进步社会党开始反对叙利亚军队";

$annee76evt16="黎巴嫩：阿拉伯峰会在利雅得达成停火协议";
$annee76evt16detail="各派系获得“谈判”特质，黎巴嫩的稳定度增加（+2）";

$annee76evt17="波兰：大罢工和工人骚乱";
$annee76evt17detail="稳定度 -1";

$annee76evt18="联合王国：严峻的货币危机";
$annee76evt18detail="稳定度 -1";

$annee76evt19="西班牙：民主化转型";
$annee76evt19detail="该国转变为立宪君主政体";

$annee76evt20="中国：现任领导人逝世，毛主席重新归来";
$annee76evt20detail="不要怀念我，你们就是我！";

$maozedong="毛泽东";

$annee76evt21="叙利亚：伊斯兰暴动";
$annee76evt21detail="暴力游击队是恐怖袭击的罪魁祸首";








?>