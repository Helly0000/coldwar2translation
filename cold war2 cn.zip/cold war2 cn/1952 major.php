﻿<?php


//MODE FRANCE

// EVT A 

// Original: $titre1952a="AN EUROPEAN DEFENCE COMMUNITY";
$titre1952a="欧洲防务共同体";
/* Original: 
$texte1952a="
NATO is not yet completely implemented and the strategists in Washington are blunt: as long as Germany is not rearmed, Western Europe will not be capable of containing a Soviet invasion.<br>
The European armies are simply too weak.<br>
On the basis of the friendly American pressure, a treaty was drafted to enable the management of their own defence by the Europeans.<br>
This treaty however contains certain clauses that have a teeth-gnashing aspect for our country.<br>
Our citizens are not yet ready to see Germany rearming itself and the governance mechanisms of this community seem to threathen the independence of our national defence. <br>
Should we sign the treaty that would create this European Defence Community (EDC)?
";
*/
$texte1952a="
北约尚未完全实施，华盛顿的战略家们也对此直言不讳——只要德国不重新武装起来，西欧就无法遏制苏联的入侵。<br>
欧洲国家的军队实在太弱了。<br>
由于美国的友好压力，已经起草了一项条约，使欧洲人能够管理自己的国防。<br>
然而，这项条约包含的某些条款对我国来说是一个令人痛心的问题。<br>
我们的公民还没有准备好看到德国重新武装起来，这个共同体的治理机制似乎威胁到我们国防的独立性。<br>
我们是否应该签署一项建立欧洲防务共同体（EDC）的条约？
";


$choix11952a="让我们签署这项条约！";
$choix11952atitle="会大幅提高你的大西洋主义指数";

$choix21952a="让我们拒绝这项条约！";
$choix21952atitle="降低你的大西洋主义指数，恶化你与联邦德国的关系
";


// Original: $titre1952a="AN EUROPEAN DEFENCE COMMUNITY";
$titre1952a1="欧洲防务共同体";
/* Original: 
$texte1952a1="
The National Assembly must now ratify the treaty, but...<br>
Debates are heated on the subject and our country is now clearly divided in two irreconcilable sides: the pro- and anti-EDC.<br>
Communists and Gaullists are actively campaigning against this treaty.<br>
For those who refuse the treaty, signing would represent an unacceptable abandoning of national sovereignty.<br>
The climate is so tensed that this treaty will probably never be ratified...
<br>
<span style=\"font-style:italic;\">
	Contrary to what was expected, your Atlanticism score does not change.
</span>
";
*/
$texte1952a1="
国民议会已提出批准该条约的议案，但…<br>
关于这一问题的辩论十分激烈，我们的国家现在明显分为两个不可调和的阵营：支持和反对欧洲防务共同体（EDC）。<br>
共产主义者和戴高乐主义者激烈反对这项条约。<br>
对于那些反对该条约的人来说，签署条约将意味着在国家主权上不可接受的投降。<br>
气候如此紧张，这项条约可能永远不会被批准……
<br>
<span style=\"font-style:italic;\">
	与预期相反，你的大西洋主义指数实际上并没有改变。
</span>
";


// Original: $titre1952a2="AN EUROPEAN DEFENCE COMMUNITY";
$titre1952a2="欧洲防务共同体";
/* Original:
$texte1952a2="
The enemies of this treaty were so many that the National Assembly would have probably never ratified it anyway...
";
*/
$texte1952a2="
这项条约的敌人太多了，国民议会可能永远也不会批准它……
";













?>