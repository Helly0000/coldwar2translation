﻿<?php

// EVTS 1978

$annee78evt1="突尼斯：黑色星期四，51人在镇压总罢工中丧生";
$annee78evt1detail="稳定度下降（-1）";

$annee78evt2="安哥拉-南非边境战争";
$annee78evt2detail="一支南非远征军进入安哥拉";

$annee78evt3="在扎伊尔，沙巴战争重启";
$annee78evt3detail="一支独立游击队组织出现在刚果";

$annee78evt4="乍得：法国派遣一支特遣队";
$annee78evt4detail="1法国部队部署在乌干达";

$annee78evt5="扎伊尔：比利时和法国伞兵空降科卢韦斯";
$annee78evt5detail="比利时和法国军队部署+1";

$annee78evt6="乌坦战争";
$annee78evt6detail="坦桑尼亚想要罢免阿明·达达";

$tribusrebelles="部落叛军";

$annee78evt7="阿富汗：四月革命！";
$annee78evt7detail="阿富汗转变为人民民主政体！";

$annee78evt8="柬越战争";
$annee78evt8detail="越南将终结敌对的红色高棉政权";

$annee78evt9="蓝色贝雷帽在黎巴嫩部署";
$annee78evt9detail="他们应该能平息局势";

$annee78evt10="黎巴嫩：黎巴嫩军队内基督教派联盟(القوات اللبنانية)";
$annee78evt10detail="大多数是长枪党人";

$annee78evt11="伊朗：黑色星期五！军队射杀抗议者";
$annee78evt11detail="稳定度下降";

$annee78evt12="黎巴嫩：以色列国防军在南黎巴嫩干预巴勒斯坦战士";
$annee78evt12detail="巴解组织采取防御姿态（获得“观望”特质）";

$annee78evt13="伊朗：库姆发生激烈抗议游行";
$annee78evt13detail="伊玛目霍梅尼的支持者越来越激动：无效果";

$annee78evt14="伊朗：每次镇压行动后示威规模都会壮大";
$annee78evt14detail="伊朗稳定度： -1";

$annee78evt15="伊朗：政府下令冻结工资，抗议以更大烈度重启";
$annee78evt15detail="伊朗稳定度： -1";

$annee78evt16="伊朗：超过200万示威者在德黑兰！政权已经穷途末路";
$annee78evt16detail="伊朗稳定度： -1";

$annee78evt17="戴维营协议，中东和平将至？";
$annee78evt17detail="纳赛尔主义受到重击";

















?>