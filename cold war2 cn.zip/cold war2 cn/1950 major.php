﻿<?php




$titre1950a="我们的亚洲政策";
/* Original: 
$texte1950a="
Secretary of State Dean Acheson defined our containment strategy for Asia.<br>
He has a speech to deliver at the National Press Club very soon where he will make our policy public.
What should he say?
";
*/
$texte1950a="
国务卿迪安·艾奇逊已经界定了我们的亚洲遏制战略。<br>
很快，他将在全国新闻俱乐部发表演讲，在那里他将公布我们的政策。
他该怎么说？
";


// Original: 
$choix11950a="我们将与共产主义针锋相对";
// Original: $choix11950atitle="Increases tension and improves your relations with South Korea, deteriorates your relations with China, South Korea and Vietnam switch to the American sphere of influence";
$choix11950atitle="加剧紧张局势，改善与韩国的关系，恶化与中国的关系；南韩和越南进入美国势力范围";

$choix21950a="我们的防线从近海开始";
$choix21950atitle="缓和紧张局势，恶化与韩国的关系。中国会对此作何反应？";

$titre1950a1="我们的亚洲政策";
/* Original: 
$texte1950a1="
The US defence perimeter in the Far East stretches from the Aleutian islands to Taiwan via Korea and Japan.<br>
The Asian communists are warned!
";
*/
$texte1950a1="
美国在远东的防御范围从阿留申群岛经朝鲜半岛和日本列岛一直延伸至台湾海峡。<br>
亚洲的共产分子已被警告了！
";

$titre1950a2="我们的亚洲政策";
/* Original: 
$texte1950a2="
The US defence perimeter in the Far East stretches from the Aleutian islands to the Philippines via Japan.<br>
Foreign observers noted that Korea and Taiwan are excluded of this perimeter... 
";
*/
$texte1950a2="
美国在远东地区的防御范围从阿留申群岛经日本列岛延伸至菲律宾。<br>
外国观察家注意到，朝鲜半岛和台湾海峡不在这一防御范围内。
";


// EVT B

$titre1950b="猎巫行动";
/* Original: 
$texte1950b="
麦卡锡参议员最近引起了全国的注意！
		这个人的声望在上升，但他一再攻击联邦政府是件麻烦事。<br>
		他会在会议上宣布：<br>
		“国务院充斥着共产党。我手上有一份205人的名单，这是一份国务卿中的共产党成员的名单，尽管如此，他们仍在国务院工作和制定政策。”
		
		<br>我们应该鼓励这种“白色恐怖”吗？
";
*/
$texte1950b="
麦卡锡参议员最近引起了全国的注意！
		他的声望在上升，但他对联邦政府的一再攻击确实令人生厌。<br>
		他准备在即将举行的会议上宣布以下内容：<br>
		“国务院充斥着共产党。在我手上有一份205人的名单，尽管国务卿知道名单上这些人都是共产党员，但这些人至今仍在草拟和制定国务院政策。”
		
		<br>我们应该鼓励这种“红色恐怖”吗？
";


// Original: $choix11950b="Let him unleash his fierce anticommunism";
$choix11950b="让他掀起这场反共产主义狂热";
$choix11950btitle="会引发一场猎巫行动和加剧紧张局势";

$choix21950b="这个极端分子不需要也不值得认真对待";
// Original: $choix21950btitle="Decreases tension but will let the communist elements free to sabotate our nation";
$choix21950btitle="缓和紧张局势，但会给共产分子得到对我国肆意破坏的自由";

$titre1950b1="红色恐怖！";
/* Original: 
$texte1950b1="
负责测试公务员忠诚度的泰丁斯委员会已开始着手调查麦卡锡参议员的指控。<br>
然而，委员会的听证会很快就证明了这不过是一场旨在清除叛徒的闹剧！<br>
我们需要一个像麦卡锡参议员这样的人来领导与邪恶的斗争。<br>
对敌方特工的识别必须扩大到科学界和好莱坞：红色无处不在！<br>

";
*/
$texte1950b1="
负责测试公务员忠诚度的泰丁斯委员会已开始着手调查麦卡锡参议员的指控。<br>
然而，委员会的听证会很快就证明了这不过是一场旨在清除叛徒的闹剧！<br>
我们需要一个像麦卡锡参议员这样的人来领导与邪恶的斗争。<br>
对敌方特工的识别必须扩大到科学界和好莱坞：红色无处不在！<br>

";


$titre1950b2="欺诈和骗局";
/* Original: 
$texte1950b2="
The Tydings Commission, in charge of testing the loyalty of civil servants, set to work to examine Senator McCarthy's accusations.<br>
The general opinion however is that the Senator is not serious and his accusations are baseless.

";
*/
$texte1950b2="
负责测试公务员忠诚度的泰丁斯委员会已开始着手调查麦卡锡参议员的指控。<br>
然而，普遍的意见是，参议员不应受到认真对待，他的指控是毫无依据的。

";

// EVT C

$titre1950c="中苏友好同盟互助条约？";
/* Original: 
$texte1950c="
Should not the Soviet \"big borther\" support the young Chinese people's republic?<br>
The country must be rebuilt and the fight is not over yet with both inner and outer enemies.<br>
Assisting the Chinese is thus a brotherly duty.<br>
From another perspective, Chine could become our rival in socialism one day…<br>
The Chinese will to export the revolution outside of their borders could also challenge the regional power balance.
";
*/
$texte1950c="
苏联“老大哥”难道不应该支持年轻的中华人民共和国吗？<br>
与内外敌人的斗争还没有结束，这个国家必须重建。<br>
因此，援助中国人民是兄弟般的义务。<br>
但是从另一个角度考虑，中国可能有一天会成为我们在社会主义阵营内的竞争对手…<br>
中国对国外革命者事业的支持援助也可能挑战地区力量平衡。
";

$choix11950c="让我们援助他们！（每月-10预算/荣誉+100）";
$choix11950ctitle="会使中国在亚洲更加活跃";

// Original: $choix21950c="We should not fund the enemy of tomorrow…";
$choix21950c="我们不应该援助明天的敌人…";
$choix21950ctitle="急剧恶化你和中国的关系";

$titre1950c1="签署中苏友好同盟互助条约";
/* Original: 
$texte1950c1="
Our aid will help China to quickly recover from the civil war!
";
*/
$texte1950c1="
我们的援助将帮助中国人民尽快从内战中恢复过来！
";

$titre1950c2="不签署中苏友好同盟互助条约！";
/* Original: 
$texte1950c2="
Their views on the transition from socialism to communism are too divergent from ours to make the understanding between us possible.
";
*/
$texte1950c2="
他们对由社会主义向共产主义过渡理念的看法与我们的分歧过大，我们之间无法达成任何理解。
";


// EVENT D

$titre1950d="我们应该喂养饿虎吗？";
/* Original: 
$texte1950d="
Kim Il-sung, the North Korean leader, only dreams about invading the south and reuniting the peninsula under the banner of marxism-leninism.<br>
		His army has been training for a year and is now ready to swarm into South Korea.<br>
		Their plan of attack looks solid and the new American Secretary of State, Dean Acheson, gave the world to understand that the USA would not intervene in Korea.<br>
		With massive support from our side, South Korea could fall rapidly...
";
*/
$texte1950d="
北朝鲜领导人金日成唯一的梦想便是南下解放韩国，将整个朝鲜半岛统一在马列主义的旗帜下。<br>
		他的军队已经训练了一年，现在准备好南下韩国。<br>
		他们的攻击计划看起来很可靠，新任美国国务卿迪安·艾奇逊让世界认为美国将不会干涉朝鲜半岛事物。<br>
		在我方的大力支持下，南朝鲜伪政权可能会迅速垮台……
";


$choix11950d="让我们帮助我们的朝鲜兄弟！ (-$25)";
// Original: $choix11950dtitle="Will dispatch Soviet military advisors in North Korea and reinforce both the North Korean Army and the country's stability";
$choix11950dtitle="将向朝鲜派遣苏联军事顾问，并将加强朝鲜军队和该国稳定度";

$choix21950d="让我们抑制朝鲜人的热情";
$choix21950dtitle="恶化你与朝鲜的关系";

$titre1950d1="饿虎待食！";
/* Original: 
$texte1950d1="
The level of training and morale of the North Korean troops is simply remarkable. With the American disengaging from the Korean peninsula, Kim Il-sung's dream of uniting Korea by force seems to be achievable...<br>
The assault could take place before the end of the year.
";
*/
$texte1950d1="
朝鲜军队的训练水平和士气实在是令人瞩目。随着美国撤出朝鲜半岛，金日成以武力统一朝鲜半岛的梦想似乎可以如愿以偿……<br>
攻击可能在今年年底前开始。
";


$titre1950d2="饿虎不安管束";
/* Original: 
$texte1950d2="
Kim Il-sung's frustration level is so high that some our diplomats are afraid that he will disregard our instructions and start a war on his own initiative...
";
*/
$texte1950d2="
金日成的沮丧程度是如此之高，以至于我们的一些外交官担心他会无视我们的指示，主动发动战争……
";


// EVT E

$titre1950e="我们应该喂养饿虎吗？";
/* Original: 
$texte1950e="
Syngman Rhee, the South Korean leader, only dreams about invading the North and reuniting the Korean peninsula under his banner.<br>
His army is unfortunately maybe not equal to his ambitions...<br>
Should be provide him the massive military support he is asking for?
";
*/
$texte1950e="
南韩领导人李承晚唯一的梦想便是北上进军朝鲜，将整个朝鲜半岛统一在他的旗帜下。<br>
不幸的是，他贫弱的军队与他的野心并不匹配……<br>
我们是否应该向他提供他一直要求的大规模军事支持？
";


$choix11950e="让我们帮助他们！ (-$25)";
// Original: $choix11950etitle="Will dispatch American military advisors in South Korea and reinfoce both the South Korean army and the country' stability; this will also increase tension";
$choix11950etitle="将向韩国派遣美国军事顾问，加强韩国军队和该国稳定度；也将加剧紧张局势";

$choix21950e="让我们抑制韩国人的热情";
$choix21950etitle="恶化你与韩国的关系";

$titre1950e1="饿虎待食！";
/* Original: 
$texte1950e1="
The level of training and morale of the North Korean troops is still suboptimal...<br>
Syngman Rhee remains nonetheless confident in his capacity to take the North back.
";
*/
$texte1950e1="
南韩军队的训练水平和士气仍不理想……<br>
尽管如此，李承晚仍然对自己夺回北方的能力充满信心。
";


$titre1950e2="饿虎不安管束";
/* Original: 
$texte1950e2="
Syngman Rhee does not understand our position. He will have to accept it anyway because his army in not in capacity to take the North back.
";
*/
$texte1950e2="
李承晚对我们的立场全不理解。不过，无论如何他都得接受，因为他的军队根本无力夺回北方。
";


// EVT F

$titre1950f="北朝鲜入侵南韩！";
/* Original: 
$texte1950f="
This morning, 6 North Korean divisions crossed the 38th parallel.<br>
The situation is preoccupying.<br>
Should we intervene to contain communism at the risk of an escalation with the USSR and China?
<br>We are faced with a unique opportunity to step in with the UNO's approval (thanks to the Soviets applying the policy of the empty chair at the UNO Security Council since the Berlin Blockade), as champions of the free world.
";
*/
$texte1950f="
今天上午，朝鲜人民军的6支军团越过了三八线。<br>
局势着实令人担忧。<br>
我们是否应该在面临与中苏局势升级的风险下进行干预以遏制共产主义？
<br>我们正面临着一个独特的机会，在联合国的批准下作为自由世界的捍卫者，（多亏苏联在柏林封锁后一直保持联合国安理会席位空缺）。
";


$choix11950f="让我们帮助他们！（荣誉+100）";
// Original: $choix11950ftitle="Will get you into a war, grant you a military base in South Korea and increase DEFCON";
$choix11950ftitle="会使你卷入战争，在韩国建立军事基地，增加防御能力";

$choix21950f="我们不应该去……";
// Original: $choix21950ftitle="The communists could believe they can do whatever they want";
$choix21950ftitle="共产党人也许相信他们可以为所欲为";

$titre1950f1="大韩民国的崩溃";
/* Original: 
$texte1950f1="
A significant part of the South Korean troops was on leave and the communist attack took everybody by surprise!<br>
In Washington, panic is fortunately not prevailing: the enemy gave us the boon to intervene in Asia to drive back communism by force!<br>
The North Korean advance is so fast that our troops can do nothing but retreating: they must hold a perimeter in Busan at any cost so that additional reinforcements can arrive...
";
*/
$texte1950f1="
南韩军队中有相当一部分人不在前线，共产党的进攻让所有人都感到意外！<br>
在华盛顿，恐慌并没有占上风——敌人给了我们干预亚洲以武力击退共产主义的绝佳良机！<br>
朝鲜的进攻是如此迅猛有力，连美国军队都被击退：他们现在必须不惜一切代价在釜山守住防线，以便部署进一步的增援部队……
";

$titre1950f2="大韩民国的崩溃";
/* Original: 
$texte1950f2="
A significant part of the South Korean troops was on leave and the communist attack took everybody by surprise!<br>
The country should fall like a ripe fruit in Kim Il-sung's hands.<br>
In Washington, dismay is dominant: part of the general staff does not understand why we abandon Korea to the communists...
";
*/
$texte1950f2="
南韩军队中有相当一部分人不在前线，共产党的进攻让所有人都感到意外！<br>
预计这个国家将很快像一颗成熟的果实一样落入金日成的手中。<br>
在华盛顿，沮丧占主导地位——部分总参谋部成员不明白我们为什么把朝鲜拱手让给共产党……
";


// EVT G

$titre1950g="祖国解放战争！";
$texte1950g="
今天上午，朝鲜人民军的6支军团越过了三八线。<br>
		北朝鲜在这次进攻前并未认真征求我们的许可（甚至建议）。<br>
		我们是否应该紧跟事态发展，冒着局势失控升级的风险帮助他们？
";


$choix11950g="让我们帮助他们！(-$50)";
// Original: $choix11950gtitle="Will increase tension and both North Korean current and maximal military capacity";
$choix11950gtitle="加剧紧张局势，北朝鲜当前军事力量和军事力量上限增加";

$choix21950g="让他们自己处理吧！";
$choix21950gtitle="无效果";

$titre1950g1="美国干涉！";
/* Original: 
$texte1950g1="
Our worst nightmare became a reality: against all odds, the USA decide to intervene in Korea!<br>
Will they be able to slow the North Korean flood down before it captures all the country?<br>
Our aid should make the difference!
";
*/
$texte1950g1="
我们最可怕的噩梦已经成为现实——尽管困难重重，美国还是决定干预朝鲜！<br>
他们能在朝鲜彻底席卷全国之前减缓它的推进速度吗？<br>
我们的援助应该会使之改变！
";


$titre1950g2="美国干涉！";
/* Original: 
$texte1950g2="
NOur worst nightmare became a reality: against all odds, the USA decide to intervene in Korea!<br>
Will they be able to slow the North Korean flood down before it captures all the country?<br>

";
*/
$texte1950g2="
我们最可怕的噩梦已经成为现实——尽管困难重重，美国还是决定干预朝鲜！<br>
他们能在朝鲜拿下该国全境之前减缓它的推进速度吗？<br>

";

// EVT H

$titre1950h="让我们全力以赴！";
/* Original: 
$texte1950h="
The red flood in Korea cannot be held back without taking drastic steps.<br>
		Five B-29 groups will be placed in the service of Far East Air Forces, and F4U Corsair squadrons will be able to massively use napalm.<br>
		<br>You can now access strategic bombings through the military actions screen of North Korea (if you have over $25 left in your budget).
		<br>You can access napalm strikes through the military actions screen of South Korea.
";
*/
$texte1950h="
如果不采取有力措施，朝鲜半岛的赤潮将是无法遏制的。<br>
		五架B-29飞机将投入远东空军服役，F4U海盗中队将能够广泛使用凝固汽油弹。<br>
		<br>你现在可以在北朝鲜的军事行动界面使用战略轰炸（如果你的预算余额多于25）
		<br>你现在可以在南韩的军事行动界面使用凝固汽油弹轰炸。
";


// EVT I

$titre1950i="仁川登陆";
/* Original: 
$texte1950i="
It is time for counterattack in Korea!<br>
General MacArthur planned a landing in Incheon to take the North Koreans from behind.<br>
Our Marines master this kind of operations since the Pacific War and we will certainly have the advantage of surpise but the defences in Incheon, where the landing should take place, are formidable...<br>
US Navy Commander Arlie G. Capps summurised the situation as follow: « We drew up a list of every natural and geographical handicap... Incheon has them all ».
";
*/
$texte1950i="
到了在韩国反击的时候了！<br>
麦克阿瑟将军计划在仁川登陆，从后面夹击朝鲜人。<br>
我们的海军陆战队从二战太平洋战争开始就掌握了这种作战方式，我们当然会有出其不意的优势，但是在仁川的防御，在那里登陆是可怕的……<br>
美国海军司令阿里·G·卡普斯总结了以下情况：“我们列出了各种自然和地理障碍……这些在仁川都存在".
";

$choix11950i="让我们登陆！ (-$25)";
$choix11950ititle="如果这次行动成功，朝鲜将遭到前后夹击";

$choix21950i="这是纯粹的疯狂！";
$choix21950ititle="无效果";

$titre1950i1="";
$texte1950i1="
";

$titlevictoireincheon="胜利！";
/* Original: 
$textevictoireincheon="胜利！<br>
The enemy was completely surprised by our maneouvre and we may now march on Seoul.<br>
50,000 soldiers and 6,000 vehicles have just been disembarked to exploit this success.";
*/
$textevictoireincheon="胜利！<br>
敌人对我们的进攻全无防备，我们现在要向汉城进军了！<br>
5万名士兵和6千辆汽车利用这一成功刚刚登岸。";


$titledefaiteincheon="仁川灾难";
/* Original: 
$textedefaiteincheon="This is a sad day for the Marine Corps...<br>
This nut was to hard to chew.<br>
A slow reconquest from the Busan perimeter is the new solution that is currently being considered.";
*/
$textedefaiteincheon="对海军陆战队来说，这是一个悲伤的日子……<br>
这是一个难以下咽的苦果。<br>
目前正在考虑的新解决方案是从釜山外围缓慢地重新开启反击。”;

// Original: $titre1950i2="THE BUSAN REDOUBT";
$titre1950i2="釜山要塞";
/* Original: 
$texte1950i2="
No need for hazardous landings: the North Koreans troops wear themselves out in vain assaults against the Busan perimeter.<br>
Their armoured divisions greatly suffered and we have control of the sky.<br>
This is a time for counterattack from the perimeter.
";
*/
$texte1950i2="
不需要危险的登陆——朝鲜军队已在对釜山外围的空袭中疲惫不堪。<br>
他们的装甲师遭受了巨大损失，现在我们也控制着天空。<br>
现在是外围反击的时候了。
";


// EVT J

// Original: $titre1950j="INDOCHINA: COLONIAL WAR OR WAR AGAINST COMMUNSIM?";
$titre1950j="印度支那：殖民战争，还是反共战争？";
/* Original: 
$texte1950j="
The United States of American condemn colonialism!<br>
However, does not the fight of France in Indochina have more to do with war against communism?<br>
It seems this question is not simply a matter of ethics…<br>
The North Vietnamese troops are capturing ground day after day.<br>
Will we abandon the Asian States and let them fall one after another in a giant dominoes game?
";
*/
$texte1950j="
美利坚合众国谴责殖民主义！<br>
然而，法国在印度支那的战争，难道不是更多地与反共战争相关吗？<br>
看来这个问题不仅仅是道义问题…<br>
北越军队日复一日地推进阵地。<br>
我们会抛弃亚洲国家，让它们在多米诺骨牌中一个接一个倒下吗？
";

// Original: $choix11950j="Let us help the Frenchmen fighting communism! (-$10$ immediately then -$10/month)";
$choix11950j="让我们帮助法国对抗共产主义！（立即-10$，然后每月-10$预算）";
// Original: $choix11950jtitle="This material aid should help containing the danger";
$choix11950jtitle="这种物质援助应该有助于控制危险";

$choix21950j="让我们谴责这场殖民战争！（荣誉+50）";
// Original: $choix11950jtitle="This material aid should help containing the danger";
$choix21950jtitle="但这会恶化你与法国的关系，最终导致失去荣誉";

$titre1950j1="反共之盾！";
/* Original: 
$texte1950j1="
By giving the Frenchmen the means to beat the communists, we avoid a direct intervention from our troops: our interest was blatant! 
";
*/
$texte1950j1="
通过给予法国人在击败共产主义上的支持，我们避免了我军的直接干涉——好处是显而易见的！
";


$titre1950j2="一场殖民战争";
/* Original: 
$texte1950j2="
The Frenchmen are defending their interests in Indochina, certainly not democracy's!<br>
Let us see how they manage without our money!
";
*/
$texte1950j2="
法国人在印度支那捍卫的不过是自己的殖民利益——这当然不是民主的！<br>
让我们看看没有我们的资金他们能如何支撑下去。
";


// EVT K

// Original: $titre1950k="THE \"NORTH KOREAN\" AVIATION SPEAK CHINESE";
$titre1950k="朝鲜“空军”讲中国话";
/* Original: 
$texte1950k="
The North Korean aviation is stimulated by the active Soviet and Chinese participation.<br>
MiGs infest the sky and we fail to enforce our air supremacy.<br>
This problem has a simple solution: bombing the air bases in Chinese territory.<br>
However, these actions would have terrible political costs...
";
*/
$texte1950k="
由于中苏的积极干预，朝鲜空军得到了增强。<br>
米格飞机在天空中出没，我们未能巩固我们的制空权。<br>
这个问题有一个简单的解决办法——轰炸位于中国境内的空军基地。<br>
然而，这些行动将付出可怕的政治代价……
";

// Original: $choix11950k="Let us bomb these places (-$25)";
$choix11950k="让我们轰炸中国空军基地 (-$25)";
// Original: $choix11950ktitle="Increases tension, deteriorates your relations with China and North Korea";
$choix11950ktitle="加剧紧张局势；恶化与中国和朝鲜的关系";

// Original: $choix21950k="Let us restrict our action to the south side of the bord";
$choix21950k="让我们把行动限制在边界以南";
$choix21950ktitle="无效果";

// Original: $titre1950k1="CHINESE AIR BASES ARE BOMBED";
$titre1950k1="中国空军基地遭轰炸";
/* Original: 
$texte1950k1="
Mao vigorously protest!<br>
These bombings seem to had very little impact on the enemy aviation activity.<br>
Our secret services let us know that a second army of Chinese \"volunteers\" entered Korea.<br>
These troops are ill-equipped and depend on rudimentary logistics: our bombings should have not effect on their advance.
";
*/
$texte1950k1="
中国对此强烈抗议!<br>
然而，这些轰炸似乎对敌方的航空活动影响甚微。<br>
我们的特勤部门已经通知我们第二支中国志愿军已经进入朝鲜。<br>
这些部队装备落后，依靠简陋的后勤，我们的轰炸对他们的前进无能为力。
";

/* Original: 
$textevictoirebombchine="The enemy bases were hit hard: they did not expect such a daring move from us.<br>
The communist aviation has been decimated and we have complete control over the sky.<br>
Our secret services believe the enemy forces are close to their breaking point: North Korean elite soldiers from the early days of this war have been replaced by force-enlisted unmotivated conscripts. <br>
Our services also let us know that a second army of Chinese \"volunteers\" entered Korea.<br>
These troops are ill-equipped and depend on rudimentary logistics: our bombings should have not effect on their advance.
";
*/
$textevictoirebombchine="敌军基地遭到重创，他们没想到我们会采取如此大胆的行动。<br>
共产主义者的空军已经被摧毁了，我们完全控制了天空。<br>
我们的情报部门认为，敌军已经接近崩溃的临界点——北朝鲜在战争初期的精锐士兵已经被毫无动力的应征入伍士兵所取代。<br>
我们的特勤部门也通知我们第二支中国志愿军已经进入朝鲜。<br>
这些部队装备落后，依靠简陋的后勤，我们的轰炸对他们的前进无能为力。
";


// Original: $titlevictoirebombchine="WE HAVE THE AIR SUPREMACY";
$titlevictoirebombchine="我们拥有制空权";

$titre1950k2="放过中国基地";
/* Original: 
$texte1950k2="
Bombing Chinese territory could have generated pointless escalation in this conflict...<br>
We took the right decision.
";
*/
$texte1950k2="
轰炸中国领土可能会导致这场冲突毫无意义的升级……<br>
我们做出了正确的决定。
";


// EVENT L

// Original: $titre1950l="IL FAUT PURGER !";
$titre1950l="我们必须清洗！";
/* Original: 
$texte1950l="
The Yugoslav precedent demonstrates that we must keep a tight reign on the European communist parties.<br>
They are filled with traitors and compromise-prone doormats.<br>
There is only one way to be a communist and it is the one way we dictate!<br>
The socialist revolution still has many enemies, we cannot be weak.
";
*/
$titre1950l="我们必须清洗！";
$texte1950l="
南斯拉夫的先例表明，我们必须严格控制欧洲共产党。<br>
在他们之中充斥着叛徒和右倾机会主义者。<br>
要通往共产主义只有一条道路，那就是我们的道路！<br>
社会主义革命事业仍面临着许多敌人，我们承受不起任何形式的软弱。
";


$choix11950l="让我们清洗！";
// Original: $choix11950ltitle="Increases stalinism and the stability in East European countries; will slightly delay the possible rise of troubles";
$choix11950ltitle="增长斯大林主义和东欧国家的稳定度；将稍微推迟可能出现的麻烦";

$choix21950l="让我们容忍矛盾";
// Original: $choix21950ltitle="Will sharply decrease stalinism";
$choix21950ltitle="显著降低斯大林主义";

$titre1950l1="以匈牙利为榜样";
/* Original: 
$texte1950l1="
The Titoist fellow travellers and the doormats are pushed to resign.<br>
In Hungary, it is the chief of State himself who is arrested!<br>
Numerous undesirable persons are taken away from the cities and put in agricultural labour camps.<br>
Everywhere in Eastern Europe people's republics, the communist parties are cracked down.<br>
<span style=\"font-style:italic;\">Stability increases in the concerned countries</span>
";
*/
$texte1950l1="
铁托主义的同行和白手套已经被迫辞职。<br>
在匈牙利，被捕的是国家元首本人！<br>
许多不良分子被赶出城市，被安置在农业劳改营。<br>
在东欧的各地人民共和国，共产党内都开始严厉镇压。<br>
<span style=\"font-style:italic;\">有关国家的稳定度有所增加</span>
";

// Original: $titre1950l2="THE SOCIALISMS FAIR";
$titre1950l2="东欧社会主义博览会";
/* Original: 
$texte1950l2="
Facing the almighty communist parties, social-democrat or agrarian movements continue to exist and meddle in public affairs, for lack of possibility to participate in elections.<br>
The Stalinist policy as set by Moscow is sometimes even contested!<br>
What will emerge from this chaos of ideas?
";
*/
$texte1950l2="
作为与全能的共产党的对抗，社会民主运动和土地运动继续存在并干涉公共事务，尽管它们不能参加选举。<br>
有时，莫斯科制定的政策甚至受到争议！<br>
从这混乱的思想中会产生什么？
";


// EVT M

$titre1950m="严冬";
/* Original: 
$texte1950m="
The harsh Korean winter meets UNO units which are not really prepared to such cold.<br>
On the contrary, the tough Nort Korean and Chinese fighters are perfectly equipped for this hard weather...
";
*/
$texte1950m="
联合国军遭遇了严酷的朝鲜冬天，他们没有真正做好应对这种寒冷的准备。<br>
相反，吃苦耐劳的中朝战士在这种恶劣的天气里可谓如鱼得水……
";


$choix11950m="这场战争变成了一场噩梦！";
$choix11950mtitle="朝鲜稳定度增加，韩国稳定度下降";

$titre1950m1="严冬";
/* Original: 
$texte1950m1="
The North Korean stability increases (+2)<br>
The South Korean stability decreases (-1)
";
*/
$texte1950m1="
朝鲜稳定度增加（+2）<br>
韩国稳定度下降（-1）
";


// EVT N

$titre1950n="局势错综复杂";
/* Original: 
$texte1950n="
Opinions are converging among our agents and diplomats:<br>
Kim Il-sung, the North Korean leader, could invade Korea without even our agreement to his projects!<br>
Our involvement and our agreements with North Korea could degnerate into a world war should there be a confrontation in the peninsula...<br>
We walk on eggshells... what should we do?
";
*/
$texte1950n="
我们的特工和外交官们的意见正在达成一致：<br>
朝鲜领导人金日成甚至可以在不征求我们同意的情况下南下进攻韩国！<br>
如果朝鲜半岛发生对抗，我们的介入和与朝鲜的协议可能会演化为一场世界大战……<br>
局势如履薄冰……我们该怎么办？
";

// Original: $choix11950n="Let us withdraw any official support to him (but not what is unofficial)";
$choix11950n="让我们收回所有的官方支持（但非官方支持除外）";
$choix11950ntitle="缓和紧张局势，取消与朝鲜的防御协议，并撤出军队";

$choix21950n="我们不害怕一场新的战争！";
$choix21950ntitle="加剧紧张局势";

// Original: $titre1950n1="APEASEMENT IN KOREA";
$titre1950n1="朝鲜的绥靖政策";
$texte1950n1="
当我们取消了对朝鲜的所有官方支持，最后一位苏联军事顾问搭乘火车返回祖国时，外交官们一直在为亚洲紧张局势的缓和而庆幸。<br>
南韩已经放松了戒备，把一半的士兵调离前线。<br>
既然我们已经高调结束了我们的干预，金日成将最终得以发动他的攻势，使南北朝鲜重归统一。<br>
他会得到我们的精神和物质支持……但我们不会直接干预。

$titre1950n2="美国不过是纸老虎";
/* Original: 
$texte1950n2="
Our information services are formal: the American nuclear bombs reserve is very small and they are not in a position to rapidly intervene in Korea...<br>
Under these circumstances, why should we keep a low profile?
";
*/
$texte1950n2="
我们的情报部门对我们直言不讳——美国的核储备非常少，他们无法迅速干预朝鲜<br>
在这种情况下，我们为什么要保持低调？
";

// EVT O

$titre1950o="空席政策";
/* Original: 
$texte1950o="
The americans brought the korean case before the security council of the United Nations Organization.
<br>
We could stop this initiative with our Veto.<br>
But we are boycotting the UNO for the moment, to protest against the non-recognition of the People's Republic of China.
<br>
Should we change our mind ?<br>
Our chineses partners want to attract the imperalist in this deadly korean trap, where their manpower will overrun them.
";
*/ 
$texte1950o="
美国人已经把朝鲜半岛议案提交到联合国安理会。
<br>
我们可以用我们的否决权阻止这项倡议。<br>
但是，目前我们因抗议联合国拒绝承认中华人民共和国而对其进行抵制。
<br>
我们应该改变主意吗？<br>
如果帝国主义者被引入这个致命的朝鲜陷阱里，我们的中国伙伴将会出兵干预，而在那里中国的人力将压倒他们。
";

// Original: $choix11950o="Veto ! (Prestige -50)";
$choix11950o="否决！（荣誉-50）";
$choix11950otitle="如果帝国主义者在没有得到联合国批准的情况下出兵朝鲜，他们将失去50荣誉";

// Original: $choix21950o="That chair must remain empty";
$choix21950o="保持联合国安理会席位空缺";
// Original: $choix21950otitle="The imperialists will rush right into our korean trap !";
$choix21950otitle="帝国主义者会一头冲进我们的朝鲜陷阱！";

$titre1950o1="否决";
$texte1950o1="
";

/* Original: 
$interventionusa="
The USA ignored our Veto and urged their first troops to Korea.<br>
By this decision, the world will truly understand the hoplessness of the UNO.
";
*/
$interventionusa="
美国无视我们的否决，他们向朝鲜派出了第一批部队。<br>
通过这一决定，世界将真正体会到联合国的绝望。
";

/* Original: 
$interventionjapon="
The USA accepted our Veto, but to the world's surprise, japaneses troops landed in Busan to help south korea !!!<br>
That japanese interventionism could not have been possible without the american's permission...<br>
The pacific states are worried about the revival of Japanese militarism.<br>
Japanese captured materials  was reportedly returned to Japan by the USA and volunteer recruitment offices were set up in Japanese cities, without the occupying authorities finding fault with it.


.<br>
(Cooling in the relationships between USA and Indonesia, Taiwan and Australia )
";
*/
$interventionjapon="
美国接受了我们的否决，但令世界惊讶的是，日本军队登陆釜山帮助韩国！！！<br>
没有美国的许可，日本的干涉是不可能的……<br>
太平洋国家担心日本军国主义的复辟。<br>
据报道，缴获的日本物资被美国运回日本，并在日本城市设立了志愿者招募办公室，占领当局对此毫无举动。


.<br>
（美国与印尼、台湾和澳大利亚关系降温）
";

/* Original: 
$interventionchinenationaliste="
The USA accepted our Veto, but to the world's surprise, KMT troops landed in Busan to help south korea !!!<br>
That chinese interventionism could not have been possible without the american's help and permission...<br>
Pacific states are worried that this will lead communist china to declare war on South Korea .<br>
The US administration says it condemns but understands this intervention, (which however could only be done with the US maritime means)...
";
*/
$interventionchinenationaliste="
美国接受了我们的否决，但令世界惊讶的是，国民党军队登陆釜山帮助韩国！！！<br>
没有美国的帮助和允许，台湾的干预是不可能的……<br>
太平洋国家担心这会导致共产中国对韩国宣战。<br>
美国政府对这种干涉进行谴责，但同时又表示理解（尽管国民党军队只能在美国的海上支援下登陆）
";

/* Original: 
$pasinterventionusa="
With our veto and the non-intervention of the USA, The South Korean regime appears to be condemned ...
";
*/
$pasinterventionusa="
由于我们的否决和美国的不干涉，南韩政权似乎已被判了死刑。
";

$titre1950o2="空席政策";
/* Original:
$texte1950o2="
With the UN's consent, the imperialists and their lackeys rushed right into our korean trap !";
*/
$texte1950o2="
经联合国批准，帝国主义者和他们的走狗一头冲进我们的朝鲜陷阱！";
//////////////////////////////////////////////////////
// ANNEE 1950 MAJ CHINE
/////////////////////////////////////////////////////

// EVT P

$titre1950p="苏联老大哥";
/* Original: 
$texte1950p="
Negotiations for a friendship treaty between China and the USSR turn out to be particularly complicated.<br>
China has only one potential partner for obtaining access to armament and industrialise itself: Stalin is perfectly aware of this fact.<br>
The secret clauses in the treaty foresee that Manchuria and Xinjiang will be considered as part of the Soviet sphere of influence where the USSR will enjoy a complete and exclusive access to the resources of these regions which are the richest in minerals across all China.<br>
No foreign power ever secured such advantages, even during the concession territories times!<br>
Fortunately, these clauses are secret...<br>
In exchange for our goodwill, the USSR will offer an aid to buy Soviet military equipment and restart a Chinesee armament industry.<br>
The influence of the USSR over the Chinese Communist Party (CCP) is significant; Mao even lives in a state of quasi-house arrest in Moscow...<br>
Faced with these conditions, it seems difficult to oppose our old Soviet ally.
";
*/
$texte1950p="
涉及《中苏友好同盟互助条约》签订的谈判变得异常复杂。<br>
若要获取武器和促进工业化，中国有且只有一个潜在合作伙伴————而斯大林显然清楚地认识到这一点。<br>
条约中的秘密条款规定，苏联将把东北和新疆地区————全中国最丰饶的矿产之乡，纳入其势力范围，并对这些区域中的自然资源享有完全排他性的使用权....<br>
即便是在租借殖民时代，都没有任何外国势力能够获取如此优渥的条件！<br>
幸运的是，这些条款都是秘而不宣的...<br>
作为与我们善意的交换，苏联将提供援助以便我们能够购买苏制武器装备并重启中国的军事工业。<br>
苏联对中国共产党施加着巨大的影响力，在访问莫斯科期间，毛泽东甚至生活于准软禁状态中...<br>
面对这些开价条件，看起来我们似乎很难与老盟友作对...
";

$choix11950p="爽快签约，合作愉快！";
// Original: $choix11950ptitle="You gain 10% in military superpower score and +$5 in investment in military-industrial complex";
$choix11950ptitle="你获得10%的超级大国指数，并在军工复合体（工业政策）建设中投入$5预算";

// Original: $choix21950p="Let us negotiate toe to toe for better conditions";
$choix21950p="让我们通过面对面谈判以争取更好的条件";
// Original: $choix21950ptitle="Sharp decrease in maoism: Stalin is actively looking to replace Mao";
$choix21950ptitle="毛主义值急剧下降————斯大林正在积极寻求取代毛泽东";


$titre1950p1="中苏友好同盟互助条约";
/* Original: 
$texte1950p1="
We just signed an import treaty with the Soviet big brother.<br>
Under the informed supervision of the great Stalin, China will be able to develop its industry and fight the imperialists in Asia!<br>
May Stalin live 10,000 years!
";
*/
$texte1950p1="
我们刚和苏联老大哥签署了这项重要条约。<br>
在伟大的斯大林的关照与监督下，中国将能够发展它的工业并与亚洲的帝国主义者们作斗争！<br>
祝斯大林万寿无疆！
";



$titre1950p2="友好谈判";
/* Original: 
$texte1950p2="
Negotiations keep going in a congenial and easy-going atmosphere.<br>
Completely cutt off from the rest of the world, the Soviets use thousand stratagems to prevent Mao from even getting in touch with the other communist parties' representatives in the world; the Chinese delegation tries hard to defend its positions...<br>
We drew closer to the United Kingdom which recognised the PRC and leaked to the outer world the rumour of the house arrest situation of Mao.<br>
The Soviets are investigating to identify the American and British spies in the entourage of our communist party leaders...<br>
Soviet agents who worked with the PRC were arrested, including Mao's own physician: we have not heard of them for a while...
";
*/
$texte1950p2="
谈判始终保持着愉快随和的气氛。<br>
但即便是在毛泽东被软禁、与世隔绝的情况下，苏联仍千方百计地阻止他与其他国家和地区的共产党代表会面。而中国代表团正在努力捍卫自己的立场...<br>
值得庆幸的是，我们拉近了与英国的外交关系————他们承认了我们的合法地位，并向外界透露了毛泽东遭到软禁的传闻。<br>
苏联人正努力调查我党领导人随行人员中的英美间谍...<br>
与中国共事的苏联特工们被捕了，其中也包括毛泽东本人的医生————我们已经有一段时间没他们的消息了...
";

// Original: $negomaosanssucces="... We eventually accepted with joy the conditions set by our ally";
$negomaosanssucces="...最终，我们还是"愉快"地接受了我们的盟友的开出的条件。";
// Original: $negomaoavecsucces="However, we manage to limit concessions to the Soviets on our raw materials (Budget +$5)";
$negomaoavecsucces="然而，我们得以设法限制了苏联人在原材料方面的特权（预算 +$5）。 ";

// EVT Q

$titre1950q="集体化";
/* Original: 
$texte1950q="
Large chunks of the Chinese economy are still running \"as before\", just being supervised by the party.<br>
This situation cannot be left \"as it is\".<br>
It is now time to radically reform China!<br>

";
*/
$texte1950q="
中国的经济在很大程度上仍旧是依照封建自然经济运行，唯一的区别仅在于这是在党的监督下进行的。<br>
这种情况决不可置之不理。<br>
彻底革新中国，正在此时！<br>

";

$choix11950q="让我们推行集体化！(荣誉分数 +100)";
$choix11950qtitle="恭喜！";

$choix21950q="让我们循序渐进。(荣誉分数 -25 / 预算 +$5)";
// Original: $choix21950qtitle="Forte baisse du Maoisme, augmentation du budget mensuel de 5$";
$choix21950qtitle="急剧削减毛主义值；每月预算+$5";

$titre1950q1="集体化";
/* Original: 
$texte1950q1="
Collectivising our economy will enable us to go over imperialist economies!<br>
Thanks to the reforms, China will be able to supply alone the communist sister-countries.
";
*/
$texte1950q1="
集体化将使我们的经济逐步赶超那些帝国主义者！<br>
多亏了这项改革，现在中国能够自力援助共产主义姊妹国家！
";

$titre1950q2="非完全集体化";
/* Original: 
$texte1950q2="
Priority was given to fighting the bandits who wreck havoc in the countryside.<br>
Shops and private workshops are invited to continue their work as before, nationalisation and collectivisation of these activities will not take place before a few years.<br>

";
*/
$texte1950q2="
剿灭那些在乡村地区兴风作浪为非作歹的匪患是第一要务。<br>
企业和私人作坊被允许像往常一样继续运营，对于这些经济活动的国营化和集体化将被推迟到数年以后。<br>

";


// EVT R

$titre1950r="解放西藏";
/* Original: 
$texte1950r="
The Tibetan Kashag, taking advantage of the civil war, seceded from China...<br>
The Tibetans began proceedings with the USA and the UNO to be recognised as a State in its own right!<br>
This situation cannot be tolerated any longer: it is time to free Tibet!<br>
The small Tibetan army is no match for the PLA but it may be preferable to put a halt to our advance before we reach Lahassa and demand a \"peaceful liberation\" of Tibet.<br>
";
*/
$texte1950r="
西藏噶厦（藏区地方政府）利用中国陷入内战的时机从中央政府的统治中脱离出来...<br>
这些藏人甚至开始向英国和美国提议承认其“独立”地位！<br>
决不可容忍这种情形被拖延下去————解放西藏时机已至！<br>
藏区的小股正规军绝非解放军的对手...但在军队到达拉萨之前，最好停止前进，在这种有利条件下与西藏就和平解放谈判。<br>
";


$choix11950r="让我们以武力解放西藏！";
$choix11950rtitle="你将以武力手段解放西藏";

$choix21950r="西藏必须和平解放";
// Original: $choix21950rtitle="This should take longer but earn you more prestige";
$choix21950rtitle="这个过程将持续更久，不过会给你带来更多额外的荣誉分数";

$titre1950r1="解放西藏";
/* Original: 
$texte1950r1="
General Zhang Guohua, leading 40,000 men, started the liberation of Tibet.<br>
No compromise can be done in preserving the territorial integrity of China!
";
*/
$texte1950r1="
张国华将军带领四万官兵出征解放西藏。<br>
我们在维护中国领土完整的问题上绝不作任何妥协！
";


$titre1950r2="西藏得以和平解放";
/* Original: 
$texte1950r2="
Our troops inflicted a crushing defeat on the separatists in Chamdo et captured many prisoners, including the commander in chief of the Tibetan army.<br>
The PLA then advanced up to the \"historical\" border of Tibet and unilaterally decreed a truce to allow the Tibetan representatives to start negotiations in order to recognise our sovereignty over Tibet.<br>
";
*/
$texte1950r2="
我方部队在昌都使那些分离主义者一败涂地，同时俘虏了众多战俘，其中包括藏军总司令。<br>
解放军部队随即挺进至西藏的"历史边界"，并单方面宣布休战使西藏代表得以展开谈判进而承认我们对西藏的主权。<br>
";


// EVT S

$titre1950s="援越前线高平省";
/* Original: 
$texte1950s="
The Viet Minh, having training camps in China and being supplied by us, could evolve from a guerrilla force into a true liberation army with a real firepower.<br>
The 200km border between Vietnam and China would be impossible to defend by the French imperialists if we decide to support the Viet Minh.
";
*/
$texte1950s="
在位于我方境内的训练营地和直援型补给的支撑下，越盟部队可以从一支游击力量进化为一支拥有正规军火力的越南解放军。<br>
如果我们决定支持越南独立同盟会，法帝国主义者是不可能守卫得了中越间200km长的边境线的。
";

$choix11950s="让我们支援并补给越盟部队 (-$25)";
// Original: $choix11950stitle="Will improve your relations with the Viet Minh and grant it the traits Extraterritorial Base and Heavy Weapons; will deteriorate your relations with France";
$choix11950stitle="这将提高你与越盟游击队的关系，并赋予其境外基地和重型武器特质；你与法国的关系恶化";

$choix21950s="让他们自行战斗";
$choix21950stitle="没有影响";

$titre1950s1="援越前线高平省";
/* Original: 
$texte1950s1="
Outflanked by a mobile enemy, properly trained and now enjoying a real firepower, the imperialists were forced to abandon northern Vietnam!<br>
This defeat marks a turning point in this war.
";
*/
$texte1950s1="
帝国主义者们被极具机动性、训练有素和拥有正规军火力的越军包围了————他们被迫放弃了越南北部！<br>
这次大捷标志着独立战争的转折点。
";


$titre1950s2="援越前线高平省";
/* Original: 
$texte1950s2="
Skirmishes are multiplying in northern Vietnam, a fertile area for all kinds of traffickings that is still fought over.<br>
From our side of the border, the PLA counts the results.
";
*/
$texte1950s2="
越南北部的小规模冲突愈演愈烈，这仍将是各种斗争活动的热点地区。<br>
而在边界的另一半，解放军仅对冲突结果做出了统计与记录。
";


// EVT T

$titre1950t="登陆海南";
/* Original: 
$texte1950t="
The Hainan island is still controlled by significant nationalist forces, benefitting from air support and a war fleet.<br>
This nationalist presence is a continuous threat for the neighbouring Guangdong.<br>
Hainan is a thorn in our side.<br>
Communist partisans present on the island are valliant but their numerical inferiority prevents them from retaking this land alone.<br>
Over 2,000 junks have been requisitioned for a landing but our gallant People's Liberation Army is not yet very much skilled in amphibious warfare... 
";
*/
$texte1950t="
海南岛仍然由一支数量可观的国民党军队控制，他们还拥有空军和一支军事战舰部队的支援。<br>
这些国民党军的存在对邻近的广东地区构成了持续性威胁。<br>
海南无疑是我们的眼中钉。<br>
岛上的共产党游击队员固然英勇无畏，但数量上的劣势阻碍他们独自夺回岛屿。<br>
我们为这次登陆作战征用了超过两千艘舢板，不过我们英勇的人民解放军在两栖登陆作战方面还不是很熟练... 
";


$choix11950t="让我们发动登陆！ (-$25)";
$choix11950ttitle="如果行动成功，西南地区的流寇力量将大幅削减，并且你将获得25荣誉分数";

$choix21950t="让我们加强对游击队的补给！ (-$5)";
$choix21950ttitle="将带来非常局限的削减流寇效果";

$titre1950t1="登陆海南";
$texte1950t1="";

$titre1950t2="琼崖纵队";
/* Original: 
$texte1950t2="
Junks that left during the night start supplying the communist Qiongya column on Hainan island.<br>
With a surprising ease, we manage to infiltrate nationalist defence lines.<br>
Soon, small groups of fighters join on-site forces.<br>
The KMT troops cease to defend the beaches and spread out in inefficient peace enforcement operations.<br>
We have not yet conquered Hainan but, with limited means, we prevent large forces to lead operations in mainland China!
<br><spanstyle=\"font-style:italic;\">--> Small decrease in strength of the Southwest Bandits </span>

";
*/
$texte1950t2="
我们于夜间发出的舢板已开始向海南岛的共产党琼崖纵队输送更多补给。<br>
我方设法渗透进入国军战线，这竟出人意料的轻松。<br>
随船抵达的小股部队就地加入游击力量。<br>
不少国民党军队停止守备海滩，转而被拖入低效的治安战中。<br>
我们尚未解放海南，但我们用有限的手段使大批国军部队被我们牵制在海南岛从而无法袭扰大陆！
<br><spanstyle=\"font-style:italic;\">--> 西南地区流寇力量略有减少。 </span>

";

/* Original: 
$hainansucces="
<strong>Victoire !</strong><br>
Their war fleet weaponry proved highly inefficient against our junks (since their high explosive shells simply go through them without exploding)!.<br>
The KMT forces, scattered and busy with hunting partisans, could oppose nothing more than a weak resistance to our main assault wave.<br>
Their counterattacks shattered against the unyielding will of our valliant soldiers.<br>
Against all odds, we demonstrated that the PLA is perfectly capable of handling a landing!
<br><spanstyle=\"font-style:italic;\">--> Prestige +25 </span>
";
*/
$hainansucces="
<strong>胜利！</strong><br>
他们的作战舰艇武器对我方的舢板效率极低（因为舰炮发射的高爆炮弹引信根本没有被木头船触发，只是简单的贯穿过去而已！） <br>
混乱不堪且忙于清剿游击队的国民党军队根本无力对我们的主攻力量进行有组织的抵抗。<br>
我们英勇的战士凭借坚强的意志彻底粉碎了敌军的反击行动。<br>
解放军战士勇往直前，证明我们完全有能力进行登陆作战！
<br><spanstyle=\"font-style:italic;\">--> 荣誉分数 +25 </span>
";

/* Original: 
$hainanechec="
Our frail junks, despite our heroic sailors, were wiped out by the enemy gunfire and very few could make their way to the beach.<br>
The nationalist aviation and war fleet transformed our failure into a disaster.<br>
We are not yet ready to undertake successful landing operations...
";
*/
$hainanechec="
尽管我们的水手英勇无畏，但我们脆弱的舢板还是被敌方炮火摧毁殆尽，仅有极少数幸存者能够抵达滩头。<br>
国民党的空中力量和作战舰艇使我们的失败演变成为一场灾难。<br>
我们尚未做好进行成功登陆行动的充分准备...
";

// EVT U

$titre1950u="金日成的统一梦";
/* Original: 
$texte1950u="
Kim Il-sung, the North Korean leader, only dreams about unifying the peninsula by force.<br>
The Soviets trained and equipped the North Korean army into a formidable war machine.<br>
Moscow supports this project but there is a risk that the American intervene in this conflict under preparation.<br>
Final authorisation will only be given you accept to intervene in Korea should the need arise.
";
*/
$texte1950u="
北朝鲜领导人金日成唯一的梦想便是以武力统一整个朝鲜半岛。<br>
苏联人通过提供训练和武器装备将朝鲜军队打造成了一台强力的战争机器。<br>
莫斯科支持这项计划，但也有美国人于该计划准备阶段就介入冲突的风险。<br>
你在我们是否介入并干预朝鲜半岛事务的问题上拥有最终决定权和批准权。
";

$choix11950u="我们迫不及待！";
// Original: $choix11950utitle="Moscow will equip you and your military superpower score will increase by +5%";
$choix11950utitle="你的超级大国指数将 +5%，并且莫斯科将在随后你干预战争时武装你";

$choix21950u="我们自顾不暇...";
// Original: $choix21950utitle="Will deteriorate your relations with North Korean and decrease your maoism";
$choix21950utitle="将恶化你与朝鲜的外交关系并降低毛主义值";

// Original: $titre1950u1="NORTH KOREAN INVADES THE SOUTH!";
$titre1950u1="祖国解放战争！";
/* Original: 
$texte1950u1="
This morning, 6 North Korean divisions crossed the 38th parallel.<br>
A significant part of the South Korean troops was on leave and the communist attack took everybody by surprise!<br>
The country should fall like a ripe fruit in Kim Il-sung's hands.<br>
Dismay prevails in Washington: an American intervention was decided!
";
*/
$texte1950u1="
今天上午，朝鲜人民军的6支军团越过了三八线。<br>
南韩军队中有相当一部分人不在前线，共产党的进攻让所有人都感到意外！<br>
预计这个国家将很快像一颗成熟的果实一样落入金日成的手中。<br>
但从华盛顿传来了令人沮丧的消息————美国决定干预此战！
";


$titre1950u2="下次再说吧";
/* Original: 
$texte1950u2="
The Soviets, not willing to get directly involved in a Korean conflict that could degenerate into full-blown world war, decided to suspend their green light to the liberation of southern Korea.<br>
Kim Il-sung helds Mao personally liable of this situation and relations with North Korea strained.
";
*/
$texte1950u2="
苏联人不愿意参与有可能演变为全面世界大战的朝鲜冲突，因此决定停止对金日成解放南朝鲜的事业开绿灯。<br>
金日成认为毛泽东个人应对这种境况负责，因此中朝关系十分紧张。
";

// EVT V

$titre1950v="西北匪患";
/* Original: 
$texte1950v="
Northwest China is still infested with bandits and nationalist troops.<br>
General Ma Bufang called for an islamic insurrection and declated he will never surrender to communists.<br>
Ma's men are seasoned veterans and their cavalry grants them superior mobility.<br>
The operational theatre is immense and this rebellion could last for years using guerrilla tactics.  
";
*/
$texte1950v="
西北地区仍然游荡着大量的土匪和军阀军队。<br>
军阀马步芳在台湾通过电台号召宗教分子展开暴动，并宣布永远不会向共产党投降。<br>
马步芳的手下尽是些久经沙场的老兵，他们的骑兵也提供了出色的机动性。<br>
剿灭行动异常艰巨，这些叛乱很可能会持续数年。  
";


$choix11950v="让我们开展大规模剿匪行动 (-$10)";
// Original: $choix11950vtitle="Should decrease the strength of Northwest Bandits";
$choix11950vtitle="将削弱西北流寇的力量";

$choix21950v="让我们寻求苏联人的帮助 (-$10 / 荣誉点数 -25)";
// Original: $choix21950vtitle="Will increase maoism";
$choix21950vtitle="将增长毛主义";

$titre1950v1="西北匪患";
/* Original: 
$texte1950v1="
The bandits avoid direct confrontation and our troops get regularly hit by deadly ambushes.<br>
Our secret services indicate us that these bandits are being materially supported by the Kuomintang through parachuted weapons and supplies.<br>
<br><spanstyle=\"font-style:italic;\">--> Small decrease in strength of the Northwest Bandits </span>
";
*/
$texte1950v1="
土匪们避免正面作战，而我们的部队经常遭遇致命的伏击。<br>
我们的秘密情报战线显示，这些土匪通过国民党的空投武器与补给得到了实质性的支持。<br>
<br><spanstyle=\"font-style:italic;\">--> 西北流寇力量略微下降。 </span>
";


$titre1950v2="宝贵的援助";
/* Original: 
$texte1950v2="
The bandits avoid direct confrontation and our troops get regularly hit by deadly ambushes.<br>
Our secret services indicate us that these bandits are being materially supported by the Kuomintang through parachuted weapons and supplies.<br>
The Soviet aviation does wonderful things in spotting and machine-gunning rebels.<br>
The USSR takes advantage of our request for intervention to reinforce in presence and secure its econoic interests in Northwestern China.<br>
Relations between Stalin and Mao are at their highest.
<br><spanstyle=\"font-style:italic;\">--> Sharp decrease in strength of the Northwest Bandits </span>
<br><spanstyle=\"font-style:italic;\">--> Mao's position in the CCP is reinforced</span>
<br><spanstyle=\"font-style:italic;\">--> -25 Prestige </span>
";
*/
$texte1950v2="
土匪们避免正面作战，而我们的部队经常遭遇致命的伏击。<br>
我们的秘密情报战线显示，这些土匪通过国民党的空投武器与补给得到了实质性的支持。<br>
苏联空军表现优异，他们通过侦查发现进而空中扫射的方式与这些匪徒作战。<br>
苏联人也充分利用了我方向他们发出的干预请求，以增强其在西北地区的存在并确保其经济利益。<br>
斯大林与毛泽东之间的关系处于最高水平。
<br><spanstyle=\"font-style:italic;\">--> 西北流寇力量大幅下降 </span>
<br><spanstyle=\"font-style:italic;\">--> 毛泽东在中国共产党内的地位得以加强</span>
<br><spanstyle=\"font-style:italic;\">--> -25  荣誉分数 </span>
";

// EVT W

$titre1950w="西南匪患";
/* Original: 
$texte1950w="
Southeastern China has been plagued with gangs of bandits for immemorial times.<br>
Nowadays, these groups are reinforced by nationalist troops left behind during the retreat to Tawian.<br>
This alliance between bandits and KMT troops is a clear mark of our enemies' perverted nature.<br>
The people who endures ill-treatment from these gangs should be willing to support us and help in wiping out the evil.<br>
";
*/
$texte1950w="
中国西南地区受匪帮荼毒的历史十分久远。<br>
如今，这些匪帮得到了未能逃至台湾的国军残兵败将的进一步加强。<br>
土匪和国民党部队之间的结合充分暴露了我们敌人的堕落本性。<br>
当地苦匪帮久矣且饱受摧残的人民一定非常乐意支持并帮助我们清剿这些邪恶势力。<br>
";


// Original: $choix11950w="Let launch a great campaign(-$25)";
$choix11950w="让我们开展一场宏大的剿匪战役 (-$25)";
// Original: $choix11950wtitle="Should decrease the strength of Southwest Bandits";
$choix11950wtitle="将削弱西南流寇的力量";

// Original: $choix21950w="Let us concentrate on defending the cities and the lines of communications (-$5)";
$choix21950w="让我们集中精力保卫城市和交通线 (-$5)";
$choix21950wtitle="对西南流寇力量几乎没有影响";

$titre1950w1="西南匪患";
/* Original: 
$texte1950w1="
Our campaign enabled the eradiction of numerous bandits.<br>
The remaining gangs, coming down to small groups operatings in remote locations, are nothing more than marginal nuisance.
<br><spanstyle=\"font-style:italic;\">--> Sharp decrease in strength of Southwest Bandits</span>
";
*/
$texte1950w1="
我们开展的剿匪战役铲除了诸多匪患。<br>
那些匪帮残余被削弱成为只能在偏远地区活动的小团伙，仅仅是微不足道的麻烦。
<br><spanstyle=\"font-style:italic;\">--> 大幅削弱西南流寇的力量</span>
";


$titre1950w2="西南匪患";
/* Original: 
$texte1950w2="
The bandits now seem to avoid the large cities and the main lines of communications; Southwestern China's economy should finally be able to revive.<br>
However, some 60% of said territory is still not under our control and bandits enjoy a complete freedom of movement.<br>
";
*/
$texte1950w2="
现在看来，这些土匪正有意避开大城市和交通干道进行活动，最终西南地区的经济应该能够复苏起来。<br>
然而，当下仍有约60%的西南领土不受我们控制，土匪们在这些地域实际上是能够畅通无阻、横行霸道的。<br>
";

// EVT X

$titre1950x="镇压反革命运动";
/* Original:
$texte1950x="
It is now time to get rid of the last remains of the former nationalist regime.<br>
Class enemies, bandits, spies... millions of counterrevolutionaries are sabotaging the efforts of the People's Republic of China.<br>
A campaign to suppress counterrevolutionaries is necessary!<br>
Considering the extent of their corruption, arrests and mass killing will be necessary: provinces will be given suppression objectives.<br>
It is crucial that these executions are public and that the people attend them!<br>
However, we may want to spare the former Kuomintang high-ranking executives, in order to foster defections among Taiwan nationalists senior-levels?
";
*/
$texte1950x="
是时候清除前国民党政权的最后遗毒了。<br>
反动派，土匪，特务...数百万反革命分子仍在不遗余力地破坏新生的中华人民共和国。<br>
现在必须开展一场镇压反革命的运动！<br>
出于对他们堕落程度的考虑，大规模逮捕与处决将是十分必要的————各省将被赋予具体的镇压指标。<br>
死刑处决必须公开执行杀一儆百，并且人民也将参与这一过程。这一点至关重要！<br>
但是我们可能可以放过前国民党高层人物，以统战尚在台湾地区的国民党高层并鼓励投诚行为。
";


$choix11950x="让我们开展大规模镇反 (荣誉点数 -25)";
// Original: $choix11950xtitle="Will sharply increase maoism, decrease the strength of bandits and reinforce the Taiwanese stability";
$choix11950xtitle="毛主义大幅增长，削弱流寇力量，但也会使台湾的稳定度增强。";

// Original: $choix11950xtitle="Will sharply increase maoism, decrease the strength of bandits and reinforce the Taiwanese stability";
$choix21950x="让我们开展镇反，但放过一些前国民党要员 (荣誉点数 -25)";
// Original: $choix21950xtitle="Will increase maoism, decrease the strength of bandits et decrease the Taiwanese stability";
$choix21950xtitle="毛主义增长，削弱流寇力量，同时降低台湾的稳定度。";

$choix31950x="让我们开展针对性和有限的镇反";
// Original: $choix31950xtitle="Light erosion of maoism";
$choix31950xtitle="毛主义略微降低";

$titre1950x1="镇压反革命运动";
/* Original: 
$texte1950x1="
The great campaign was just launched!<br>
The Soviet experts helped us organising our own gulag system: the Laogai.<br>
The class enemies who have not been executed are sent into re-education through labour camps.<br>
None of the former nationalists slipped through the cracks: these spies will not longer be detrimental to our cause!
";
*/
$texte1950x1="
伟大的运动迈出了它的第一步！<br>
苏联专家指导我们建立了自己的古拉格系统————劳改营。<br>
尚未被处决的阶级敌人统统被送去"劳动改造"。<br>
那些前国民党反动派没有一个可以逃离我们的手掌心————这些特务将不再对我们的事业造成阻碍！
";


$titre1950x2="镇压反革命运动";
/* Original: 
$texte1950x2="
The great campaign was just launched!<br>
The Soviet experts helped us organising our own gulag system: the Laogai.<br>
The class enemies who have not been executed are sent into re-education through labour camps.<br>
Important KMT members who defected to us are on the contrary treated with respect and honour. We already received word from some high-ranking executives in Taiwan of their wish to return to mainland China.<br>
";
*/
$texte1950x2="
伟大的运动迈出了它的第一步！<br>
苏联专家指导我们建立了自己的古拉格系统————劳改营。<br>
尚未被处决的阶级敌人统统被送去"劳动改造"。<br>
与之相反，那些向我们投诚的前国民党要员则受到尊重和优待。我们已经从一些在台国民党高官那里得到了他们希望回归祖国大陆的消息。<br>
";


$titre1950x3="镇压反革命运动";
/* Original: 
$texte1950x3="
The great campaign was just launched!<br>
No less than 5,000 class enemies are suppressed this way.<br>
Criticisms against Chairman Mao are increasingly stronger and more open within the party. However, his detractors are divided: did he do too much or not enough?
";
*/
$texte1950x3="
伟大的运动迈出了它的第一步！<br>
我们通过这种手段镇压了至少5000名阶级敌人。<br>
党内对毛主席的批评越来越强烈和公开。但针对他的批评者却分野成了两派————他所处理的人是太多了，还是远远不够？
";




// EVTS FRANCE

// EVT Y

// Original: $titre1950y="一个团结的欧洲或者再次陷于战火";
$titre1950y="要么一个团结的欧洲，要么再次陷于战火";
/* Original: 
$texte1950y="
« A united Europe was not achieved and we had war. »<br>
According to this great principle, Robert Schuman, inspired by the Plan Commissioner Jean Monnet, just proposed to Germany and other willing European country to put their coal and steel in common.<br>
This cooperation will create common interests and solidarities between the Europeans.<br>
This process should guarantee peace on the continent.<br>
Negotiations must now begin to prepare a treaty that could be signed next year.
";
*/
$texte1950y="
\"如果一个团结的欧洲没有实现，我们便会再次陷于战火.\"<br>
根据这一伟大的原则，罗伯特·舒曼在计划专员让·莫内的启发下，刚刚向德国和其他有意愿的欧洲国家提议将各国的煤炭和钢铁市场统一起来.<br>
这种合作将让欧洲人团结一致并创造共同利益.<br>
这一进程应能保证欧洲大陆的和平.<br>
现在必须开始谈判，准备一份明年可以签署的条约.
";


// EVT Z

// EVT F

$titre1950z="北朝鲜入侵南韩!";
/* Original: 
$texte1950z="
The North Korean 'army' crossed the 38th parallel.<br>
The situation is preoccupying.<br>
The UNO Security Council just called on its members to provide means to contain the invasion.<br>
As a member of the Security Council, we cannot do less than getting involved in this war, despite our financial difficulties.
";
*/
$texte1950z="
朝鲜的“军队”越过了三八线.<br>
局势着实令人担忧.<br>
联合国安理会刚刚呼吁其成员国提供遏制朝鲜入侵的手段.<br>
作为安全理事会的一个成员，尽管我们有财政困难，我们不得不卷入这场战争.
";

$choix11950z="让我们派一个营去 (预算-5)";
$choix11950ztitle="这会让你参与这场战争并增加你的大西洋主义得分";

// Original: $choix21950z="Let us not go there (Prestige -100)";
$choix21950z="我们不去 (荣誉 -100)";
// Original: $choix21950ztitle="The communists could believe they have free hands, your Atlanticism score decreases";
$choix21950ztitle="共产主义者相信他们可以腾出手来，而你的大西洋主义分数下降了";

$titre1950z1="大韩民国的崩溃";
/* Original: 
$texte1950z1="
The North Korean offensive is so quick and powerful that the American troops are falling back: they must hold a perimeter in Busan at any costs so that further reinforcements can be deployed...<br>
We declared in this context that we would send a warship with a voluntary force of approximately 1,000 men.
";
*/
$texte1950z1="
朝鲜的进攻是如此迅猛有力，连美国军队都被击退:他们现在必须不惜一切代价在釜山守住防线，以便部署进一步的增援部队...<br>
因此，我们宣布将派遣一艘军舰以及一支约为1000人的志愿军前往朝鲜.
";

$titre1950z2="大韩民国的崩溃";
/* Original: 
$texte1950z2="
A significant part of the South Korean troops was on leave and the communist attack took everybody by surprise!<br>
The country should fall like a ripe fruit in Kim Il-sung's hands.<br>
In Washington, dismay is dominant but some war hawks already see there an unhoped for opportunity to drive communism out of Asia.<br>
Our decision not to participate in this war led to a misunderstanding with the United States that we will be long to smooth out.
";
*/
$texte1950z2="
南韩军队中有相当一部分人不在前线，共产党的进攻让大家措手不及!<br>
预计这个国家将很快像一颗成熟的果实一样落入金日成的手中.<br>
在华盛顿，沮丧情绪占主导地位，但一些鹰派却看到了将共产主义赶出亚洲的意外机会.<br>
我们决定不参加这场战争造成了我们与美国之间的误解，消除这种误解需要花费相当长的时间.
";


// EVT AA

// Original: $titre1950aa="执政华尔兹";
$titre1950aa="抢椅游戏";
/* Original: 
$texte1950aa="
Three French governments fell since the begining of summer and this instability does not seem to stop anytime soon.<br>
Is the IVth Republic already on its knees?
<br>
This political instability does not seem to hamper the national reconstruction though, neither does it stop important laws from being voted. The government just had voted a new bill on rent-controlled housing \"Habitations à Loyer Modéré\" (HLM).<br>
And what about the Frenchmen in this picture?<br>
Well, they prefer to follow the Tour de France (at least, this is something they can understand).

";
*/
$texte1950aa="
自夏季伊始，三届法国政府接连倒台，这种不稳定似乎不会很快停止.<br>
法兰西第四共和国已经跪下了吗?
<br>
然而，这种政治不稳定似乎并没有妨碍国家重建，也没有阻止重要法律的投票。政府刚刚投票通过了一项关于租金控制住房的新法案。.<br>
那么这张照片中的法国人呢?<br>
嗯，他们更喜欢追随环法自行车赛(至少这是他们可以理解的).

";


$choix11950aa="夏天到了!";
$choix11950aatitle="无事可报";

// Original: $titre1950aa1="执政华尔兹";
$titre1950aa1="抢椅游戏";
/* Original: 
$texte1950aa1="
<br><br>
<span style=\"font-style:italic;\">
	As long as your regime is the IVth Republic, you have a disadvantage to all your diplomatic actions.<br>
	(When the representatives you are dealing with keep changing, you can hardly establish a lasting dialogue)
</span>
Oh look, Ferdi Kübler won the Tour de France!

";
*/
$texte1950aa1="
<br><br>
<span style=\"font-style:italic;\">
	只要你们的政权还处于第四共和国，你的所有外交行动都会受到惩罚.<br>
	(因为当你面对的代表不断变化时，你很难建立一个持久的对话)
</span>
哦，看哪，费尔迪·库布勒赢得了环法自行车赛!

";


// EVT AB

$titre1950ab="反共十字军东征";
/* Original: 
$texte1950ab="
With the war in Korea, it is clear that Communism is a threat to the entire world -- from the Rhine to the Mekong.<br>
Our commitment in Indochina is not a colonial adventure, but a crusade to defend the values of the Western world.<br>
Our American allies only begin to understand this...<br>
They are finally inclined to help us to the height of the threat. This input of cash will greatly discharge us from the costly burden of war while giving a breath of fresh air to our economy.

";
*/
$texte1950ab="
朝鲜战争清楚地表明，从莱茵河到湄公河，共产主义对整个世界产生了威胁.<br>
我们在印度支那的承诺不是一场殖民主义冒险，而是一场捍卫西方世界价值观的十字军远征.<br>
我们的美国盟友现在才开始认识到这一点...<br>
他们最终倾向于帮助我们全面打击这一威胁。美国的资金投入将大大减轻我们沉重的战争负担，同时给我们的经济注入新鲜空气.

";

// Original: $choix11950ab="共产主义去死! (预算+10)";
$choix11950ab="给共产主义死亡! (预算+10)";
$choix11950abtitle="无事可报";

$titre1950ab1="反共十字军东征";
/* Original: 
$texte1950ab1="
This is a very good \"deal\" (as would the Americans say) that we stroke!<br>
Thanks to the African blood and the American dollars, we are capable of fighting a war in Indochina that does not weight too much on the metropolis.
<br>An important question though remains unanswered: what is it that we still really have to do in Indochina?
";
*/
$texte1950ab1="
这是我们达成的一项非常好的“协议”(至少美国人会这么说)!<br>
多亏了非洲人的鲜血和美国人的美元元，我们才有能力在印度支那打一场不会对宗主国造成太大影响的战争.
<br>然而，还有一个重要的问题没有得到回答:我们在印度支那究竟还需要做什么?
";

// EVT AC

$titre1950ac="苏联调停印度支那战争";
/* Original: 
$texte1950ac="
Regarding the war in Indochina, Moscow has proposed an offer of mediation.<br>
They suggest dividing the country into two zones, which would be reunited after a referendum in two years' time.<br>
The Viet Minh would be inclined to accept such an arrangement.<br>
Is this an unanticipated opportunity to end this war with dignity -- or is it nothing more than a complete surrender in a war that we have not yet lost?

";
*/
$texte1950ac="
莫斯科就印度支那战争向我们提出调解建议.<br>
他们建议将国家划分为两个区域，在两年后通过公投重新统一.<br>
越盟将倾向于接受这种安排.<br>
这是一个我们未曾料到的可以有尊严地结束战争的机会，还是仅仅是一场我们还没有输掉的战争的彻底投降?

";

// Original: $choix11950ac="让我们缔造和平 (威望-25 )";
$choix11950ac="我们同意和平 (威望-25)";
$choix11950actitle="越南分裂成两个独立的实体";

// Original: $choix21950ac="打倒亚洲的共产主义! ";
$choix21950ac="打倒亚洲的共产主义!";
$choix21950actitle="我们的大西洋主义分数增加";

$titre1950ac1="印度支那迎来和平";
/* Original: 
$texte1950ac1="
It was about time to stop this war and the peace agreements signed in Geneva validate the creation of two political entities in Indochina.<br>
Elections are supposed to take place in two years but some obervers already lost faith in the chance for these to take place.<br>
Back home, the French people does not understand: how is it that we made so much fuss about Indochina to end up with such a poor result?

";
*/
$texte1950ac1="
现在是结束这场战争的时候了，在日内瓦签署的和平协议证明了在印度支那建立两个政治实体的合法性.<br>
选举应在两年内举行，但一些观察人士已经对选举能否举行失去了希望.<br>
回到国内，法国人民对此感到不理解——为什么我们在印度支那问题上如此小题大做，结果却如此缺乏可陈?

";


$titre1950ac2="战斗仍将继续";
/* Original: 
$texte1950ac2="
Communism in Asia has shown that it does not want peace -- we must put a stop to it in Indochina!

";
*/
$texte1950ac2="
亚洲的共产主义表明它不想要和平:我们必须把它遏制在印度支那!

";









?>