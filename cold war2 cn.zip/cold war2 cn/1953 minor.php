﻿<?php



$eisenhower="德怀特·艾森豪威尔";
$kroutchev="尼基塔·赫鲁晓夫";

$annee53evt1="美国：处决朱利叶斯和艾瑟尔·罗森堡夫妇";
$annee53evt1detail="结束苏联对原子弹和氢弹谍报研究的加成";

$annee53evt2="捷克斯洛伐克：民众骚乱";
$annee53evt2detail="稳定度下降";

$annee53evt3="玻利维亚：土地改革";
$annee53evt3detail="增长稳定度和与美国关系恶化";

$annee53evt4="玻利维亚：经济集体化";
$annee53evt4detail="该国经济类型转变为集体经济";

$annee53evt5="苏联：结束改造自然的宏伟工程";
$annee53evt5detail="工业政策预算降至0$";

$annee53evt6="苏联：斯大林逝世";
$annee53evt6detail="领导人更迭";

$annee53evt7="埃及：禁止政党";
$annee53evt7detail="埃及现在是一个独裁国家";



$annee53evt8="法国：新政府";
$annee53evt8detail="它是由令人称奇的勒内·梅耶领导的！";

$annee53evt9="法国：库朗计划，预计每年新增24万个住宅";
$annee53evt9detail=重建进度 +2";

$annee53evt10="法国：新政府";
$annee53evt10detail="你猜怎么着？前政府没能持续多久。这个又能持续多长时间？";

$annee53evt11="法国：公共服务领域的大罢工浪潮（-5$）";
$annee53evt11detail="拉尼埃政府的政策不受公务员青睐";

$annee53evt12="法国：皮埃尔·普雅德创建店主和工匠防卫联盟（UDCA）";
$annee53evt12detail="哦，小工匠，增值税会杀了你";

$annee53evt13="勒内·科蒂赢得法国总统选举";
$annee53evt13detail="不要和真正负责国家事务的部长会议主席混淆";








?>