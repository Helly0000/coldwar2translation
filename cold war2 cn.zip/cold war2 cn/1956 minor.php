﻿<?php

$annee56evt1="苏联：贝利亚死亡，赫鲁晓夫接替他";
$annee56evt1detail="领导人更迭！";

$kroutchev="尼基塔·赫鲁晓夫";

$annee56evt2="赫鲁晓夫谴责斯大林罪行！";
$annee56evt2detail="他开启了潘多拉魔盒";

$annee56evt3="赫鲁晓夫倡导和平共处方针（荣誉+300） ";
$annee56evt3detail="苏联荣誉+300，大幅降低斯大林主义";

$annee56evt4="苏南和解";
$annee56evt4detail="大幅改善苏联-南斯拉夫关系";

$annee56evt5="中国：百花齐放运动";
$annee56evt5detail="稳定度大幅下降";

$annee56evt6="波兰：波兹南骚乱";
$annee56evt6detail="稳定度下降";

$annee56evt7="玻利维亚：内战危机";
$annee56evt7detail="稳定度大幅下降";

$annee56evt8="匈牙利：布达佩斯暴动（苏联荣誉-150）";
$annee56evt8detail="暴动被严厉镇压，斯大林主义增长";

$annee56evt9="波兰：哥尔穆卡批判斯大林主义并承诺民主改革！";
$annee56evt9detail="斯大林主义 -2";

$eisenhower="德怀特·艾森豪威尔";

$annee56evt10="美国：艾森豪威尔赢得总统选举";
$annee56evt10detail="德怀特·艾森豪威尔总统";

$annee56evt11="联邦德国：盖伦组织加入德国联邦情报局";
$annee56evt11detail="盖伦组织终止运作";

$annee56evt12="苏丹独立";
$annee56evt12detail="一个新的国家";

$annee56evt13="喀麦隆：反对派选择武装斗争";
$annee56evt13detail="一支游击队出现在喀麦隆";

$annee56evt14="摩洛哥独立！";
$annee56evt14detail="一个未来的新盟友？";

$annee56evt15="突尼斯独立！";
$annee56evt15detail="一个未来的新盟友？";

$annee56evt16="阿尔及利亚：法国调集特遣队";
$annee56evt16detail="法国在阿尔及利亚军事力量增加";

$annee56evt17="洪都拉斯：禁止共产党";
$annee56evt17detail="亲苏反对派消失";

$annee56evt18="古巴：一小撮义军藏身于马埃斯特腊山";
$annee56evt18detail="他们只有区区不到二十人，何以为患？";

$annee56evt19="西藏：武装叛乱";
$annee56evt19detail="一支藏独游击队出现";

//Manquent les 20 à 23
$annee56evt24="阿尔及利亚：苏马姆民族解放阵线大会";
$annee56evt24detail="民族解放阵线终于消除一些负面特质";

// EVTS MINEURS FRANCE 56

$annee56evt20="摩洛哥：里夫地区交火";
$annee56evt20detail="一支游击队组织出现";

$annee56evt21="摩洛哥：严峻的工会动乱（稳定-1）";
$annee56evt21detail="中情局似乎在幕后操纵：一个亲美反对派出现";

$annee56evt22="法国：居伊·摩勒部长会议主席";
$annee56evt21detail="新部长会议主席";

$annee56evt23="阿尔及利亚：居伊·摩勒在阿尔及尔被西红柿“迎接”";
$annee56evt23detail="稳定度-1";

$annee56evt24="阿尔及利亚：苏马姆民族解放阵线大会";
$annee56evt24detail="民族解放阵线消除特质：谈判、观望和内部分歧";

























?>