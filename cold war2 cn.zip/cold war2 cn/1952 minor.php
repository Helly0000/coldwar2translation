﻿<?php

$annee52evt1="<strong>联合王国第一颗原子弹试爆成功！</strong>";
$annee52evt1detail="该国拥有核武器，再也不能被入侵了";

$annee52evt2="苏联：德国科学家被批准回归民主德国";
$annee52evt2detail="7号部门停止运作，苏联科研加成消失 ";


$annee52evt3="玻利维亚：选举危机";
$annee52evt3detail="稳定度下降";

$annee52evt4="玻利维亚：土地改革";
$annee52evt4detail="与莫斯科关系改善；与华盛顿关系恶化";

$annee52evt5="结束马歇尔计划";
$annee52evt5detail="结束马歇尔计划";

$annee52evt6="埃及：革命 ";
$annee52evt6detail="军队废黜苏丹法鲁克一世";

$annee52evt7="英军撤离苏伊士运河";
$annee52evt7detail="英国不再在埃及驻军";

$annee52evt8="德怀特·艾森豪威尔当选美国总统！";
$annee52evt8detail="他将于一月宣誓就职";

$annee52evt9="委内瑞拉：重大修宪";
$annee52evt9detail="该国转变为独裁政体";

$annee52evt10="印度支那： 纳产之战";
$annee52evt10detail="游击队损失力量";

$annee52evt11="突尼斯：宾泽特骚乱";
$annee52evt11detail="急剧降低稳定度，一支游击队出现";

$annee52evt12="肯尼亚：茅茅起义";
$annee52evt12detail="一支部落游击队出现在肯尼亚";

$annee52evt13="摩洛哥：卡萨布兰卡骚乱";
$annee52evt13detail="稳定度下降";

$annee52evt14="日本：旧金山和约生效";
$annee52evt14detail="结束盟军在日军事管制";

$annee52evt15="伊拉克：罢工和社会动荡";
$annee52evt15detail="稳定度下降";


// 
$annee52evt16="法国：富尔政府";
$annee52evt16detail="这是一架飞机吗？这是一只鸟吗？不，这是一个新政府！";

$annee52evt17="法国：安托万·比内组建政府";
$annee52evt17detail="又一个？你一定在开玩笑吧！";

$annee52evt18="法国：安托万·比内启动一笔巨额贷款";
$annee52evt18detail="（这样他就可以填补自由主义政策导致的国家预算亏空）重建进度+2";

$annee52evt19="法国：通货膨胀得到治理";
$annee52evt19detail="重建进度+2";











?>