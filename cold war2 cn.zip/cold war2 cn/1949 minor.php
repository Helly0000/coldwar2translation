﻿<?php

$annee49evt1="该国加入北大西洋公约（NATO）";
$annee49evt1detail="与美国签署防御协议";
$annee49evt1title="与美国签署防御协议";

$annee49evt2="西德：德意志联邦共和国宣告成立";
$annee49evt2detail="这个国家现在是共和国";

$annee49evt3="印度尼西亚：伊斯兰叛乱";
$annee49evt3detail="一支新游击队出现";

$annee49evt4="哥斯达黎加：军队被废除";
$annee49evt4detail="该国武装力量被设为0";

$annee49evt5="东德：德意志民主共和国宣告成立";
$annee49evt5detail="这个国家现在是人民共和国";

$dewey="托马斯·杜威";

$annee49evt9="索马里处于意大利统治下";
$annee49evt9detail="如上所述";

// MODE FRANCE

$annee49evt7="老挝加入法兰西联盟";
$annee49evt7detail="我们来了！";

$annee49evt8="柬埔寨加入法兰西联盟";
$annee49evt8detail="我们来了！";

$annee49evt9="索马里成为意大利托管地";
$annee49evt9detail="如上所述";

?>