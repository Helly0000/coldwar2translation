﻿<?php

// EVTS 1979

$annee79evt1="乍得：内战以更大规模重启";
$annee79evt1detail="总理的北方军正在与总统的乍得武装部队交战";

$annee79evt2="乌干达：利比亚派遣部队前来拯救政权";
$annee79evt2detail="1利比亚部队部署在乌干达";

$annee79evt3="乍得：民族和解会议";
$annee79evt3detail="稳定度增长2级，游击队获得“谈判”特质";

$annee79evt4="乍得：恩贾梅纳在燃烧";
$annee79evt4detail="一个团体（乍得人民解放运动）感觉在谈判桌上被不公正地遗忘了";

$annee79evt5="乍得：利比亚军队介入提贝斯提";
$annee79evt5detail="这是战争！ ";

$annee79evt6="乍得：拉各斯民族和解大会";
$annee79evt6detail="稳定度增长2级，游击队获得“谈判”特质";

$annee79evt7="印度洋：一颗卫星探测到可能是核试验的双重闪光";
$annee79evt7detail="是谁在研发核武器呢？";

$annee79evt8="尼日利亚：军政府还政于民";
$annee79evt8detail="一个民选政府？天哪！";

$annee79evt9="反君主制示威震动尼泊尔政权";
$annee79evt9detail="稳定度下降，地方议会将由选举产生：政权转变为立宪君主政体（这有点跳跃，很抱歉…） ";

$annee79evt10="粮食援助涌入柬埔寨";
$annee79evt10detail="柬埔寨现在有NGOs";

$annee79evt11="韩国：民众游行抗议独裁政权";
$annee79evt11detail="稳定度 -1";

$annee79evt12="泰国：该国因老挝和柬埔寨难民潮影响而不稳";
$annee79evt12detail="稳定度 -1和NGOs抵达该国";

$annee79evt13="<strong>苏联军事干预阿富汗</strong>";
$annee79evt13detail="稳定度+2：苏联安置一个傀儡候选人掌权";

$annee79evt14="阿富汗：部分军队转入地下！";
$annee79evt14detail="阿富汗局势可能会变得更加错综复杂：大量游击队出现，其实力为苏军兵力的一半";

$annee79evt15="自由黎巴嫩政府在该国南部宣告成立";
$annee79evt15detail="南黎巴嫩军获得伪国家特质";

$annee79evt16="伊朗：沙阿出逃";
$annee79evt16detail="他会在局势平息后回来……或许永远不会";

$guerillakhouzistan="胡兹斯坦阿拉伯部落";

$annee79evt17="伊朗：胡兹斯坦部落叛乱";
$annee79evt17detail="它很快就会被摧毁";

$annee79evt17="伊朗：库尔德人利用乱局";
$annee79evt17detail="另一个库尔德叛乱";

$annee79evt18="联合王国：不满之冬，罢工使该国陷于瘫痪";
$annee79evt18detail="稳定度下降";

$annee79evt19="英国：新任首相玛格丽特·撒切尔，想要“粉碎”工会。";
$annee79evt19detail="稳定度 +3 （是的，这是铁娘子：你不能用寻常的颠覆行为摔倒她！）";


$annee79evt20="在访问墨西哥期间，教宗严厉批评了牧师们的政治投入";
$annee79evt20detail="结束解放神学加成";

$annee79evt21="伊朗：成立革命卫队";
$annee79evt21detail="政权现在拥有自己的武装力量";

$annee79evt22="伊朗：军队大清洗";
$annee79evt22detail="该国军事力量降低30%";

$guerillabaloutche="俾路支游击队";
$guerillaazeris="阿塞拜疆独立派";

$flnpkhmer="高棉人民民族解放阵线";



?>