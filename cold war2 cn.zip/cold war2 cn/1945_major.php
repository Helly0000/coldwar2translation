﻿<?php


// Original: $titresept1945a="孩子们想要回家！";
$titresept1945a="我们的孩子想要回家！";
// Original: $titresept1945a1="BOYS ARE COMING BACK HOME!";
$titresept1945a1="我们的孩子要回家了！";
// Original: $titresept1945a2="OUR NEW ENERMY: COMMUNISM!";
$titresept1945a2="我们的新敌人：共产主义！";

/* Original: 
$textesept1945a="
500 000 Allied and American soldiers are occupying Japan.<br>
Our planners thought war would last for at least another year.<br>
Consequently, we had nothing planned for a quick reconversion of our war economy to peace economy.<br>
With hostilities coming to an end, only massive unemployment will welcome our veterans...<br>
Tensions sparking with our former Soviet ally and the imbalance between Soviet forces and ours in Europe may be a good reason for not ordering immediate demobilisation.
";
*/
$textesept1945a="
50万盟军和美国士兵正在占领日本。<br>
我们的参谋本预计战争至少还要持续一年。<br>
因此，我们没有将目前的战时经济转入和平经济的计划。<br>
随着战争行动的结束，我们的退伍军人将面临大量失业……<br>
但是，与我们的前盟友苏联之间的紧张关系已经引发，我们的军队和苏联在欧洲的军队之间的不平衡可能是不下令立即复员的一个好借口。";

$choix1sept1945a="战争结束了！让我们复员！";
// Original: $choix1sept1945atitle="You switch to peace budget (-25$) and increase social contestation";
$choix1sept1945atitle="你转入和平预算（-25$），并增加社会抗议";
$choix2sept1945a="让我们继续动员对抗共产主义";
// Original: $choix2sept1945atitle="Increases Russian aggressivity and pacifist contestation, sharly increases tension and will worry your European allies.";
$choix2sept1945atitle="增强俄罗斯的侵略性和增加和平主义抗议，紧张局势大幅上升，并将使你的欧洲盟友担忧。";

// Original: $textesept1945a1="Demobilisation starts and you switch to peace economy (monthly budget -$25)";
$textesept1945a1="复员开始，你转入和平经济（每月预算-25$）";

// Original: $textesept1945a2="President Truman declares: the fight for freedom in Europe goes on!";
$textesept1945a2="总统宣布在欧洲为自由而战的斗争还将继续！";


$croisadeanticoco="这个国家加入你的反共十字军（关系+2）";
// Original: $refuseanticoco="this country disapproves of your irresponsible attitude (relations-1)";
$refuseanticoco="这个国家不赞成你不负责任的态度（关系-1）";




$telexsept1945a1="复员";
// Original: $telexsept1945a1detail="Decrease in the number of troops stationed in Japan and switch to peace budget(-$25)";
$telexsept1945a1detail="减少驻扎在日本的军队数量，转入和平预算（-25$）";

// 2nd event

$titresept1945b="我们需要哪个中国？";
/* Original:
$textesept1945b="While Mao and Chiang Kai-shek are discussing a potential coalition to rebuild the country in Chungking, it becomes blatant that the two Chinas - the nationalist one and the communist one - will not get along and that civil war will restart soon.<br>
				We hold the key to China's fate since we occupy Manchuria.<br>
				What should we do about this territory?<br>
				Mao would like to have the Chinese communist troops move in to establish their new main base of operations.<br>
				We could also create a puppet State in Manchuria beneath our boot.
				Last, we could strike a deal with nationalist China and evacuate later this territory.";
*/ 
$textesept1945b="即使毛泽东和蒋介石在重庆商讨组成联合政府重建国家的可能性，很明显，两个中国——国民党的和共产党的——不会融洽相处，中国内战应该会很快重启。<br>
				既然我们掌握着东北，我们就掌握了中国命运的钥匙。<br>
				我们该怎么做？<br>
				毛泽东希望中国共产党军队进驻东北，并将其作为他们新的主要前进基地。<br>
				我们也可以在我们的靴子下建立一个东北傀儡国家。
				最后，我们可以与国民党达成协议，并计划随时间推移离开东北。";

$choix1sept1945b="让中共进入东北";
// Original: $choix1sept1945btitle="The Manchu State disappears and the Chinese guerrilla is reinforced";
$choix1sept1945btitle="满洲消失，中共游击队得到加强";
$choix2sept1945b="让我们创造第三中国";
// Original: $choix2sept1945btitle="Deteriorates your relations with the other two Chinas and weakens the guerrilla.";
$choix2sept1945btitle="恶化你同国共两党的关系，削弱共产党游击队。";
// Original: $choix3sept1945b="Let us get on with the nationalists.";
$choix3sept1945b="让我们把东北交给国民党";
// Original: $choix3sept1945btitle="Improves your relations with China, deteriorates your relations with the guerrilla and weakens it.";
$choix3sept1945btitle="改善和国民党的关系，恶化共产党游击队的关系，并削弱他们。";

// Original: $titresept1945b1="COMMUNISTS ENTER MANCHRUIA!";
$titresept1945b1="共产主义者进入满洲！";
// Original: $textesept1945b1="While your troops are withdrawing, Chinese communists enter Manchuria and join up forces with the local guerrilla (guerrilla power +15).";
$textesept1945b1="当苏军撤退时，中共已经进入满洲，汇合当地游击队并成立了东北民主联军（游击队力量+15）.";

$titresept1945b2="满洲人民共和国宣告成立！";
// Original: $textesept1945b2="The People's Republic of Manchuria is proclaimed to the greatest dismay of the various Chinese factions. The new government intends not to be delayed in collectivising the economy.";
$textesept1945b2="满洲人民共和国宣告成立——这令中国各派系大为震惊。新政府将毫不拖延地开始集体化经济。";

// Original: $titresept1945b3="MOSCOW KEEPS ITS COMMITMENTS";
$titresept1945b3="莫斯科遵守承诺";
// Original: $textesept1945b3="Communists are prevented to enter Manchuria and the nationalist government appreciates that you kept your promise to turn the land back to him.<br> Units of the People's Liberation Army are nonetheless infiltrating the field and local guerrilla becomes increasingly active: this is undoubtedly time for Soviet troops to leave China.";
$textesept1945b3="共产党人被阻止进入东北，国民党政府对你遵守承诺，把东北交给他们很感激。<br> 尽管如此，中国人民解放军的部队仍在向这一地区渗透，本地游击队正在日益活跃，该是苏军离开中国的时候了。";

$telexsept1945b1="中共进入东北";
// Original: $telexsept1945b1detail="Communist guerrilla is reinforcing";
$telexsept1945b1detail="共产党游击队得到加强";


// event 3 

$titresept1945c="意料之外的盟友";
/* Original: 
$textesept1945c="
Japanese people are still very loyal to the emperor and the defeat of the Japanese Empire is as poorly accepted as is our occupation of the country.<br>
	The Japanese Communist Party and its leader Kyuichi Tokuda are the only ones to campaign for the creation of a republic and the end of the imperial system.<br>
	Tokuda even advocates a complete respect of Japanese responsibilities as decreed in the capitulation act and general MacArthur's instructions.<br>
	We have at least an unexpected ally on these points!<br>

	It may be time to legalise this party which has been banned in Japan since the beginning of World War II and release its leaders.";
*/
$textesept1945c="
日本人民仍然对天皇非常忠诚，日本帝国的战败和我们对该国的占领一样难以被接受。<br>
	日本共产党(JCP)及其领袖德田球一是唯一一只为终结帝国体制和建立共和国而奋斗的力量。<br>
	德田甚至主张完全履行日本在《投降法令》和麦克阿瑟将军指示中的责任。<br>
	我们在这些问题上有一个意料之外的盟友！<br>

	也许是时候解禁日本共产党（自二战开始以来就在日本被禁止）并释放其领导人。";

$choix1sept1945c="让我们解禁日本共产党(JCP)";
// Original: $choix1sept1945ctitle="Creates a pro-USSR opposition in Japan and will create pressure on the Japanese government";
$choix1sept1945ctitle="创造一个在日本的亲苏反对派，并将对日本政府施压";
$choix2sept1945c="在日本没有共产党！";
// Original: $choix2sept1945ctitle="The Japanese stability increases, relations with the USA deteriorate and Japan gains the trait Non aligned";
$choix2sept1945ctitle="日本稳定度增加，与美国关系恶化，获得不结盟特质";

$titresept1945c1="德田球一自由了！";
/* Original: 
$textesept1945c1="No sooner had Tokuda been released that he is carried by a joyful crowd of communists and Korean workers shouting Banzai!<br>
 Japanese government sees with fear this tiger advocating the end of the imperial system being set free...<br>Nothing beats a good communist threat to push a country on our side!";
*/
$textesept1945c1="德田球一刚刚获释，就被一群欢呼雀跃的共产党人和朝鲜工人抬着在街上游行，高呼“板载”！<br>
 日本政府已经在焦虑地注视着这只主张终结帝国制度的出笼猛虎的自由<br>没有什么比共产主义威胁更能把一个国家带到我们这边来了！";

$titresept1945c2="德田球一继续在监狱里";
/* Original: 
$textesept1945c2="Order will keep reigning in Tokyo...<br>
";
*/
$textesept1945c2="秩序将继续在东京维持……<br>
";

// Original: $telexsept1945c1="Tokuda freed";
$telexsept1945c1="德田球一获释";
$telexsept1945c1detail="共产主义反对派出现在日本";

// EVENT D

// Original: $titresept1945d="TOKYO WAR CRIMES TRIBUNAL";
$titresept1945d="东京战争罪行法庭";
/* Original: 
$textesept1945d="
在东京，对战争罪、危害和平罪和危害人类罪的审判已经开始。<br>
	这些被告是日本军部总参谋部的多名成员，以及像东条英机将军这样的前政府要员。 <br>
	到目前为止，天皇的罪行等级尚未被决定： <br> 
	他显然知晓日军的种族灭绝罪行，并且没有采取任何行动阻止战争——这些因素使他成为潜在的罪魁祸首。 <br>
				然而，攻击天皇可能会严重破坏日本的稳定。";
*/ 
$textesept1945d="
在东京，对战争罪、危害和平罪和危害人类罪的审判已经开始。<br>
	这些被告由日本军部大本营成员和前政府要员组成，例如东条英机将军。 <br>
	到目前为止，皇帝的罪行等级尚未被决定：<br> 
	他显然知晓日军的种族灭绝罪行，并且没有采取任何行动阻止战争——这些因素使他成为潜在的罪魁祸首。 <br>
				然而，审判天皇可能会严重破坏日本的稳定。";

$choix1sept1945d="让我们审判天皇";
$choix1sept1945dtitle="后果会是怎样？";
$choix2sept1945d="宣布他无罪（荣誉-25）";
// Original: $choix2sept1945dtitle="The Japanese stability increases, relations with the USA improve and Japan loses the trait Non-aligned";
$choix2sept1945dtitle="日本稳定度增加，与美国关系改善，失去不结盟特质";

$titresept1945d1="天皇将被审判";
// Original: $textesept1945d1="This is a shock for this country of age-old traditions!<br>";
$textesept1945d1="这是对一个有悠久传统国家的巨大冲击！<br>";
$aimperiale="皇民军";
$pcj="赤卫队";

/* Original: 
$soulevementjapon="The announcement of the emperor's trial saw the American troops being spontaneously attacked throughout the country.<br>In a few days, the movement grew to an unbelievable extent and occupation forces must know fight a true liberation army!<br>
	Notwithstanding the unrest, the emperor will be judged and executed as soon as possible.<br>
	Communist militias spontaneously formed and are giving a helpful hand to our troops: this world became crazy!

";
*/
$soulevementjapon="天皇被审判的消息宣布以后，全国各地都发生了针对美军的自发袭击事件。<br>几天之内，这场运动发展到令人难以置信的程度，占领军现在必须与一支真正的军队作战！<br>
	尽管动乱不断，但天皇将尽快被定罪和处决。<br>
	共产主义民兵自发成立，并对我们的军队伸出援手——这世界真的疯了！

";

/* Original: 
$vaguedesuicide="随着日本帝国制度的瓦解，一股前所未有的自发殉死浪潮袭卷了日本：日本的灵魂被撕裂了！<br>
  日本共产党人无法抑制他们的喜悦！现在是他们进入计划第二阶段的时候了：夺权。<br>";
*/
$vaguedesuicide="随着日本帝国制度的瓦解，一股前所未有的自发殉死浪潮袭卷了日本：日本的灵魂被撕裂了！<br>
  日本共产党人无法抑制他们的喜悦！现在是他们进入计划第二阶段的时候了：夺权。<br>";
// Original: $vaguemanifestations="Protests and counter-protests shake the country and degenerate into uncontrollable violence. Our troops are forced to shoot cannon several time while the country is falling in chaos.";
$vaguemanifestations="抗议和反抗议动摇了国家，并恶化为无法控制的暴力。在国家陷入混乱之际，我们的部队被迫多次使用重炮。";
$titresept1945d2="天皇逃过一劫";
$textesept1945d2="罪犯将受到审判！<br>";

$telexsept1945d1="帝国终结";
$telexsept1945d1detail="日本成为共和国";

// EVENT E

$titresept1945e="叛徒古琴科";
/* Original: 
$textesept1945e="
伊戈尔·古琴科背叛了革命！<br>
这名苏联驻渥太华大使馆文职人员刚刚叛逃。如果他泄密，我们在加拿大的所有特工网络以及我们获取原子弹机密的努力都将付诸东流。<br>
加拿大共产党领导人可能会面临指控，这将对我们在加拿大的影响产生极坏的后果。";
*/
$textesept1945e="
伊戈尔·古琴科背叛了革命！<br>
这名苏联驻渥太华大使馆文职人员刚刚叛逃。如果他泄密，我们在加拿大的所有特工网络以及我们获取原子弹机密的努力都将付诸东流。<br>
加拿大共产党领导人可能会面临指控，这将对我们在加拿大的影响产生毁灭性打击。";

$choix1sept1945e="不作评论";
// Original: $choix1sept1945etitle="Sharply deteriorate your relations with Canada";
$choix1sept1945etitle="严重恶化你和加拿大的关系";
$choix2sept1945e="古琴科必须死！";
// Original: $choix2sept1945etitle=" Deteriorates your relations with Canada very sharpply and there is a risk of a rise in tension";
$choix2sept1945etitle="严重恶化你与加拿大的关系，而且有加剧紧张局势的风险";

$titresept1945e1="古琴科讲出了一切！";
/* Original: 
$textesept1945e1="The existence of large spying network in North America is revealed as well as our efforts to obtain A-bomb secrets.<br>
Communists militants, including deputy Fred Rose, are arrested and charged with spying.<br>Our relations with Canada severely deteriorated and tension with the West rises.<br>
Our R&D bonus on A-bomb research slightly decreases.";
*/
$textesept1945e1=苏联在北美的大型谍报网络已经被公开揭露，一并被揭露的还有我们获取原子弹机密的努力。<br>
共产党激进派，包括党的副手弗雷德·罗斯，已被逮捕并被指控从事间谍活动。<br>我们与加拿大的关系严重恶化，与西方的紧张关系加剧。<br>
我们在原子弹研发上的加成略有下降。";

$titresept1945e2="追捕古琴科";
// Original: $textesept1945e2="Our killers are hunting the traitor and...";
$textesept1945e2="我们的特工正在追捕叛徒……和";
/* Original: 
$gouzenkoabbatu="<br>manage to kill him in front of the Ottawa Journal where he was hiding!<br>
This move was neither discreet nor diplomatic and our relations with Canada went sour.";
*/ 
$gouzenkoabbatu="<br>得以在他藏身的渥太华日报处刺杀了他！<br>
这一举动既不慎重，也不符合外交，我们与加拿大的关系已经恶化。";
// Original: $gouzenkopasabbatu="cannot make a move because Gouzenko is already under protection of the Canadian secret services.<br>";
$gouzenkopasabbatu="不能采取行动，因为古琴科已经在加拿大特勤局的保护之下。<br>";

$telexsept1945e1="古琴科事件";
// Original: $telexsept1945e1detail="Relations bewteen Canada and Moscow have worsened";
$telexsept1945e1detail="加拿大和莫斯科的关系恶化";

// EVENT F

$titresept1945f="战争赔款";
/* Original:
$textesept1945f="
Russia paid a heavy price during the Great Patriotic War.<br>
It is time to assert the winner's rights!<br>
Agreements concluded with the Allies allow us to claim major war reparations from defeated countries.<br>
We must as well create a defensive buffer zone that would protect the Motherland from foreign aggressions.
<br>We committed to organise free elections in countries we are occupying.<br>
However, there are still interpretation and negotiation margins left.";
*/
$textesept1945f="
俄国在伟大的卫国战争中付出了沉重的代价。<br>
现在是时候声称胜利者的权利了！<br>
我们与盟国签署的协议允许我们向战败国要求大额战争赔偿。<br>
此外，我们还必须建立一个缓冲区，保护祖国不受外国侵略。
<br>我们同意在我们占领的国家组织自由选举。<br>
然而，仍有很大的解释和谈判空间。";


// Original: $choix1sept1945f="Let us plunder and make losers into satellite states!";
$choix1sept1945f="让我们掠夺并把战败国变成卫星国！";
// Original: $choix1sept1945ftitle="Increases tension, Eastern Europe countries have a chance to see their wealth decreasing, increases stalism and monthly budget.";
$choix1sept1945ftitle="加剧紧张局势，增长斯大林主义，每月预算提升，但是东欧国家的财富可能降低。";
$choix2sept1945f="让我们（以互利的方式）与西方讨论";
// Original: $choix2sept1945ftitle="Withdraws your troops from Czechoslovakia, guarantees free elections and consolidates elected communist governments.";
$choix2sept1945ftitle="从捷克斯洛伐克撤军，保证整个地区的自由选举，巩固民选产生的共产党政府。";

$titresept1945f1="东方出血";
// Original: $textesept1945f1="While industrial infrastructures from occupied countries are being dismantled and shipped by train to the USSR, communists attempt to carve a position for themselves in governments through intimidation and power struggles.<br>";
$textesept1945f1="当被占领国的工业基础设施被拆卸并通过火车运往苏联时，共产党人试图通过恐吓和权力斗争在政府中占据一席之地。<br>";

// Original: $cocopasseenforce="Communists attempt to force their way in... unsuccessfully";
$cocopasseenforce="共产党试图强行进入政府……不成功";
// Original: $cocorenforceinfluence="Communists reinforce their influence";
$cocorenforceinfluence="共产党加强了他们的影响力";
// Original: $cocopouvoir="Communists seize power";
$cocopouvoir="共产党夺权";
// Original: $pillage="Systematic plunder of occupied countries increases your monthly budget by $10 but tension with the USA rises sharly.";
$pillage="战败国的系统性赔偿使你每月预算增加10$，但与美国的紧张关系急剧上升。";

// Original: $titresept1945f2="WE KEEP OUR WORD";
$titresept1945f2="我们遵守承诺";
/* Original: 
$textesept1945f2="Our troops evacuate the Czechoslovak territory and, in each Eastern European country, communists play the election game.<br>
	The USA recognise these democratically elected governments.<br>
	Stability of Eastern European countries increases";
*/
$textesept1945f2="我军撤离了捷克斯洛伐克领土，共产党人在每个东欧国家玩选举游戏。<br>
	美国已经承认了这些民主选举产生的政府。<br>
	东欧国家的稳定度有所增长";

// Original: $telexsept1945f2="The USA recognise the government";
$telexsept1945f2="美国已经承认了新政府";
// Original: $telexsept1945f2detail="Stability increase";
$telexsept1945f2detail="稳定度增长";
// Original: $telexsept1945f3="Soviet troops leave the country";
$telexsept1945f3="苏军已经离开该国";
$telexsept1945f3detail="苏军不再驻扎在捷克斯洛伐克";

// EVENT G 

// Original: $titresept1945g="THE FOREST BROTHERS";
$titresept1945g="森林兄弟";
/* Original: 
$textesept1945g="
Territories we reconquered on our western borders remain infested by fascists, nationalists and other traitors who fight our forces and claim independance.<br>
		The fiercest groups are the UPA Ukrainians and reactionnary Baltic people like the Union of Lithuanian Freedom Fighters.<br>
		The NKVD and the Red Army are redoubling in efforts to crush these movements but their action seems to remain insufficient.<br>
";
*/
$textesept1945g="
我们收复的西部边界地区仍然潜藏着法西斯分子、民族主义者和其他叛徒，他们正在同我们的军队作战并宣称独立。<br>
		最狂热和反动的是乌克兰反抗军（UPA）和如立陶宛自由战士联盟这样的波罗的海民族主义者。<br>
		人民内务委员部（NKVD）和红军正在加倍努力镇压这些反动派，但他们的行动似乎仍然不够。<br>
"; 
$choix1sept1945g="让我们驱逐和封锁！（荣誉-100）";
// Original: $choix1sept1945gtitle="Increases stalinism and decreases partisans' strength";
$choix1sept1945gtitle="增长斯大林主义，削弱游击队力量";
$choix2sept1945g="武器就够了";
$choix2sept1945gtitle="无效果";

$titresept1945g1="封锁和驱逐";
/* Original: 
$textesept1945g1="To find a needle in a haystack, you just have to burn the haystack, right? <br>
NKVD divisions are putting the forests to fire, massively deporting populations and disguising themselves as UPA soldiers to commit atrocities. 
These movements will soon cease to exist because of the lack in popular support.";
*/
$textesept1945g1="要在干草堆里寻针，那就用火把草堆点燃吧。<br>
人民内务委员部（NKVD）各师纵火焚烧森林，大规模驱逐人口，并伪装成乌克兰反抗军（UPA）士兵实施暴行。
由于缺乏民众支持，这些运动将很快不复存在。";

$titresept1945g2="战斗将持续很久";
/* Original: 
$textesept1945g2="
The fight will take a long time: UPA controls entire Ukrainian regions and its fighters are on equal terms with our troops.
";
*/
$textesept1945g2="
这场战斗将持续很长时间——乌克兰反抗军（UPA）控制着大片乌克兰聚居区，其战斗人员与我们的军队平分秋色。
";

// EVENT H

$titresept1945h="在中国的调停";
/* Original:
$textesept1945h="
With the end of the war against Japan, the united front between Chinese communists and nationalists against the occupier is no longer valid.<br>
Patrick J.hurlay has been trying since August to convince both sides to rebuild China together in a coalition government.<br>
Defiance seems to deeply rooted between the two camps and these talks are deadlocked.<br>
What should we do?
";
*/
$textesept1945h="
既然抗日战争已经结束，中国共产党人和国民党人已不再结成抗击侵略者的统一战线。<br>
美国少将帕特里克·J·赫尔利（Patrick J.Hurley）自8月以来一直试图说服国共双方组建联合政府，共同重建中国。<br>
然而，两大阵营之间的敌意似乎根深蒂固，谈判陷入僵局。<br>
我们该怎么办？
";

$choix1sept1945h="谈判必须继续！";
$choix1sept1945htitle="只要还在谈判，和平就仍有一线希望";

$choix2sept1945h="让我们施压国民党！";
// Original: $choix2sept1945htitle="Talks should go on but there is a minor risk of splitting with the nationalists";
$choix2sept1945htitle="谈判应该会继续，但有一个微小的风险导致与国民党分裂";

$choix3sept1945h="我们已经选择了自己站在哪一边，不是吗？（荣誉-25）";
// Original: $choix3sept1945htitle="End of talks, improves your relations with the nationalists, deteriorates your relations with the communists and increases your help to nationalists by $5";
$choix3sept1945htitle="结束谈判，改善与国民党的关系，恶化与共产党的关系，并增加对国民党的援助5$";

$titresept1945h1="在中国的调停";
/* Original: 
$textesept1945h1="Negotiations are still ongoing but unproductive: it appears that both camps are using delaying tactics to build up their forces at the onset of the inevitable resumption of fights.<br><br>
<span style=\"font-style:italic;\" >Forces from both sides increase by +5</span>
";
*/
$textesept1945h1="谈判仍在进行中，但毫无成效。看来这两个阵营都在拖延时间以便部署自己的部队，为不可避免的冲突卷土重来做好准备。<br><br>
<span style=\"font-style:italic;\" >国共双方的军事力量+5</span>
";
$titresept1945h1b="一个潜在的外交结果？";
/* Original: 
$textesept1945h1b="Negotiations are ongoing and, despite high tension, it seems the two partners are progressing toward a negotiated solution.<br><br>
<span style=\"font-style:italic;\" >The People's Liberation Army gains the trait \"Negociations\"</span>";
*/
$textesept1945h1b="谈判仍在进行中，尽管双方关系紧张，但谈判似乎正在朝着解决问题的方向前进。<br><br>
<span style=\"font-style:italic;\" >中国人民解放军获得了“谈判”特质</span>";

$titresept1945h2="蒋坐回谈判桌";
/* Original: 
$textesept1945h2="We threatened Chiang Kai-shek, the nationalist leader, to forbid him access to our military surpluses and cut all financial support. <br>
   Chiang reluctantly seats again at the negotiations table. <br><br>
<span style=\"font-style:italic;\" >The People's Liberation Army gains the trait \"Negociations\"</span>
";
*/
$textesept1945h2="我们要求国民党领导人蒋介石继续谈判，以取消我们的军需供应，切断一切财政支持相威胁。 <br>
   蒋已经不情愿地再次在谈判桌上就座。 <br><br>
<span style=\"font-style:italic;\" >中国人民解放军获得了“谈判”特质</span>
";

$titresept1945h2b="美中分裂";
/* Original:
$textesept1945h2b="We threatened Chiang Kai-shek, the nationalist leader, to forbid him access to our military surpluses and cut all financial support. <br>
   He was so willing to crush the Communists that he ignored our threats and multiplied provocations.<br>
   Hurlay is formal: there is not only nothing to derive from this man but there is unfortunately no potential worthier replacement in the Kuomintang party.<br>
   The split is now complete between our two nations and, following Hurlay's advice, we cut our support to the nationalists.
    <br><br>
<span style=\"font-style:italic;\" >End of your support to China and deterioration of your relations</span>
";
*/
$textesept1945h2b="我们要求国民党领导人蒋介石继续谈判，以取消我们的军需供应，切断一切财政支持相威胁。 <br>
   蒋对摧毁共产党的执念是如此的狂热，他无视了我们的威胁，增加了他对共产党人的挑衅。<br>
   赫尔利少将直言不讳，我们不仅从他身上一无所得，而且更不幸的是，国民党内没有一个能够取代蒋的人选。<br>
   现在我们两国的分裂已经公开化，根据赫尔利少将的建议，我们切断了对国民党的支持。
    <br><br>
<span style=\"font-style:italic;\" >结束你对中国的支持，恶化你与中国的关系</span>
";

$titresept1945h3="他在重庆揭下面具";
/* Original: 
$textesept1945h3="Communists quickly realised the mediator was not neutral.<br>
Negotiations are broken off while military surpluses convoys from South East Asia are redirected to Chinese harbours in order to reinforce nationalists.<br>
 The communist armies are already on their way to Manchuria.

<br><br>
<span style=\"font-style:italic;\" >Your aid to China increases by $5</span>
";
*/
$textesept1945h3="共产党人很快意识到这位调停者绝非中立。<br>
谈判已经破裂，来自东南亚的军事补给船队正被运到中国港口，以加强国民党军队的力量。<br>
共产党军队已经在去东北的路上了。

<br><br>
<span style=\"font-style:italic;\" >你每回合对中国的援助增加5$</span>
";


// EVENT i

$titresept1945i="我们的秘密武器";
/* Original: 
$textesept1945i="
We knew even before President Truman that the USA were working on the atomic bomb.<br>
Our secret services recruited numerous scientists within the most secret US research project: Project Manhattan.<br>
Thanks to these information and the collaboration of German scientists who we \"invited\" to work in USSR, we should be in position to explode our own A-bomb by 1949.<br>
As long as we do not possess nuclear weapons, the overwhelming numerical superiority of our troops will not be enough to intimidate the Americans.

";
*/
$textesept1945i="
我们对美国正在研制原子弹的知悉甚至早在总统杜鲁门之前！<br>
我们的特勤部门在美国最机密的研究项目：曼哈顿计划中招募了许多科学家。<br>
多亏了这些信息以及我们“邀请”到苏联工作的德国科学家的合作，我们应该能够在1949年前引爆我们自己的原子弹。<br>
在我们拥有核武器之前，我们军队在人数上的压倒性优势远不足以威吓美国人。

";


$choix1sept1945i="核项目是重中之重！";
// Original: $choix1sept1945ititle="You get a bonus in developing A-Bomb";
$choix1sept1945ititle="你在研制原子弹时得到大幅加成。";

$titresept1945i1="我们的秘密武器";
/*/ Original: 
$textesept1945i1="
You receive a major bonus in developing A-Bomb.

";
*/ 
$textesept1945i1="
你在研制原子弹时会得到大幅加成。

";

/***********************************
// FRANCE JOUABLE
************************************/

$titresept1945j="福利国家";
/* Original: 
$textesept1945j="
The people suffered from war and, with the returning peace, coming back to the previous situation is out of the question.<br>
The programme drafted by the Résistance foresees  « a complete plan for Social security, aimed at guaranteeing livelihoods for all citizens, in all cases where they are incapable of procuring them with their work, managed by representatives of those concerned and the State ».<br>
The fathers of this project, Alexandre Parodi and Pierre Laroque, have been working on it since before the war: it is finally time to implement it!<br>
This idea is fashionable at the moment and, among our British neighbours, William Beveridge is recommending similar measures.<br>


";
*/
$textesept1945j="
人民饱受战争之苦，旧制度已不再能重返，即使在和平回归后。<br>
抵抗运动起草的方案设想“一个完整的社会保障计划，旨在保障所有公民在没有工作能力的情况下维持生计，由有关各方和政府代表管理”。<br>
这个项目的创始人，亚历山德拉·帕罗迪和皮埃尔·拉洛基，从战前就一直在为之努力——终于到了让它付诸实施的时候了！<br>
这个想法目前很流行，在我们的英国邻国，威廉·贝弗里奇（William Beveridge）也建议采取类似的措施。<br>


";


$choix1sept1945j="社保系统万岁！（荣誉 150/预算-5$）";
// Original: $choix1sept1945jtitle="Yes, I know. These are contributions which should not impact your budget.";
$choix1sept1945jtitle="是的，我知道--这些政策真的不应该影响你的预算……";

// Original: $choix2sept1945j="Let us agree on nothing! (prestige -50)";
$choix2sept1945j="我们不会同意任何事情！（荣誉-50）";
// Original: $choix2sept1945jtitle="Will increase communist contestation";
$choix2sept1945jtitle="会增加共产党的抗议活动";

$titresept1945j1="福利国家";
/* Original: 
$textesept1945j1="
This ambitious plan is implemented via orders and will be funded through contributions of the working population.<br>
In addition to the unified general social security system, those specific systems that predated it will remain in existence (miners,civil servants...)<br>
The general system will later be completed with the establishment of family allowances.<br>
This is a new era of welfare that begins for the Frenchwomen and Frenchmen.

";
*/
$textesept1945j1="
这项雄心勃勃的计划正在通过行政命令实施，并将通过劳动人口的税收提供资金。<br>
除新的统一社会保障制度之外，所有在此之前的类似制度（针对矿工、公务员等）都将继续存在。<br>
社会保障制度将在建立家庭津贴之后大致完善。<br>
这是一个为了全法国人民的福祉的新时代。

";


$titresept1945j2="政府危机";
/* Original: 
$textesept1945j2="
Everything goes wrong within the Provisional Government of the French Republic: its different parts - socialists, communists and republicans - fail to agree on anything!<br>
No compromise can be found on the project of constitution, neither on the implementation terms of conditions of the unified social security system, nor on the Indochinese policy.<br>
What a sad show of punching-up and resignations together with hesitations coming from yesterday's Résistants - offered to the stupefied eye of their contemporaries.


";
*/ 
$textesept1945j2="
法兰西共和国临时政府内部一切都出了问题。它的组成部分——社会党人、共产党人和共和党人——没有在任何事情上达成过一致！<br>
在新宪法上，在实行统一社会保障制度的具体问题上，在我们关于印度支那的政策上，都不能达成妥协。<br>
曾经的抵抗运动成员们互相批评、辞职和犹豫不决的悲剧正在向为他们震惊的同时代人展示。


";


// EVT K

$titresept1945k="制宪会议";
/* Original: 
$textesept1945k="
人民决定他们的未来！这次我们所有的公民都将参与投票，这是妇女第一次拥有投票权！<br>
新的国民议会将是一个具有代表性的议会!<br>
但是，政府的制衡机制将如何发挥作用呢？<br>
戴高乐将军主张政府应有强大的行政权，而共产党则希望有一个强大而全能的议会。
<br>


";

if($_SESSION['PCF']>2)
{
	$textesept1945k.="选举结果非常明显，三大政党支配着法国政坛： 
左翼，由社会党和共产党组成，获得了50.2%的选票。中右翼，聚集在国民共和运动（MRP）周围，也从投票中脱颖而出。<br>
左翼获得了绝对多数：只要社会党人和共产党人合作，他们就将为我们的国家确定方向。";
}
else
{
	$textesept1945k.="选举结果非常明显，三大政党支配着法国政坛： 
	左翼，由社会党和共产党组成，获得了49.6%的选票。中右翼，聚集在国民共和运动（MRP）周围，也从投票中脱颖而出。<br>
	中左翼的激进社会党——战前如此强大——正在从政治舞台上消失。";
}
*/
$textesept1945k="
人民决定他们的未来！这次我们所有的公民都将参与投票，这是妇女第一次拥有投票权！<br>
新的国民议会将是一个具有代表性的议会!<br>
但是，政府的制衡机制将如何发挥作用呢？<br>
戴高乐将军主张政府应有强大的行政权，而共产党则希望有一个强大而全能的议会。
<br>


";

if($_SESSION['PCF']>2)
{
	$textesept1945k.="选举结果非常明显，三大政党联盟支配着法国政坛：  
左翼，由社会党和共产党组成的联盟获得了50.2%的选票。一个围绕着国民共和运动（MRP）的中右翼联盟也从投票中脱颖而出。<br>
左翼获得了绝对多数：只要社会党人和共产党人合作，他们就将为我们的国家确定方向。";
}
else
{
	$textesept1945k.="选举结果非常明显，三大政党联盟支配着法国政坛：  
	左翼，由社会党和共产党组成的联盟获得了49.6%的选票。一个围绕着国民共和运动（MRP）的中右翼联盟也从投票中脱颖而出。<br>
	中左翼的激进社会党——战前如此强大——正在从政治舞台上消失。";
}


// EVT L

$titresept1945l="回归印度支那";
/* Original: 
$textesept1945l="
Our glorious troops just regained a foothold in Indochina, which is dominated by a great political incertainty since the Japanese capitulation.<br>
In the north, Dans le Nord, Ho Chi Minh proclaimed the independence of a Democratic Republic of Vietnam.<br>
General Leclerc suggests a conciliatory approach with Ho Chi Minh: 
«I recommended the government to recognise the State of Vietnam, there was no other solution. Reconquering the North by the force of arms was not at issue as we had none and would never have the means. Remember the South. Insuccess is certain here... We must keep Vietnam in the French Union, that is the goal, even if this means independence.»<br>
The north of Vietnam is infested with Chinese troops pillaging the countrysides and hunting communists: it is time to restore order.<br>
";
*/ 
$textesept1945l="
我们光荣的军队刚刚在印度支那重新站稳脚跟，这是一个自日本投降以来导致的权力真空以来局势就极不稳定的地区。<br>
在北部，胡志明已经宣布了越南民主共和国的独立。<br>
勒克莱尔将军建议与胡志明采取和解的办法：
他说，我建议政府承认越南独立的现状，这是最明智的解决办法。因为我们现在没有，将来也没有可能用武力重新征服北方。记住南方的教训，我们肯定不会成功……我们必须把越南留在法兰西联盟之内，这是我们的目标，即使这意味着越南的独立<br>
北越已经被国民党军队对农村的掠夺和对共产党人的追捕行为所淹没。是时候重建秩序了。<br>
";

// Original: $choix1sept1945l="Let us discuss with Ho Chi Minh";
$choix1sept1945l="让我们与胡志明展开讨论";
$choix1sept1945ltitle="这是最明智的解决办法";

$choix2sept1945l="我们会用武力征服他们";
// Original: $choix2sept1945ltitle="Will increases the communist contestation and decrease the stability of Vietnam";
$choix2sept1945ltitle="会增加共产党的抗议活动，降低越南稳定度";

$titresept1945l1="回归印度支那";
/* Original: 
$textesept1945l1="
Negociations have been initiated with Ho Chi Minh and are on the right track: our troops should be able to land in Hanoï very soon without a shot being fired.<br>
The terrible famine that strikes the north of Vietnam has undoubtedly a significant role in this unexpected opening.<br>
It is time to set this French Union with an Indochinese federation.<br>
";
*/
$textesept1945l1="
与胡志明的谈判已经开始，而且正在迈入正轨——很快，我们的军队应该可以在不交火的情况下登陆河内。<br>
越南北部的可怕饥荒无疑在这一意外事件中扮演了重要角色。<br>
现在是时候在我们的法兰西联盟内接受印度支那联邦了。<br>
";

$titresept1945l2="回归印度支那";
/* Original: 
$textesept1945l2="
Our contingent is not yet capable of retaking the North by the force of arms. This will be a long-term endeavour but time is on our side.<br>
The north of Vietnam is struck by a terrible famine in addition to the exactions of the Chinese army: Ho Chi Minh's movement should grow weaker every day.
";
*/
$textesept1945l2="
我们的特遣队还不能用武力夺回北方。这将是一项长期的努力……但时间在我们这边。<br>
除了境内国民党军队的荼毒带来的沉重负担之外，越南北部也面临着可怕的饥荒；胡志明的运动应该会日益微弱。
";

// EVT M

$titresept1945m="政府中的共产党人";
/* Original: 
$textesept1945m="
Buoyed by its electoral success, the communist party should enter the government with full force.<br>
Charles de Gaulle has been nominated President of the government and does not intend to give the communists any of the key ministries. 
<br>
If he was a true democrate, he should nonetheless wholeheartedly take into account the outcome of the polls.
";
*/
$textesept1945m="
在选举成功的鼓舞下，共产党正在准备完全进入法国新政府。<br>
然而，被选为总统的夏尔·戴高乐，不打算让共产党控制政府的任何重要部门。
<br>
如果他是一个真正的民主主义者，他应该毫无异议地接受投票结果。
"; 

// Original: $choix1sept1945m="Let us give the Ministry of the Interior to the communists";
$choix1sept1945m="让我们给共产党内政部的位置";
// Original: $choix1sept1945mtitle="This is a very reasonable decision: will sharply increase the power of the PCF as well as the activism of far-right movements";
$choix1sept1945mtitle="这是一个非常合理的决定。这将显著增加共产党力量和极右翼运动的积极性";

// Original: $choix2sept1945m="Let us give the Ministry of Foreign Affairs to the communists";
$choix2sept1945m="让我们给共产党外交部的位置";
// Original: 
$choix1sept1945mtitle="这是一个非常合理的决定。这将增加共产党力量和极右翼运动的积极性";

// Original: $choix3sept1945m="Let us not give them any of the too-sensitive ministries";
$choix3sept1945m="我们不会给共产分子任何“敏感”部门的位置";
// Original: $choix3sept1945mtitle="One has to firm in critical moments";
$choix3sept1945mtitle="在这样的关键时刻一定要坚定";

$titresept1945m1="政府中的共产党人";
/* Original:
$textesept1945m1="
五位共产党人进入了新政府。被任命为内政部长的马塞尔·保罗尤其值得关注。<br>
美国驻法大使谨慎地向戴高乐将军表达了他的不赞成和关切。<br>
让我们希望共产党人不会利用已授予他们的权力。<br>
与此同时，戴高乐将军一直保持着对国防部的控制。
";
*/
$textesept1945m1="
五位共产党人进入了新政府。被任命为内政部长的马塞尔·保罗尤其值得关注。<br>
美国驻法大使谨慎地向戴高乐将军表达了他的不赞成和关切。<br>
让我们希望共产党人不会利用已授予他们的权力。<br>
与此同时，戴高乐将军一直保持着对国防部的控制。
";

$titresept1945m2="政府中的共产党人";
/* Original:
$textesept1945m2="
5 communists entered the government, the nomination of Marcel Paul to the Ministry of Foreign Affairs is particularly newsworthy<br>
The United States Ambassador to France discreetly let General de Gaulle know about his disapproval and concern.<br>
Moscow warmly welcomed this nomination, hoping it will mark the beginning of even more fraternal relations with France.<br>
General de Gaulle however kept control over the Ministry of Defence.
";
*/
$textesept1945m2="
五位共产党人进入了新政府。被任命为外交部长的马塞尔·保罗尤其值得关注。<br>
美国驻法大使谨慎地向戴高乐将军表达了他的不赞成和关切。<br>
莫斯科热烈欢迎共产党人的任命，希望这将标志着与法兰西更密切关系的开始。<br>
与此同时，戴高乐将军一直保持着对国防部的控制。
";


$titresept1945m3="政府中的共产党人";
/* Original: 
$textesept1945m3="
5 communists entered the government.<br>
General de Gaulle used all his credibility to safeguard the Interior, the Foreign Affairs and the National Defence from communist influence.<br>
The United States Ambassador to France nonetheless discreetly let General de Gaulle know about his concern.<br>
";
*/
$textesept1945m3="
五位共产党人进入了新政府。<br>
戴高乐将军用尽浑身解数来保护内政部、外交部和国防部不受共产党人的影响。<br>
尽管如此，美国驻法大使还是谨慎地向戴高乐将军表达了他的关切。<br>
";

// EVT N

$titresept1945n="一个大国";
/* 
$textesept1945n="
The victors of the last war, at the instigation of the United States of America, decided to create a United Nations Organisation (UNO) to replace the defunct and inefficient League of Nations/Société des Nations.<br>
This organisation will be a place for dialogue between the nations and will be able to take concrete decisions.<br>
However, all countries will not be equals in the UNO: the executive body of the organisation will be a security council comprised of 15 members.<br>
The five great victors of WW2 will be permanent members of this council and have a veto right.<br>
The United States of America, the USSR, the United Kingdom, the Republic of China and... France will be part of this prestigious club!<br>
We are a great nation!

";
*/
$textesept1945n="
在美国的鼓动下，上次大战的胜利者们决定建立一个联合国(UN) 组织，以取代已不复存在且效率低下的国际联盟。<br>
联合国将成为国家间对话的场所，它将被授权作出具体决定。<br>
然而，联合国内的所有成员国并非完全平等——其执行机构将是一个由15个成员国组成的安理会。<br>
第二次世界大战的五大主要战胜国将成为安理会常任理事国，他们将享有否决权。<br>
美利坚合众国，苏维埃社会主义共和国联盟，大英帝国，中华民国，还有……没错，法兰西将成为这个尊贵俱乐部的一员！<br>
我们是一个大国！

";


// Original: $choix1sept1945n="Hurray! (Prestige +500)";
$choix1sept1945n="万岁！（荣誉+500）";
// Original: $choix1sept1945ntitle="The United Nations Charter comes into effect";
$choix1sept1945ntitle="《联合国宪章》生效";

$titresept1945n1="一个大国";
/* 
$textesept1945n1="
We must recgonise that this success does not come from our prowesses on the battlefield (though the battles of Bir Hakeim and Monte Cassino, among others, still resonate in memories) nor from the excellence of our diplomats. It was Winston Churchill, conscious of the real power and declining role of the British power, who insisted on having France at the security council to avoid being isolated between the USA and the USSR. <br>
Never mind, there is no loss of face!

";
*/
$textesept1945n1="
我们必须承认，我们在联合国的成功并不是来自于我们在战场上的实力（尽管比尔哈基姆和蒙特卡西诺等战役仍然在国际记忆中引起共鸣），甚至不是来自于我们卓越的外交能力。温斯顿·丘吉尔意识到大英帝国的实力和影响力正在下降，他坚持让法国加入联合国安理会，以免被美苏孤立。 <br>
不过，没关系，没什么丢脸的！

";
//EVT O

$titresept1945o="银行国有化";
/* Original: 
$textesept1945o="
该国正处于可怕的财政困境中：通货膨胀率达到48%，我们的商业赤字也很严重。<br>
临时政府刚刚下令将法郎贬值60%。<br>
一个计划委员会（Commissariat général au Plan）将被设立，以起草实现国家复苏的5年计划。<br>
通过国有化控制的银行将成为国家重建和自愿政策的金融工具。<br>
法兰西银行（Banque de France）和像里昂信贷银行（Crédit Lyonnais）和法国兴业银行（Sociéténérale）这样的几家大型储蓄银行将被国有化.<br>
对于左派政治家来说，这一决定也意味着约200个家庭对国家金融命脉控制的终结。

";
*/
$textesept1945o="
该国正处于可怕的财政困境中：通货膨胀率高达48%，我们的商业赤字也很严重。<br>
临时政府刚刚下令将法郎贬值60%。<br>
一个总计划委员会（Commissariat général au Plan）将被设立，以起草促进经济复苏的5年计划。<br>
通过国有化控制的银行将成为国家重建和建设真正民主的社会政策的金融引擎。<br>
法兰西银行（Banque de France）以及像里昂信贷银行（Crédit Lyonnais）和法国兴业银行（Sociéténérale）这样的几家大型储蓄银行一样被国有化.<br>
对于左派政治家来说，这一决定也意味着约200个家庭对国家金融命脉控制的终结。


";

// Original: $choix1sept1945o="Let us nationalise the Banque de France";
$choix1sept1945o="让我们国有化法兰西银行";
// Original: $choix1sept1945otitle="Will increase the reconstruction gauge";
$choix1sept1945otitle="会增加重建进度";

// Original: $choix2sept1945o="Let us nationalise the Banque de France and the deposit banks";
$choix2sept1945o="让我们国有化法兰西银行和储蓄银行";
// Original: $choix2sept1945otitle="Will increase the reconstruction gauge and the influence of the PCF";
$choix2sept1945otitle="会增加重建进度，也会增长法共的影响力";

$choix3sept1945o="没有国有化！";
// Original: $choix3sept1945otitle="Decrease the influence of the PCF";
$choix3sept1945otitle="降低法共的影响力";

$titresept1945o1="银行国有化";
/* Original: 
$textesept1945o1="
With this nationalisation, the State retakes full control of the national monetary policy!
";
*/
$textesept1945o1="
随着法兰西银行的国有化，国家重新获得了对国家货币政策的完全控制权！
";

$titresept1945o2="银行国有化";
/* Original:
$textesept1945o2="
With these nationalisations, the State retakes full control of the national monetary and investment policies!
";
*/
$textesept1945o2="
随着这些银行的国有化，国家重新获得了对国家投资和货币政策的完全控制权！
";

// Original: $titresept1945o3="NATIONALISATIONS ADJOURNED";
$titresept1945o3="国有化延迟";
/* Original: 
$textesept1945o3="
Although the nationalisation policy seemed natural, strong debates emerged around the processes to implement these nationalisations as well as their sphere of operation - leading the provisional government to a standstill on this issue.<br>
These nationalisations have been adjourned to a later date.<br>
Some observers think the momentum on this issue has been definitively lost. 

";
*/
$textesept1945o3="
尽管国有化政策对法兰西来说似乎是一个自然的胜利，但对于实施国有化的程序，以及对政策范围的分歧，一直存在着激烈的争论，使临时政府在这个问题上陷入僵局。<br>
国有化已被延迟到日后进行。<br>
一些观察家认为，在该议题上的所有动力都已丧失。 

";

// EVT P

// Original: $titresept1945p="THE PARTY OF THE 75,000 EXECUTED PEOPLE";
$titresept1945p="战争中牺牲七万五千人的政党";
/* Original: 
$textesept1945p="
The French Communist Party (PCF) is one of the major political forces in post-war France.<br>
The party took part in the Resistance and earned its place in the Provisional Government of the French Republic with two ministers on board.<br>
General de Gaulle accepted the return of Maurice Thorez, the communist leader, who took refuge in Moscow during WW2 and could have been sentenced to death for desertion as a result.<br>
The PCF and the Provistional Government actually stroke a win-win deal: a communist political participation and the return of Thorez in exchange for the disarmament of the armed communist militias.<br>
The party brings a clever propaganda into play, exaggerating their feats of arms and the price paid by its militants to claim a leading position in the French political life.<br>
The PCF renounced to seize power through revolution and its current strategy is to ally with the socialist party, the SFIO, in order to marginalise it and eventually absorb it.<br>
The road to power is for now blocked by General de Gaulle's influence and a powerful centrist party, the MRP, which also partakes in the provisional government.
";
*/
$textesept1945p="
法国共产党（PCF）是战后法兰西的主要政治力量之一。<br>
该党参与了抵抗运动，并在法兰西共和国临时政府中赢得了一席之地，其中有两名部长。<br>
戴高乐将军已经许可莫里斯·多列士的回归，多列士是二战期间在莫斯科避难的法共领导人，他本可能因流亡苏联而被判处死刑。<br>
PCF和临时政府得以达成一个双赢协议——共产党政治家参与政府，以及多列士从苏联归国，作为交换条件，法共民兵将解除武装。<br>
该党正在进行巧妙的宣传，宣扬二战期间其武装部队的壮举和为此付出的牺牲，以期在法国政治生活中占据领导地位。<br>
PCF放弃了一切通过革命夺取政权的意图。它目前的策略是与社会党(SFIO)结盟，以便取得领导地位并最终吸收社会党。<br>
目前，由于戴高乐将军的影响力和临时政府中强大的中派政党国民共和运动（MRP）的存在，法国共产党(PCF)的执政之路受阻。
";

$choix1sept1945p="我们必须重建国家！";
$choix1sept1945ptitle="点击这里查看游戏描述";

$titresept1945p1="战争中牺牲七万五千人的政党";
/* 
$textesept1945p1="
<span style=\"font-style: italic;\">
	<h2>The PCF in-game</h2>
	The French player has a PCF gauge visible in its country screen.<br>
	This gauge represents the role granted by the player to the PCF in the country.<br>
	A high PCF score will worry the USA and lead them to give more financial aid to France starting from 1947.<br>
	A high PCF score will also guarantee the PCF cooperation... as long as the political line do not change in Moscow.<br>
	This high PCF score will also mean that the PCF is stronger should it decide to start contestation movements.<br>
	On the contrary, a low PCF score will immediately lead the PCF to look for showdowns in the country - triggering recurring minor events being a burden on the national reconstruction. 
</span>
";
*/
$textesept1945p1="
<span style=\"font-style: italic;\">
	<h2>游戏中的法国共产党（PCF）</h2>
	法国玩家在本国界面有一个可视的法国共产党（PCF）指标。<br>
	这个量表代表了PCF在国家中的地位。<br>
	高PCF指数将使美国感到担忧，并将导致他们从1947年起向法国提供更多的财政援助。<br>
	高PCF指数也将保证共产党人的合作……只要莫斯科的政治风向不变。<br>
	高PCF指数也意味着，如果法共决定发起抗议运动，其将处于更有利的地位。<br>
	相对的，低PCF指数将导致法共立即开始斗争——反复发生阻碍国家重建的小事件。 
</span>
";


// EVT Q

$titresept1945q="一个重建中的国家";
/* Original: 
$textesept1945q="
The euphoria of German capitulation soon passing, the country tries to reorganise itself as best as it can among rubble and shortages.<br>
Millions of families are homeless and over 2 million of habitations must be repaired or rebuilt.<br>
Certain cities were bombed so heavily by the Allies that they will have to be entirely rebuilt.<br>
Rationing is the norm and the country's supply networks are in pitiful condition.<br>
The black market is booming while a significant part of the children are suffering from rickets.<br>
We must clear vast areas of mines and rebuild infrastructures one by one: there are long-term and major construction works awaiting France given that public debt has skyrocketted and inflation is looming.

";
*/
$textesept1945q="
随着德国投降的喜悦感迅速过去，这个国家现在正尝试在废墟和短缺中尽其所能重组自己。<br>
数以百万计的家庭无家可归，超过200万套住宅必须修复或重建。<br>
一些遭到盟军猛烈轰炸的城市必须彻底重建。<br>
定量配给成为常态，供应网络状况非常糟糕。<br>
黑市蓬勃发展，相当数量的儿童患有佝偻病。<br>
我们必须清除广大地区的地雷，并一点一点地重建基础设施——尽管公共债务猛增，通货膨胀迫在眉睫，但法国未来仍有长期的重大建设项目。

";


$choix1sept1945q="回去工作！";
$choix1sept1945qtitle="点击这里查看游戏描述";

$titresept1945q1="一个重建中的国家";
/* Original: 
$textesept1945q1="
<span style=\"font-style: italic;\">
	<h2>The reconstruction in-game</h2>
	The French player has a Reconstruction gauge visible in its country screen.<br>
	The score is expressed in percentage and, at each 25% stage achieved, the player's monthly budget increases by $5.<br>
	This score naturally increases over time but also depending on the player actions.
</span>
";
*/
$textesept1945q1="
<span style=\"font-style: italic;\">
	<h2>游戏中的国家重建</h2>
	法国玩家在本国界面有一个可视的重建量表。<br>
	重建分数用百分比表示。重建进度每完成25%，玩家的每月预算增加5$。<br>
	重建分数会随着时间的推移而自然增加，但其增长速度也取决于玩家的行为。
</span>
";







?>