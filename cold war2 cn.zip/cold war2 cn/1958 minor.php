﻿<?php

$annee58evt1="苏联：处女地运动结束";
$annee58evt1detail="现在有10$可用预算";

$annee58evt2="： 该国加入欧洲经济共同体";
$annee58evt2detail="稳定度增长";

$annee58evt3="建立欧洲经济共同体";
$annee58evt3detail="一个参与国家稳定和繁荣的时代";

$annee58evt4="委内瑞拉：民众运动推翻军政府";
$annee58evt4detail="该国转变为代议共和政体";

$annee58evt5="南越：越共游击队渗透南方";
$annee58evt5detail="越共游击战士重新开始战斗！";

$annee58evt6="古巴：政府军惨败于圣克拉拉";
$annee58evt6detail="那一天，一个神话诞生了：游击队获得魅力领袖特质，古巴稳定度崩溃了";

$annee58evt7="北也门：该国加入阿拉伯联合共和国";
$annee58evt7detail="北也门加入阿拉伯联合共和国";

$annee58evt8="中国：大跃进！";
$annee58evt8detail="剧烈的经济改革削弱了中国的稳定度";

$annee58evt9="伊拉克-约旦：两国在伊拉克国王费萨尔二世的统治下结成联邦";
$annee58evt9detail="两个王国联合起来";

$annee58evt10="伊拉克-约旦：伊拉克从阿拉伯联邦撤出";
$annee58evt10detail="约旦再次作为一个独立的国家存在";

$insurgentsirakiens="伊拉克叛乱分子";

$annee58evt11="苏联：农业改革";
$annee58evt11detail="苏联将其每月10$预算分配用于农业政策";

$annee58evt12="阿根廷：汽油工人罢工";
$annee58evt12detail="稳定度下降";

$annee58evt13="印度尼西亚：一个反叛政府在苏门答腊宣布成立";
$annee58evt13detail="一个伪国家出现在印度尼西亚";

$annee58evt14="西藏：武装叛乱";
$annee58evt14detail="一支武装游击队出现在中国";

$annee58evt15="缅甸：政权移交给军队";
$annee58evt15detail="一个反共独裁政权在缅甸建立";

$annee58evt16="约旦：英军撤离";
$annee58evt16detail="英国军队离开这个国家";

$annee58evt17="塞浦路斯：土耳其民族主义者拿起武器";
$annee58evt17detail="一支新的游击队出现";

$annee58evt18="黎巴嫩：内乱与美国干预";
$annee58evt18detail="美军在黎巴嫩部署以防止该国内爆";

// Evts mineurs France 1958

$annee58evt19="法国：民族解放阵线在法国本土暗杀警察";
$annee58evt19detail="民族解放阵线袭击本土";

$annee58evt20="法国：警察抗议政府无所作为";
$annee58evt20detail="政变风险加剧";

$annee58evt21="法国：政府再次垮台了…";
$annee58evt21detail="政变风险加剧";


?>