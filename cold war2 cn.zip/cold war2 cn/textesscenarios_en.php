﻿<?php

// doing the original vs new here seems much too difficult
if($_POST['scenario']=='premisses')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/1945.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">迹象 1945-1949</h3>
            第二次世界大战刚刚结束没多久，但前盟友间的关系已经紧张。一场以争夺世界领导权为目的的斗争即将开始。
            </div>

      <?php
}
elseif($_POST['scenario']=='armesegales')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/chinepop.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">旗鼓相当 1949-1953</h3>
            苏联原子弹刚刚试爆，中华人民共和国随之宣告成立，那么冷战可能会转热。
            美国能否在多条战线遏制共产主义？
            </div>

      <?php
}
elseif($_POST['scenario']=='armesegaleslong')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/korea50.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">早期冷战 1945-1953</h3>
            第二次世界大战刚刚结束没多久，但前盟友间的关系已经紧张。一场以争夺世界领导权为目的的斗争即将开始。
            </div>

      <?php
}
elseif($_POST['scenario']=='degel')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/budapest.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">解冻 1953-1956</h3>
            斯大林的逝世和赫鲁晓夫的崛起是否标志着两个阵营间缓和时代的开始？ <br> 决定权在您！
            </div>

      <?php
}
elseif($_POST['scenario']=='mirages')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/suez56a.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">海市蜃楼 1955-1958</h3>
            自朝鲜战争和越南战争结束以来，冷战紧张局势的中心已转移到中东。<br>
            在这个复杂的地区，两个超级大国简单的想法会引起哪些地震？
            </div>
      <?php
}
elseif($_POST['scenario']=='eastisred')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/pekin59.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">东方红 1949-1969</h3>
            巨龙会苏醒吗？<br>
            一个人民共和国在中国宣告成立：在这11年内，美国将不得不面对苏中共同组成的联合战线。<br>然而，在斯大林逝世后，两大巨头间的关系将迅速恶化。 
            </div>

      <?php
}
elseif($_POST['scenario']=='cubalibre')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/barbudos.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">自由古巴 1959-1962</h3>
            古巴革命带来了一个对美国怀有敌意的政府，该政府距佛罗里达海岸仅有几英里之遥。<br>
            这场革命已经成为拉丁美洲许多运动的灵感之源。<br>美国会容忍这种侧翼的社会主义尖刺吗？
            </div>
      <?php
}
elseif($_POST['scenario']=='engrenagevietnamien')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/vietcong.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">越南陷阱 1963-1965</h3>
            南越的局势正在迅速恶化：腐败而不得民心的政府似乎无力对抗越共游击战士。<br>
            对美国国务院来说，让另一个亚洲国家落入共产主义手中是不可想象的！
            </div>

      <?php
}
elseif($_POST['scenario']=='vingtans')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/castlebravo.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">二十年 1945-1965</h3>
            经历冷战的前20年，从日本帝国投降到越南战争。
            </div>

      <?php
}
elseif($_POST['scenario']=='illusionsperdues')
{
      ?>
            
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/praga.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">失去幻想 1964-1968</h3>
            在这短短的4年中，美国和苏联都将失去他们的幻想。<br>
            在越南，美国开始明白他们陷入了一场无望的冲突中。<br>
            在布拉格，苏联意识到他们的联盟是脆弱的，只能依靠武力维持。
            </div>

      <?php
}
elseif($_POST['scenario']=='doublefront')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/flowerpower.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
            <h3 style="text-align: center;">双重战线 1959-1969</h3>
            是否能同时进行两场战争？<br>
            这是美国在20世纪60年代通过与国内贫困的斗争和在越南与共产主义的斗争而下的赌注。
            至于苏联，他们将逐渐发现一个社会主义阵营内的新敌人，她将很快拥有核武器。
            </div>

      <?php
}
elseif($_POST['scenario']=='misterk')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/misterk.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;">
                  
            </div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;color:ivory;">
             <h3 style="text-align: center;">K先生 1953-1964</h3>
            赫鲁晓夫从斯大林逝世到他被罢黜，在苏维埃政策上留下了自己的烙印，足有10年！
            这位前斯大林格勒政治委员会为社会主义阵营选择哪种方向？
            如果您扮演苏联，你将可以在“缓和”和“严厉”、“去斯大林化”和“强硬”之间做出抉择：足以在历史上留下您自己的烙印。
            </div>

      <?php
}
elseif($_POST['scenario']=='dienbienphu')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/dienbienphu1.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">奠边府<br> 1953-1954</h3>
           在印度支那，法国人仍在进行一场漫长而遥远的战争，面对一个坚定的敌人几乎无计可施。 <br>
            随着朝鲜战争即将结束，明显中国对越盟的支持只会强劲增长。 <br>
            法国对印度支那的控制还能维持多久？
            </div>

      <?php
}
elseif($_POST['scenario']=='guerreindochine')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/indochine1.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">印度支那战争<br> 1945-1954</h3>
            战争结束了，法国正准备重新占领印度支那。 <br>
            然而，由于第二次世界大战及日本的胜利，殖民列强不可战胜的声誉已然荡然无存。 <br>
            越南民族主义者不愿不战而接受殖民主义的回归！
            </div>

      <?php
}
elseif($_POST['scenario']=='tempsdiplomates')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/nixonchine2.png) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;">
                  
            </div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">外交官的时代 1969-1975</h3>
            无论在朝鲜半岛、欧陆或是苏伊士运河沿岸，世界似乎被分成了两个阵营，它们相互观察，却无法利用优势。
            与此同时。由于美利坚合众国深陷越战泥潭，力量对比发生改变，把冷战变成一场三方对决，而中国是仲裁者。
            在轰炸机无能为力的地方，外交官必须采取行动。
            </div>

      <?php
}
elseif($_POST['scenario']=='chutesaigon')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/fallofsaigon.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">西贡的陷落 1973-1975</h3>
           苏联正在寻求与西方的绥靖，一系列重要条约正在谈判中。<br> 
            然而，从莫斯科的角度看，解冻似乎与第三世界无关…<br>
            南越的最终崩溃现在只是时间问题，中东的紧张局势正在加剧。<br>
            在这一时期，世界经济将经历深刻的震荡。
            </div>
      <?php
}
elseif($_POST['scenario']=='trenteans')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/bombeH.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">三十年 1945-1975</h3>
            重温冷战的前30年，从日本帝国投降到越南战争结束。
            </div>

      <?php
}
elseif($_POST['scenario']=='grandtimonier')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/maosuperstar.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">伟大舵手 <br>1949-1976</h3>
           从中华人民共和国成立到毛泽东逝世，
           这一场景给予你一个游玩贯穿整个毛泽东时代的机会。
            </div>

      <?php
}
elseif($_POST['scenario']=='mortstaline')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/stalinemort.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">斯大林之死 1953</h3>
           随着朝鲜战局陷入停滞，斯大林只剩下几个月的寿命了。<br>
            他予1953年的逝世将从根本上改变东西方关系。<br>
            这一非常简短的场景将允许你测试这个变革时期的各种政治选择。
            </div>

      <?php
}
elseif($_POST['scenario']=='guerrefraiche')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/khomeini.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">不可预测的世界<br> 1975-1979</h3>
            苏联认为自己正在赢得冷战，而美国则因其从越南战争到水门事件的众多失败而蒙羞，似乎正在衰落。<br>
            对莫斯科来说，资本主义正处于最后的危机，共产主义的时代已经来临！<br>
            我们正在见证历史的终结吗？ <br>
            从西贡到喀布尔，经由德黑兰，世界越来越不可预测。
            </div>

      <?php
}
elseif($_POST['scenario']=='americaisback')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/reagandrapeau.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">美国回归 1980-1985</h3>
            尽管两大阵营间的紧张局势正处于最高峰，但美国很快将选出一位愿意为这场大火再火上浇油的领导人。<br>            
            对罗纳德·里根来说，事情很简单：苏联是邪恶的帝国，在马克思列宁主义加入“历史的灰烬”之前，他不会给苏联超过10年时间。
            里根决心加速其衰败！
            苏联是否有能力迎接这一挑战？
            </div>
            

      <?php
}
elseif($_POST['scenario']=='unepagesetourne')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/afghanistan3.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">从西贡到喀布尔 1975-1985</h3>
            随着越战即将结束，美国对自己的立场缺乏信心，苏联越来越确信自己正在赢得冷战。<br>
            然而，从德黑兰到喀布尔，这两大阵营很快会意识到他们有一个新的重要竞争对手：伊斯兰革命。<br>
            很快，苏联将被自己的越南吞没：阿富汗的群山。
            </div>

      <?php
}
elseif($_POST['scenario']=='quaranteans')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/nikemissile.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">四十年 1945-1985</h3>
            重温冷战的前40年，从日本投降到戈尔巴乔夫改革。
            </div>

      <?php
}
elseif($_POST['scenario']=='vietnamwar')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/vietnam.png) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">越南战争 1963-1975</h3>
            这一场景涵盖了整个越南战争时期。 <br>游玩这一时期的美国当然更有意思。 <br>您能摆脱越战的泥潭吗？
             <br><strong> 决定权在您！ </strong>
            </div>

      <?php
}
elseif($_POST['scenario']=='presidentcarter')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/carteroffice.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">总统卡特 1977-1980</h3>
            长期以来，面对苏联不断增加的挑衅，吉米·卡特的总统职位一直被奉为天使。<br>
            从欧洲导弹危机到入侵阿富汗，卡特总统任重而道远，最近的史学研究对这位总统也相当友善。<br>
            您会比他做得更好吗？
            </div>

      <?php
}
elseif($_POST['scenario']=='beakingthewall')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/chutemurberlin.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">推倒那堵墙 1985-1989</h3>
            苏联的灭亡临近，因为其经济体制和政治阶级都已完全僵化。 <br>
            <br> 红军深陷看不到尽头的阿富汗冲突泥潭中，这个国家的停滞对所有人都是显而易见的。苏维埃领导人知道，除非他们改革这一系统，否则他们孩子的生活将比其父母现在的情况明显恶化。 <br>
            但是，系统仍然可以改革吗？
            </div>

      <?php
}
elseif($_POST['scenario']=='guerrefroide4589')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/bombeHvignette.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">伟大战争 1945-1989</h3>
            从1945年到1989年，您在一场排除直接对抗的战争中执掌了两大超级大国之一的控制权。 <br>
             这是一场冷战，以宣传和颠覆手段争取世界领导权的斗争。 <br>

            <strong>决定权在您！ </strong>
            </div>

      <?php
}
elseif($_POST['scenario']=='implosions')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/desertstorm.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">内爆 1989-1991</h3>
            苏联和东欧阵营正处于内爆的边缘，屈从于其人民的自由主义和民族主义意愿。 <br>
             苏联经济处于混乱状态，全世界都在屏住呼吸，静待这位垂死的巨人将作何反应。 <br>
             戈尔巴乔夫还能拯救苏联吗？ <br>

            <strong>决定权在您！</strong>
            </div>

      <?php
}
elseif($_POST['scenario']=='secondeguerrefroide')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/armeeurss83.jpg) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">第二次冷战 1980-1989</h3>
            苏联刚刚入侵了阿富汗，紧张局势达到最顶点。 <br>
            然而，巨人之足已成泥，联盟正处于最后的岁月，受到腐败、低效的经济和内部民族主义的兴起的破坏。 <br>
            在这一场景中，您被邀请重温冷战的最后几年。
            </div>

      <?php
}
elseif($_POST['scenario']=='altPesidency')
{
      ?>
            <div style="display: inline-block;margin-left: 2%;width:40%;text-align: center;background: url(../images/events/1964althist.png) ;background-size: 100%;background-repeat: no-repeat;  ;height:150px;"></div>
            
            <div style="display: inline-block;margin-left: 3%;width:50%;height:150px;border: 1px solid white;box-shadow:1px 1px 3px black;background-color: black;opacity:0.9;vertical-align:top;padding-left: 3px;padding-right: 1px;overflow: scroll;overflow-y:auto;overflow-x:auto;">
            <h3 style="text-align: center;">惊奇选举 1965-1968</h3>
            在越南，美国开始明白他们陷入了一场无望的冲突中。 <br>
            在布拉格，苏联意识到他们的联盟是脆弱的，只能依靠武力维持。 <br>
            另一位美国总统会怎么做？ <br>
            在平行宇宙中，1964年总统大选的结果将出人意料，Devin2204向我们展示了这一切。
            </div>

      <?php
}




?>