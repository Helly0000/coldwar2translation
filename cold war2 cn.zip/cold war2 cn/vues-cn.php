﻿<?php

// One line comment
/* 
Many line comment
*/

$accorddef="防御协定";

$accordeco="经济协定";
$accordsdefavec="签署防御协定 ";
$accordseconomiquesavec="签署经济协定 ";

$actionmilitaire="军事行动";

$actions="行动";
$activitesennemies="敌方行动";
$actualite="新闻";

$adminmil="军事管理区";
$adminmilalliee="盟军占领区";
$adminmilsov="苏军占领区";

$aideeconomique="经济援助";
$aidemilitaire="军事援助";
// Original: $aidebudget="每次的预算只能通过事件增加， 开销可以通过撤军，取消基地或者军备竞赛而减少. 每个没有花费的$ 会丢失, 不能被储存并用于以后的回合";
$aidebudget="每次的预算只能通过事件增加， 开销可以通过撤军，取消基地或者军备竞赛而减少. 每个没有花费的$ 会丢失, 不能被储存并用于以后的回合";
$aidealachine="对华援助";
$aligner="结盟";

$allogene="非本土";
// Original: $allogenedetail="这个游击队没有本土支持，所以会难以增援自身并且在政府被推翻时解体";
$allogenedetail="这个游击队没有本土支持，它在没有外来援助的情况下不能增强实力并会在政府被推翻时解体";
$annulerembargo="取消禁运";

$armeslourdes="重武器";
$armeslourdesdetail="由于装备了重型武器，该游击队有更好的几率打赢政府军";


// Original: $anticommuniste="反共";
$anticommuniste="反共";
// Original: $anticommunistedetail="这个势力高度仇恨共产主义，因此认为华盛顿是它的天然盟友";
$anticommunistedetail="这个游击队高度仇恨共产主义，因此认为华盛顿是它的天然盟友";

$augmenterrechercher="增加科研经费";
$autresinformations="世界其他地区: ";
$base="军事基地";
$bases="基地";

$baseextra="境外基地";
$baseextradetail="这个游击队在本国境外有根据地，可以肆无忌惮地隐藏在邻国，这使得武器运输更为有效，其势力在没有他国合作的情况下更难被消灭";

$berlinairlift="柏林空运";
$blocusberlin="柏林封锁";

$bienveillante="友善";
$bombe="原子弹";
$bombeA="核弹";
$bombeH="氢弹";

// Original: $bombetitle="这个国家难以被威胁，所以无法入侵";
$bombetitle="T这个国家难以被威胁，也无法被入侵";
$bonne="好";

$boutonclose="关闭";

$budget="预算";
$budgetmensuel="每月预算";
// Original: $budgetinsuffisant="预算不足，无法进行行动";
$budgetinsuffisant="预算不足!";
$chaos="混乱";


$clickout="在窗外点击以关闭";

$coalition="统一战线";
// Original: $coalitiondetail="这只游击队属于联合推翻政府的一个游击队的统一战线，所以会更频繁的进攻";
$coalitiondetail="这只游击队属于联合推翻政府的一个游击队的统一战线，它将会更频繁的发动进攻";

$collectivisee="集体经济";
$colonie="殖民地";

// Original: $complexemilitaroindustrieldetail="军事援助的额外效果";
$complexemilitaroindustrieldetail="军事援助获得额外加成";
// Original: $complexemilitaroindustriel="军工复合体";
$complexemilitaroindustriel="军工复合体";

// Original: $contestsocial="社会不满";
$contestsocial="社会示威";
// Original: $contestsocialdetail="这个指数越高，就越容易出现社会示威来降低你的荣誉";
$contestsocialdetail="这个指数越高，就越容易出现社会示威来降低你的荣誉";

// Original: $corrompue="腐败";
$corrompue="腐败";
// Original: $corrompuedetail="游击队的首领们比起夺权来更热衷于掠夺他们控制下的地区";

$corrompuedetail="游击队的首领们比起夺权来更热衷于掠夺他们控制下的地区";
$corruption="腐败";
// Original: $corruptiontitle="给这个国家的援助更不起效果，而且容易被颠覆";
$corruptiontitle="给这个国家的援助更不起效果，而且该国更容易被颠覆";
$coursearmements="军备竞赛 ";



$creeropposition="组织反对派";
$creerguerilla="制造游击队";
// Original: $dejaaccord="你已经和这个国家签署条约了";

$dejaaccord="你已经和这个国家签署条约了";

$demarche="市场经济";

$departement7="7号部门";
// Original: $departement7detail="从德国获得的科技允许了苏联的研究优势";
$departement7detail="从德国获得的科技加速苏联的科研进展";

$depenses="经费";

$dictature="威权独裁制";

$diminuerrechercher="减少研究经费";

$diplomatie="外交";

// Original: $dissentions="内部反对者";
$dissentions="内部分歧;
// Original: $dissentionsdetail=" 出于内部派系内斗林立，这个游击队在分裂的边缘，他会收到招募的惩罚，但沟通的难度大大增加“;
$dissentionsdetail="出于内部派系内斗林立，这个游击队处在分裂的边缘，该游击队会受到招募惩罚，但与其沟通的难度也大大增加“;

$doctrinejdanov="日丹诺夫理论";
$doctrinejdanovdetail="结盟行动获得大幅加成";

$doctrinetruman="杜鲁门主义";
// Original: $doctrinetrumandetail="经济援助获得加成";
$doctrinetrumandetail="经济援助获得加成";

$economie="经济";

$ecoguerre="战时经济";
// Original: $ecoguerredetail="你的每月预算会过热，但是民众也许会感到疲惫";
$ecoguerredetail="你的每月预算会过度膨胀，但是民众会感到疲惫";

$embargo="禁运";
$endeveloppement="发展中";

$ennemis="敌方部队";



$enguerre="处于战争状态！";
$enguerretitle='title="这个国家被卷入了一场战争"';


$envoitroupes="派遣部队";

$etatpays='国家状况';
$etatislamique="原教旨神权";
$execrable="濒临战争";
$excellente='极好';
$exceptionnelle='样本';

// Original: $fanatisme='狂热';
$fanatisme='狂热';
// Original: $fanatismedetail=" 这些战士们非常狂热，与其他游击队联合或是与政府谈判是不可能的，同时他们也有更顽强的生存力";
$fanatismedetail="这些战士们非常狂热，与其他游击队联合或是与政府谈判几乎是不可想象的，同时他们也有更顽强的生存力 ";

$faible='虚弱';
$fermerbase="关闭基地";
$fermermissiles="撤回导弹";
$financerguerilla="资助游击队";
$finlandisation="芬兰化";
// Original: $finlandisationtitle="芬兰化的国家无法签署防御协定";
$finlandisationtitle="芬兰化的国家无法签署防御协定";
$forcearmee='军事力量';
$forcesarmees='军事力量';
$forceguerilla="军事力量";
$forceguerillamax="军事力量最大上限";
$forte='强大';

$guerilla="游击队与武装团体";
// Original: $gouvernementrenverse="国家陷入了混乱，政府垮台了！";
$gouvernementrenverse="该国动荡，政府垮台！";

// Original: $groupuscule="小型游击队";
$groupuscule="小型游击队";
// Original: $groupusculedetail=" 难以找到能为其事业战斗的人，这个游击队的规模极小。一方面难以渗透，一方面他们的攻击仅限于抢劫或是恐怖袭击";

$groupusculedetail=" 难以找到能为其事业战斗的人，这个游击队的规模极小。一方面难以渗透，一方面他们的攻击仅限于抢劫或是恐怖袭击";

// Original: $helpbudget="在这里控制你的经费，如果每个月经费不花完的话就浪费了";
$helpbudget="在这里控制你的科研和军备经费，如果每个月的预算不花完的话就浪费了";

// Original: $helpdefcon="DEFCON（战备等级）表示了世界的紧张程度，越低的话就离全球核战争越近，越高的话局势就越缓和。当DEFCON达到1时，那么敌人将会更为主动的挑衅而核战争也成为了可能发生的事";
$helpdefcon="战备等级defcon表示了世界的紧张程度，越低的话就离全球核战争越近，越高的话情势就越放松。如果defcon降低为1，你的对手会更具侵略性，核战争的风险更加真实可感";

// Original: $helpprestige="这里是荣誉分数。拥有最高的荣誉分数的玩家将会胜利，荣誉点数随着外交的良好姿态会获得上升，并且随着关系下降而下降。所有的荣誉分数变化在你的影响范围内翻倍";
$helpprestige="这里是荣誉分数。拥有最高的荣誉分数的玩家将会胜利，荣誉点数随着外交的良好姿态会获得上升，并且随着关系下降而下降。所有的荣誉分数变化在你的影响范围内翻倍";

// Original: $hommeespace="迈向太空";
$hommeespace="迈向太空";
// Original: $hommelune="登月";
$hommelune="登月";


$ids="战略防御计划";

$independantiste="分离主义";
$independantistedetail="这支游击队渴望自我民族的独立.";

$infiltree="被渗透";
// Original: $infiltreedetail="这只游击队被渗透了，如果是被敌对势力渗透的话则会在各种情况下尝到苦头";
$infiltreedetail="这只游击队被渗透了，这可能危及其军事行动和武器供应";
$infiltrerguerilla="渗透这只游击队";


$infiltrepar="渗透来自 ";

$informations="情报";

$instructeurs="军事顾问";
$instructeursshort="顾问";

$invasion="入侵";

$invasionbdfautre="一个地区强权入侵了这个国家.<br> 我们不能对此视而不见！";
$invasionbdfchine="中国部队入侵了这个国家.<br> 我们不能对此视而不见！";
$invasionbdfusa="帝国主义部队入侵了这个国家.<br>  我们不能对此视而不见！";
$invasionbdfurss="苏联部队入侵了这个国家.<br> 我们不能对此视而不见！";

// Original: $invasionimpossible="你不能入侵一个拥核大国的盟友";
$invasionimpossible="你不能入侵一个与超级大国签有防御协议或拥有核武器的国家";

// Original: $invasionimpossibletroupes="你不能入侵有外国驻军的国家";
$invasionimpossibletroupes= "你不能入侵有外国驻军的国家";
$invasionimpossibleenclave="因为地理原因难以入侵这个国家";

$islamique="伊斯兰主义";
// Original: $islamiquedetail="这个游击队希望建立一个哈里法，他只能与同样是伊斯兰原教义主义的游击队同盟";
$islamiquedetail="这个游击队希望依照伊斯兰教法建立一个宗教国家，他只能与同样是伊斯兰主义的游击队结成统一战线";

$jungle='丛林';

$kimphilby="金.菲力比";
// Original: $kimphilbydetail="美国对于东欧的情报动作或的惩罚";
$kimphilbydetail="美国对东欧的颠覆行为受到严重惩罚";

$leader="领袖";

$leadercharismatique="魅力领袖";
// Original: $leadercharismatiquedetail="这个游击队的领袖是一个充满人格魅力的角色，其成长速度与战斗能力获得加成.";
$leadercharismatiquedetail="这个游击队是由一位真正的战士和领袖领导的！其成长速度与战斗能力获得加成.";

// Original: $lyssenkisme="李森科主义";
// In English, his name is usually spelled "Lysenko"
$lyssenkisme="李森科主义";
// Original: $lyssenkismedetail="出于科研圈子里的上纲上线，科研效率获得减成";
$lyssenkismedetail="出于科研圈子里的意识形态上纲上线，科研效率受到减成";


$maffieuse="犯罪集团";
// Original: $maffieusedetail="这个游击队通过贩毒或走私获得其活动资金，如果他们上台的话会导致腐败";
$maffieusedetail="这个游击队通过贩毒或走私获得其活动资金，如果他们上台的话会导致腐败";

$maoiste="毛派";
// Original: $maoistedetail="该运动与中国的毛立场接近";
$maoistedetail="该运动与毛泽东领导下的中国的观点是一致的";


$marxiste="马列主义";
// Original: $marxistedetail="这只游击队信仰共产主义，直接从莫斯科获得指示";
$marxistedetail="这只游击队信仰共产主义，直接从莫斯科获得指示（只要苏联还存在）";

$mauvais='坏';
$mediocre='紧张';
$mefiante='不信任';
$menacer="威胁";
$mercenaires='雇佣军';

$mic="中程导弹";
// Original: $mictm="Multiple Independtly Targeted Reentry Vehicles (MIRVs)";
$mictm="分导多弹头导弹(MIRVs)";
$basedemissiles="核导弹基地";
$manifestations="发动示威";

$missiles="导弹";

$monarchie='绝对君主制';
$monarchieconstitutionnelle='立宪君主制';
$montagne='山区';
$moyenne='平均';

$negociations="谈判";
// Original: $negociationsdetail="这个运动不否定谈判的可能，如果谈判成功他们将会放下武器成为合法的政治力量";
$negociationsdetail="这个运动正与政府展开谈判，如果谈判成功他们将会放下武器参加正常的政治生活";


$neutre="中立";
// Original: $neutretitle="不可能签署防御协议";

$neutretitle="不可能签署防御协议";
$nextturn="下一回合";


$nonalign="不结盟";
$nonalignetitle="与这个国家签署防御协议会更困难";
// Original: $nonbombeA="这个国家还没有核武器";
$nonbombeA="这个国家还没有核武器";
$nondisponiblecolonie="因为是个殖民地，所以不可能这么做.";
// Original: $nondisponibleadmmin="因为处于军事占领状态，所以不可能这么做";
$nondisponibleadmmin="因为处于军事占领状态，所以不可能这么做";
// Original: $nondisponibleaidefaite="一回合只能给予一次经济援助";

$nondisponibleaidefaite="一回合只能给予一次经济援助";
$normal="正常";


$oppositionpro="反对派 忠诚于 ";

// Original: $orggehlendetail="对东欧和巴尔干的颠覆有加成";
$orggehlendetail="对东欧和巴尔干的颠覆获得加成";
$orggehlen="盖伦组织";

// Original: $pacifistes="反战示威";
$pacifistes="反战示威";
// Original: $pacifistesdetail="The higher the score is, the more active the pacifist movements are and generate prestige losses";
$pacifistesdetail="分数越高，反战运动就越活跃并造成荣誉丢失";
// Original: $xdroite="Segregationists movments";
$xdroite="种族主义示威;
// Original: $xdroitedetail="指数越高会导致种族主义者的暴力与分数减少";
$xdroitedetail="分数越高，种族主义运动就越活跃并造成荣誉丢失";
// Original: $contestcivic="Civic contestation";
$contestcivic="民权示威";
// Original: $contestcivicdetail="The higher the score is, the more active the civil rights movements are and generate prestige losses";
$contestcivicdetail="分数越高，民权运动就越活跃并造成荣誉丢失";



$paperclip="回形针计划";
// Original: $paperclipdetail="Plundering the German intellectual resources and recycling numerous nazi scientist enables faster American R&D";
$paperclipdetail="收编旧纳粹科学家与掠夺德国智力资源可以提升美国的科研效率";


$paranoia="偏执";
$paranoiatitle="这个国家对颠覆企图特别有抵抗力";
$panarabisme="泛阿拉伯主义";
// Original: $panarabismedetail="non arabic nations get a malus to opposition in this country";
$panarabismedetail="非阿拉伯国家更难在此地创造反对派";

$partisansbaltes="波罗的海游击队";
// Original: $partisansdetail="Partisans directly wreck havoc in Soviet-controlled territory! They regularly make you lose prestige. The higher their score, the more active they are";
$partisansdetail="游击队在苏联领土上制造浩劫！他们让你丢失荣誉，这个分数越高他们的行动就越频繁";
$partisansupa="乌克兰游击队";

$pasdebudget="预算不足!";

$planmarshall="马歇尔计划";
$points='点数';
$politiqueindustrielle="工业政策";
// Original: $poussernegociation="Encourage to negotiate";
$poussernegociation="鼓励谈判";
$poussercoalition="结成统一战线";
// Original: $pousserdivision="制造反对派";
$pousserdivision="制造反对派";
// Original: $fox="Infiltration FOX";
$fox="FOX Infiltration";

$progres="进度";

$protectorat="保护国";

$protoetat="伪国家";
// Original: $protoetatdetail="This guerrilla carve out a territory for itself that is being administrated like a State, with its own administration, government and currency. They try to gain offical recognition from the international community.";
$protoetatdetail="这个游击队已经成立了一个伪国家，它拥有自己的管理机构和货币，并且积极尝试获得国际支持";

$putch="政变";
// Original: $rappelinstructeurs="Recalling military advisors";

$rappelinstructeurs="召回军事顾问";
// Original: $rappeltroupes="Recalling troops";
$rappeltroupes="召回部队";
// Original: $rappeltoutestroupes="Recalling all your troops";
$rappeltoutestroupes="召回所有部队";

$rapport="全球局势与敌方行动";

$ras="无事发生";

$rechercher="研究中"; 
// Original: $rechercheterminee="研究完成";
$rechercheterminee="科技研究完成了";
$recherchedev="研究与发展";

$relationsusa="与美关系";
$relationsurss="与苏关系";

$reste="余额";

$regime='政府';
$republique='代议共和制';
// The game seems to show the backslash in the phrase "people's republic" within the game; should we try removing it?
$republiquepopulaire="人民民主制";
$riche='发达';
$richesse='财富';

$rurale="偏远游击队";
// Original: $ruraledetail="this guerrilla has supporters among rural populations, which supply and inform the rebels. Fighting them without displacing or constraining populations is complicated. ";

$ruraledetail="这个游击队在偏远地区扎根并且获得本地人口的支持。他们为游击队提供信息。与他们作战非常困难，打击他们将需要限制人口和扩大反游击行动";

$sanctuaire="秘密根据地";
$sanctuairedetail="这个游击队有一个易守难攻的秘密根据地，这导致他们难以被根除.";
$satellite="卫星";
$sauvegardenotavailableyet="存档系统尚不可用";


// Original: $snle="Ballistic Missiles Submarines";
$snle="战略导弹潜艇";


$soutienpopulaire="民众支持";
// Original: $soutienpopulairedetail="this guerrilla enjoys a strong support from the populations, it capable of growing in power faster than other guerrillas.";
$soutienpopulairedetail="多亏了民众的广泛支持，该游击队的增长速度快于其他游击队";


// Original: $sphereusa="美国势力范围内 ";
$sphereusa="该国处于势力范围内：美国 ";
$sphereurss="该国处于势力范围内：苏联 ";
$sphereautre="该国处于势力范围内：";

$stabilite='稳定度';

$stalinisme="斯大林主义";
// Original: $stalinismedetail="指数越高，代表了对社会的专政越紧。指数越低，东欧国家将会尝试脱离你，大于10或小于10的斯大林主义会导致严重后果.";
$stalinismedetail="指数越高，对社会的控制就越紧。指数越低，东欧国家越想尝试脱离你，高于+10或低于-10的斯大林主义指数可能会导致引发严重动荡";

$station="空间站";
$subversion="颠覆";

$taupesmanathan="已潜入曼哈顿计划";
// Original: $taupesmanathandetail="Grants you a bonus in developing A-bomb; the higher the socre is, the higher the research bonus is";
$taupesmanathandetail="允许你在研究原子弹的时候获得加成，指数越高研究越快";

$terrain='地形';
$txtprestige="荣誉分数 ";
$tiersmonde='第三世界';

// Original: $titleaccorddef='title="Defence agreements will increase your prestige and improve the efficiency of your military aids. You will be able to send troops in this country. A country that signs defence agreements with you goes to your side"';
$titleaccorddef='title="防御协定将会增加你的荣誉分数并且增加军援的效率，也允许你派遣你的部队。一个签署了防御协议的国家的立场与你接近"';
// Original: $titleaccordeco='title="Economic treaties will increase your prestige and improve the efficiency of your economic aids"';
$titleaccordeco='title="经济协定将会增加荣誉分数与经济援助的效率"';

$titleactionmilitaire='这些行动将会允许部队的派遣与撤离';


$titleagirguerilla='title="通过渗透或资助来影响游击队"';

// Original: $titlealigner='title="Will align this country on your positions and deteriorate its relations with your opponent"';
$titlealigner='title="将会使该国家的立场与你的立场接近，并且使它与你的对手的关系下降"';
// Original: $titleaideeconomique='title="This action enables the reinforcement of a country\'s stability and wealth as well as improve your relations with it"';
$titleaideeconomique='title="这个行动将会允许你增强国家的财富与稳定性"';
$titlearmeemax='title="This country\'s armed forces are already at their full strength!"';
// Original: $titlebase='title="A base will cost you $5 per month but will grant bonuses to fighting and actions taking place on this territory. A base will also give you a lot of prestige"';
$titlebase='title="每月花费 $5 , 军事基地可以给予大量的荣誉分数与加强本地部队的作战能力"';

$titlecampusa="该国家亲美";
$titlecampurss="该国家亲苏";

$titleconditionsmissilesinsuffisantes='title="还不能建造战略导弹基地"';

$titlefermerbase='title="将会关闭基地与失去荣誉点数!"';
// Original: $titlefermermissiles='title="Will take a weight off your budget and lower tension"';
$titlefermermissiles='title="Will remove the monthly charge from your budget and lower tension"';

$titlecreerguerilla='title="将会创造一个与你的观点相近的游击队"';

// Original: $titlediplomatie='title="Will reinforce your connection with this country, increase your relations and make your other actions more efficient"';
$titlediplomatie='title="将会加强你与这个国家的联系，增加关系与其他外交行动的成功率"';

// Original: $titleembargo='title="Will deteriorate your relations with this country and hamper economic or military aid actions to this country."';
$titleembargo='title="将会大幅度减少你与这个国家的关系，并且削弱其获得的援助"';

// Original: $titleenvoietroupes="Will dispatch troops in this country to defend it against invasions and fight insurgent movements";
$titleenvoietroupes="将会派遣部队用来抵御入侵与清剿起义运动";


// Original: $titleinstructeurs='title="Will dispatch military advisors costing you $5 per month to drill and advise this country\' armed forces"';
$titleinstructeurs='title="将会派遣花费 $5 每月的顾问来帮助这个国家训练其部队"';
$titlerappelinstructeurs='title="召回你的军事顾问"';
$titlemanifestations='title="这个行动可以用来降低当地稳定度"';
// Original: $titlemenacer='title="Threatening a country will deteriorate your relations with it and could possibly finlandise it"';
$titlemenacer='title="威胁这个国家会降低你与他的关系，但可能导致当地稳定度的下降并且可能芬兰化这个国家"';
// Original: $titlemercenaires='title="Will fund a private army to defend this country without you getting directly involved"';

$titlemercenaires='title="将会雇佣匿名的雇佣军为这个国家作战"';

$titlemissile='title="将会建造一座带有核导弹的军事基地来增加核威慑时候的胜利可能"';

// Original: $titleaidemilitaire='title="This action allows to reinforce this country\'s military potential and increase your relations with it"';
$titleaidemilitaire='title="这个行动可以增加国家的军事力量并且增加与其的关系"';
// Original: $titlebudgetinsuffisant='title="Your budget is unsufficient to undertake this action!"';
$titlebudgetinsuffisant='title="你没有足够的预算来进行这个行动！"';


// Original: $titlespere="Your gains and losses in prestige points are double in your sphere of influence";
$titlespere="势力范围内的任何点数变动将会翻倍";
$titlenondisponiblecolonie='title="不能在没有主权的国家进行这些行动"';

$titreactions='你的行动';

// Original: $titleinvasion="Will have you declare war to this country and could provoke a nuclear showdown";
$titleinvasion="将会开战，并且可能导致一场核威慑对决";

// Original: $titleopposition='title="Will create an opposition that you controls in this country and enable new actions"';
$titleopposition='title="将会制造一个你控制的反对派从而解锁新动作"';
$titleoppositionnecessaire='title="你必须控制一个反对派来这么做"';
$titleputch='title="将会尝试推翻这个政府"';

// Original: $titlerappeltroupes='title="撤回你的部队"';
// It would either be "recall your troops" or "bring your troops back home"
// I think "recall troops" is enough
$titlerappeltroupes='title="撤回部队"';

$titlesubversion='title="这些行动可以用来降低国家稳定度"';

$traits="Traits";
// Original: $traitsdupays="Traits, Bonuses et Penalties";
$traitsdupays="特质，增益与惩罚";

$tresbonne="很好";
$tresfaible='很虚弱';
$tresforte='很强大';
$tresmauvais='很紧张';

// Original: $tribale="Tribal";
$tribale="部族";
// Original: $tribaledetail="this guerrilla has an ethnic or tribal origin that limits its national resonance.";
$tribaledetail="这个游击队起源于某个民族或部落，这限制了它的招募能力";

$tribalisme="部族社会";
$tribalismetitle="在该国更容易创建游击队";

$trouble='危机';

$troupes="部队";

$troupesalliees="友军";

// Original: $troupesimpossibles="You need defence agreements to send troops in a country; to invade it, you need execrable relations with it";
$troupesimpossibles="你需要防御协定来派遣部队，若是入侵的话，则需要关系达到濒临入侵";

$txtbdf="威胁核武器打击来要挟撤军!";
$txtbdftitle="导致一次核威慑对决事件";

$txtbdf2="严厉谴责";
$txtbdf2title="无效果";

$urbaine="城市武装";
// Original: $urbainedetail="This guerrilla has roots in cities, particularly within the civil society and academic circles. Negotiations with this type of guerrilla have more chances to succeed";
$urbainedetail="这个游击队有来自有城市的朋友，尤其是学术界和民间结社，因此谈判的成功率会上升";



$voiceof="美国之音";
$voiceofdetail="创建反对派获得加成";

$bonuscomecon="经互会";
// Original: $bonuscomecondetail="Grants a bonus to align countries with an trade agreement with USSR";
$bonuscomecondetail="与拥有贸易协定的集体经济国家进行结盟行动时获得加成";

/// MAj 1950

// Original: $guerreindochine="Indochina War";
// In English, it's universally known as the "Vietnam War", even when the war's actions occurred in nearby countries like Laos or Cambodia
$guerreindochine="越南战争";
// Original: $titlenapalm="将会杀伤本地游击队与入侵部队";
$titlenapalm="将会杀伤本地游击队与入侵部队，并且减少荣誉";
$napalm="凝固汽油弹";

// Original: $titlebombardement="will reduce enemy's stability and its armed forces";
$titlebombardement="将会减少敌人的稳定度与部队数";
$bombardement="战略轰炸";


// Maj Chine

$corruption="腐败 ";

// MOD CHINE

$vaguehumaine="人海战术";
$titlevaguehumaine="通过热诚和人数优势战胜他们！";

$maoisme="毛主义";
// Original: $maoismedetail="The Maoism gauge represents Mao's influence over the party: if it falls below zero, Mao will be removed from power. As long as Mao is in charge, the player may 'maoise' all guerrillas he/she controls and has no diplomatic disadvantage when negotiating with non-aligned countries";

$maoismedetail="毛主义代表了毛对于党的影响力：如果小于零的话毛主席将会隐退，只要毛主席依然在掌控全局就可以毛主义化游击队并且在于不结盟国家沟通时没有惩罚效果";

$superpuissance="超级大国";
// Original: $superpuissancedetail="As long as the superpower gauge is  < 100%, the Chinese player cannot sign any defence agreements nor militarily intervene in countries which are not neighbouring China; its R&D are impacted by a hefty disadvantage and its troops are less efficient than those of other nations. However, the Chinese player has a special action of Human wave.";
$superpuissancedetail="只要该指数没有到达100，就不能与影响范围外的其他国家签署防御协定或进行军事干预，此外部队的作战能力与研究能力会获得惩罚，不过可以使用人海战术";
$superpuissanceacquisedetail="中国现在是一个同美苏平起平坐的超级大国了";

$banditsdetail="国民党流寇在解放战争后依然存在，他们的数字越大，就越有可能冒险妨碍中国的经济";
// Original: $banditssudouest="西南流寇 : ";
$banditssudouest="西南流寇 : ";
// Original: $banditsnordouest="North-West Bandits : ";
$banditsnordouest="西北流寇 : ";
// Original: $banditscentre="Center Bandits : ";
$banditscentre="中原流寇 : ";
$banditsest="东方流寇 : ";
// Original: $banditsnordest="North-East Bandits : ";
$banditsnordest="东北流寇 : ";

$relationschine="与华关系";

$corruption="腐败 ";

$maoisation="毛主义化";

// 1953 -1956

$bananesdulles="杜勒斯主义";
// Original: $bananesdullesdetail="The USA have a major bonus to coups in their sphere of influence";
$bananesdullesdetail="美国在其影响范围内的政变成功率上升";

$americanwayoflife="美国式生活";
$americanwayoflifedetail="加强结盟国家的可能率与创造反对派的可行性";
$pactvarsovie="华约";
// Original: $pactvarsoviedetail="The Soviets have a bonus to their Threaten and Aligning actions in Europe";
$pactvarsoviedetail="在欧洲的结盟与威胁行动获得加强";

$terresvierges="处女地运动";

//1957


$vaguehumaine="人海战术";
$textevaguehumaine="大规模的军事行动<br>
中国志愿军 ";
$txtvaguehumaine="大规模派遣部队 ";

// I haven't seen this pop up in the diary when china usee human wave...
/* 
Original: $projectionforcesimpossibles="Our force projection capabilities do not enable us to invade this country!<br>
";
*/ 
$projectionforcesimpossibles=我们的部队投射能力不足，无法入侵这个国家!<br>
";
$invasionimpossible="无法入侵!";
// Original: $txtinvasionimpossible="This country laugths at rumours of invasion by ";
$txtinvasionimpossible="这个国家嘲笑于谣言-入侵来自 ";

//what??

/* Original:
$maoisationreussie="In guerrilla-controlled areas, the land is collectivised and the peasants masses are freed from exploitation by greedy landlords.<br>
Militants are invited to participate in self-criticism sessions and rightist downward slides denunciations.<br>
Many spies and class enemies are executed or sent to Laojiao (re-education through labor) camps.
<br>Guerrilla strength: -1";
*/ 


// Laogai is more harsh than laojiao, so it should be used to punish counterrevolutionaries
$maoisationreussie="在游击队控制区，土地被快速分配，农民群众不再受到贪婪地主的剥削<br>
游击队领导人开始进行自我批评与谴责右倾思想.<br>
许多特务与阶级敌人被处决或是送去劳改.
<br>游击队力量: -1";
$gainMaoisme_A="<br>游击队获得毛派特性!";
// Original: $gainMaoisme_B="<br>This guerrilla gains the trait Internal Dissents!";
$gainMaoisme_B="<br>游击队失去内部分歧特性!";
$gainMaoisme_B="<br>游击队失去腐败特性!";
$gainMaoisme_D="<br>游击队获得偏远游击队特性!";
$gainMaoisme_E="<br>游击队获得民众支持特性!";
// Original: $gainMaoisme_F="<br>This guerrilla gains the trait Fanatism!";
$gainMaoisme_F="<br>游击队获得狂热特性!";
$gainMaoisme_G="<br>来自其他国家的渗透被肃清了!";
$nommaoisation="毛主义化";

// Original: $maoisationguerilla="Maoising the guerilla";

$maoisationguerilla="使游击队向毛派观点靠拢";
// 1953 -1956

$bananesdulles="杜勒斯主义";
$bananesdullesdetail="美国在其影响范围内的政变成功率上升";

$americanwayoflife="美国式生活";
$americanwayoflifedetail="加强结盟国家的可能率与创造反对派的可行性";
$pactvarsovie="华约";
$pactvarsoviedetail="在欧洲的结盟与威胁行动获得加强";

$terresvierges="处女地运动";

// 1958

$nasseriste="纳赛尔主义";
// Original: $nasseristedetail=" this guerrilla fights for an ideal of Arab union around Nasser's Egypt. The country will join the United Arab Republic if this guerrilla seizes power.";
$nasseristedetail=" 这只游击队为阿拉伯民族统一的理想而战，如果游击队夺权该国会加入埃及领导的阿拉伯联合共和国";

$politiqueagricole="农业政策";

$sousequipee="装备落后";
// Original: $sousequipeedetail=" Firearms are rares and most fighters in this guerrillas only have machetes, agricultural tools or old muskets.";
$sousequipeedetail=" 现代装备在这只游击队内很少，大多数战士只有砍刀，农具和老式火枪.";

$banditstibet="西藏流寇: ";

$aidecuba="古巴援助:";

// 1959

$foco="游击中心论";
// Original: $focodetail="Bonus to create guerrillas in the Third World. Marxist guerrillas with the trait Rural are more efficient.";
$focodetail="获得第三世界内创造游击队的加成，拥有偏远属性的马列主义游击队在战斗时会更有效率.";

$allianceprogres="进步联盟: ";
$politiquessociales="社会政策: ";

$txtdefaite="国家战败";

$panarabisme="泛阿拉伯主义";
// Original: $panarabismedetail="Non-Arab nations have a penalty to creating oppositions in this country";
$panarabismedetail="非阿拉伯国家更难在这个国家创造反对派";

$doctrinelemay="勒梅主义";
// Original: $doctrinelemaydetail="Bonus +2 to your nerves score in case of nuclear showdown";

$doctrinelemaydetail="在核威慑中你的意志被加强2";
// 1963

$telephonerouge="莫斯科-华盛顿热线";
// Original: $telephonerougedetail="The USA and the USSR can see the nerves gauge of the adversary in case of showdown, unless the opponent is a Bluffer";
$telephonerougedetail="苏联与美国可以看见对手的紧张度，除非对手是玩暗牌的好手";
$importations="进口";

// Original: $progouv="亲政府";
$progouv="亲政府";
// Original: $progouvdetail="This guerrilla fights beside the government (...for now)";
$progouvdetail="这个游击队支持现政府 (……至少现在)";

$bomblaos="轰炸胡志明小道";
$rollingthunder="滚雷 ";

$bonuschelepine="国际革命";
// Original: $bonuschelepinedetail="Bonus to support to guerrillas actions";
$bonuschelepinedetail="支持游击队行动获得加成";

// Original: $bonusmikoyan="软实力";
$bonusmikoyan="柔和力量";
// Original: $bonusmikoyandetail="Bonus to relations in case of economic aid";
$bonusmikoyandetail="经济援助提升好感加成";

// Original: $baas="复兴主义";
$baas="复兴主义";
$baastitle="这个意识形态让你创造反对派获得-1惩罚";

$freresmusulmans="穆斯林兄弟会";
// Original: $freresmusulmanstitle="A formidable ideological competition that gives a penalty of 1 to the creation of oppositions";
$freresmusulmanstitle="这个意识形态让你创造反对派获得-1惩罚";

$nasserisme="纳塞尔主义";
// Original: $nasserismetitle="A formidable ideological competition that gives a penalty of 1 to the creation of oppositions";
$nasserismetitle="这个意识形态让你创造反对派获得-1惩罚";

$islamisme="原教旨主义";
// Original: $islamismetitle="A formidable ideological competition that gives a penalty of 1 to the creation of oppositions";
$islamismetitle="这个意识形态让你创造反对派获得-1惩罚";

$concurrencesideologiques="意识形态对手";

// 1966

$theologieliberation="解放神学";
$theologieliberationtitle="苏联的示威抗议行动与美国的政变行动获得加成";
$livrerouge="毛主席语录";
$livrerougedetail="创造反对派行动获得加成";

$ong="非政府组织";
// Original: $ongtitle="The NGOs grant bonuses to economic aids and disadvantages to governments in their counter-insurgency operations.They can also denounce the abuses from each stakeholders";
$ongtitle="非政府组织（NGO）让经济援助更为有效，然而也会阻碍政府军的反叛军行动并且谴责暴行";

$onu="维和部队";
// Original: $onutitle="一只联合国部队正在维护区域稳定，减少正规模的军队冲突";

$onutitle="一只联合国部队正在维护区域稳定，减少大规模的军队冲突....除非有一方将它们当做了目标";
$sinai="以色列占领西奈半岛";
$sinaititle="埃及也许会因此攻击以色列，如果埃及觉得自己实力足够强大的话（叙利亚也有可能加入）";

$golan="以色列占领戈兰高地";
$golantitle="叙利亚也许会因此攻击以色列，如果叙利亚觉得自己实力足够强大的话（埃及也有可能加入）";

// MODE FRANCE

$reconstruction="重建进度: ";
// I don't really understand what "by group of 25%" indicates here.
// Fixed 
// Original: $reconstructiondetail="Shows the level of reconstruction of the country. You gain +$5 in your budget by group of 25%.";

$reconstructiondetail="展示法国重建的进度。每当重建进展25%，你的预算+5$";
$influencepcf="法共影响力";
// Original: $influencepcfdetail="A PCF influence of zeo will trigger strikes while a high score can generate more serious insurectional strikes if the PCF does not participate to the government";
$influencepcfdetail="为零的法共影响力会导致罢工蔓延，而过高的法共影响力会导致严重的政治危机，如果法共不参与政府体系的话，";

$empirefrancais="殖民帝国";
// Original: $empirefrancaisdetail="You can recruit troops in your colonies and you lose prestige when your colonies secure their independence";
$empirefrancaisdetail="你可以在殖民地招兵，但当殖民地独立会失去荣誉点数";

// Original: $tripartisme="Tripart Government";
$tripartisme="三党政府";
// Original: $tripartismedetail="Your nerves gauge is set to 1 in case of showdown";
$tripartismedetail="在核武对决时，你的紧张度设为1";

$troupescoloniales="殖民地部队";
// Original: $titletroupescoloniales="You can use colonial troops in your empire.";

$titletroupescoloniales="可以在你的帝国内招募殖民地部队.";
$relationsfrance="与法关系";

$atlantisme="大西洋主义";
// Original: $atlantismedetail="When this score is negative, you have a bonus to diplomatic actions with non-aligned countries. When it is positive, your armies are more efficient as are your colonial troops actions";
$atlantismedetail="当这个指数为负的时候，获得对不结盟国家的外交优势，当这个指数是正的时候，你的军队和殖民地部队的作战能力更高";
$franceotan="北约成员";
$franceotandetail="你可以使用凝固汽油弹!";

$milicesviet="创建民兵武装";
$titlemilicesviet="可以创建民兵武装";

$quatriemerepublique="第四共和国";
$quatriemerepubliquedetail="由于政治局势不稳定，你的外交行动受到惩罚";

// Original: $bienetrebrejnev="brezhnevian well being";
$bienetrebrejnev="勃列日涅夫主义";
// Original: $bienetrebrejnevdetail="你的斯大林主义会缓慢变为零";

$bienetrebrejnevdetail="随着时间的推移，斯大林主义分数会逐渐趋于零";
//MGS

$guerillafox="Infiltrated by FOX";
$guerillafoxdetail="Agents from the FOX elite unit infiltrated this guerrilla, granting you a significant bonus to all your actions with it.";

$guerillaboss="Boss";
// Original: $guerillabossdetail="This organisation hosts an evil genious or a super henchman, so efficient that the agents operating against it will have to overcome him/her before continuing their mission. (The risks of injury and/or capture are higher for your agents when they fight a boss)";
$guerillabossdetail="This organisation hosts an evil genius -- so efficient that the agents operating against it will have to overcome that individual before continuing their mission. (The risks of injury and/or capture are higher for your agents when they fight a boss.)";

$snake="Deploy Snake ";
$sigint="Sigint";
$halo="HALO jump";
$paramedic="Para-Medic";
$osp="OSP";
$xof="XOF";
$shagohod="Shagohod";
$activesonar="Active Sonar";
$snakeeater="Snake Eater";
$fakedeathpill="Fake Death Pill";

$foxko="Snake is injured! He can continue his mission but will be less efficient!";

// Original: $snakecapture="Snake is prisoner";
$snakecapture="Snake is imprisoned";
$snakecapturedetail="Snake is currently unavailable for missions";

$snakeblesse="Snake is injured";
$snakeblessedetail="Snake is currently unavailable for missions";

$sokolov="Sokolov";
$sokolovdetail="You have a bonus to your Shagohod R&D";

$contextmission="Analysis of the enemy's strengths and weaknesses";
$briefing="Briefing";

$paramedic="Para-Medic";

$txtfindelamission="Mission complete";

/* Original:
$biosnake="Snake is an elite agent of the FOX Unit.<br>
He will wreak havoc in guerrilla groups you assign him.<br>
Snake however only becomes extremely efficient if you develop FOX technologie.<br>
 ";
*/ 
$biosnake="Snake is an elite agent of the FOX Unit.<br>
He will wreak havoc in any guerrilla group where you assign him.<br>
However, he will only become extremely efficient if you develop FOX technology.<br>
 ";

$bonusdesnake="Snake's bonuses";

/* Original: 
$txtxof="Snake is supported by assisted by a ghost team led by Skullface that prepares the ground for him and clean any traces of his mission. Only Major Zero and very few other handpicked high-level officials are aware of the existence of this unit.<br>
Snake's effiency: +1<br>
Chances of being captured: -2 <br>";
*/ 
$txtxof="Snake is assisted by a ghost team led by Skullface which will prepare the ground for him and remove any traces of his mission. Only Major Zero and a few other handpicked high-level officials are aware of the existence of this unit.<br>
Snake's effiency: +1<br>
Chances of being captured: -2 <br>";

/* Original: 
$txtsigint="Snake is supported by the expert on weapons, equipment and cutting-edge technology Sigint, who flies above the operational area at high altitude with the rest of the support team.<br>
His advice is precious in numerous situations.<br>
Snake's effiency: +1<br>
Efficiency against Bosses: +4 <br>
";
*/
$txtsigint="Snake is supported by an expert on weapons, equipment, and cutting-edge sigint technology, which flies above the operational area at high altitude with the rest of the support team.<br>
His advice is essential in numerous situations.<br>
Snake's effiency: +1<br>
Efficiency against Bosses: +4 <br>
";

/* Original: 
$txthalo="Snake is airdropped directly on his mission objective from a high altitude and the low altitude opening of his parachute lets him get past radar detection, effectively easing his infiltration.<br>
Snake's effiency: +1<br>
Efficiency against Sanctuaries: +2 <br>
";
*/
$txthalo="Snake is airdropped directly above his mission objective from a high altitude, and the low altitude opening of his parachute effectively eases his infiltration by evading radar and anti-air defenses.<br>
Snake's effiency: +1<br>
Efficiency against Sanctuaries: +2 <br>
";

/* Original:
$txtparamedic="Snake is supported by the medical expert Para-Medic who is capable of providing direct medical advice on how to treat his wounds and survive.<br>
Chances of being injured: -4<br>
Recovery time from injuries significantly reduced<br>";
*/ 
$txtparamedic="Snake is supported by the medical expert Para-Medic, who is capable of providing direct medical advice on how to treat his wounds and survive.<br>
Chances of being injured: -4<br>
Recovery time from injuries is significantly reduced<br>";

$txtfakedeathpill="Thanks to this pill, Snake is able to simulate death and escape his enemies.<br>
Chances of being captured: -3<br>
";

/* Original: 
$txtactivesonar="This sonar allows Snake to detect potential enemeies from afar, making him very efficient in infiltration missions.<br>
Snake's effiency: +3 (bonus becomes void past the 4th stage of a long mission)<br>
";
*/
$txtactivesonar="This sonar allows Snake to detect potential enemies from afar, making him very efficient in infiltration missions.<br>
Snake's effiency: +3 (this bonus becomes void past the 4th stage of a long mission)<br>
";

/* Original:
$txtosp="This training allows Snake to use any enemy weapon or equipment found in the operational area. Our agent is thus airdropped without any disctinctive equipment to avoid the enemy connecting him to us should he be captured.<br>
Snake's effiency against groups with Heavy Weapons: +2<br>
Snake's effiency against groups with the trait Mafia: +2<br>
Snake's effiency against Underequipped groups: -1<br>
";
*/ 
$txtosp="This training allows Snake to use any enemy weapon or equipment found in the operational area. He is thus airdropped without any distinctive equipment, to avoid the enemy associating him with us should he be captured.<br>
Snake's effiency against groups with Heavy Weapons: +2<br>
Snake's effiency against groups with the trait Mafia: +2<br>
Snake's effiency against Underequipped groups: -1<br>
";
$snakezerobonus="Snake has no bonus for the moment";

//1981

$doctrinereagan="里根主义";
$doctrinereagandetail="资助游击队获得2加成";



// MODE FRANCE
// Is this section a duplicate?
// All changes I made were in the previous section

$reconstruction="重建进度: ";
// Original: $reconstructiondetail="Indicates the progression of the national reconstruction. You gain $5 in your budget for each slice of 25% achieved;";
$reconstructiondetail="展示法国重建的进度。每当重建进展25%，你的预算+5$";

// Original: $influencepcf="Influence of the PCF";
$influencepcf="法共影响力";
// Original: $influencepcfdetail="A score of zero for the influence of the PCF will generate strikes; a very high score could generate way more serious insurrectional trikes if the PCF does not participate to the government";
$influencepcfdetail="为零的法共影响力会导致罢工蔓延，而过高的法共影响力会导致严重的政治危机，如果法共不参与政府体系的话，";


$empirefrancais="殖民帝国";
$empirefrancaisdetail="你可以在殖民地招兵，但当殖民地独立会失去荣誉点数";

// Original: $tripartisme="Tripart Government";
$tripartisme="三党政府";
// Original: $tripartismedetail="Your nerves gauge is set to 1 in case of showdown";
$tripartismedetail="在核武对决时，你的紧张度设为1";

$troupescoloniales="殖民地部队";
$titletroupescoloniales="可以在你的帝国内招募殖民地部队.";

// Original: $relationsfrance="France relations";
$relationsfrance="与法关系";

$atlantisme="大西洋主义";
/* Original: 
$atlantismedetail="When this score is negative, you enjoy a bonus to diplomacy actions with non-aligned countries.
When this score is positive, your armies are more efficient as are your colonial troops actions.";
*/
$atlantismedetail="当这个指数为负的时候，获得对不结盟国家的外交优势，当这个指数是正的时候，你的军队和殖民地部队的作战能力更高";
$franceotan="北约成员";
$franceotandetail="你可以使用凝固汽油弹!";

$milicesviet="创建民兵武装";
$titlemilicesviet="可以创建民兵武装";

$quatriemerepublique="第四共和国";
$quatriemerepubliquedetail="由于政治局势不稳定，你的外交行动受到惩罚";

$bienetrebrejnev="勃列日涅夫主义";
$bienetrebrejnevdetail="随着时间的推移，斯大林主义分数会逐渐趋于零";







// Original: $bienetrebrejnev="brezhnevian well being";


$escadronmort="死亡小队";
/* Original: 
$escadronmortdetail="这只游击队擅长对抗异议人士与活动者<br>
他会使用折磨恐吓，并且通过制造恐怖和暗杀达到其目的.<br>
";
*/
$escadronmortdetail="这只游击队擅长对抗异议人士与活动者.<br>
他会使用折磨恐吓，并且通过制造恐怖和暗杀达到其目的.<br>
";


$guerillaattentiste="观望";
$guerillaattentistedetail="这个国家的局势是如此混乱和令人困惑，以至于这只游击队决定采取观望等待局势下一步发展（或者它正在为新的进攻积蓄力量）";

// Display INFO about traits

$titretraits="特质的描述";
$titreterrain="地形";
// Original: $texteterrain="If the terrain is jungle or mountrain, fighting the guerrilla groups will be more difficult and the country will defend better against invaders. The guerrilla groups that appear in these countries have a higher chance to spawn with certain Traits like \"Rural guerrilla\" or \"Sanctuary\"";
$texteterrain="如果地形是山区或从林的话，敌人更难以入侵并且游击队更难根除，并且出现在该国的游击队更有可能获得偏远游击队或秘密根据地特性"";

$titrefinlandisation="芬兰化";
$textefinlandisation="这个国家如同二战后的芬兰一样被迫严守中立，不能与其签署防御协议.";

$titrenonalignement="不结盟";
// Original: $textenonalignement="This country refuses to enter the logic of a bipolar world and distrusts both the USA and the USSR. Signing defefence agreements with it is possible but there are hefty maluses to this action (in short, this trait is a less restrictive version of the \"Neutral\" Trait. A neutral country can also be Non-aligned, showing this way a strong will of independence.";
$textenonalignement="这个国家拒绝常规的冷战思维，和它签署防御协议会更困难但不是不可能，一个中立的国家也可能是不结盟的，这显示该国强烈的独立意愿。";

$titreneutralite="中立";
$texteneutralite="不管什么情况，这个国家都不会签署防御协议，并且会尝试向中立的外交方向靠拢.";

$titrepayscorrompu="腐败";
// Original: $textepayscorrompu="这个特性是个噩梦，经济援助更难被接受虽然可以更容易提高好感度，但是因为整体的腐败如同病菌一样侵蚀着机构，所以更容易去颠覆这个政府，也许可以通过政治格局的变化来消除这个特性但这可能性不大 ";
$textepayscorrompu="这个特质是真正的噩梦，经济援助更难帮助国家的发展和稳定虽然可以更容易提高政府好感度，但是因为整体的腐败如同病菌一样侵蚀着机构，所以更容易去颠覆这个政府，也许可以通过政权更迭来消除这个特质但这可能性不大. ";

$titrepuissancenucleaire="核武器";
// Original: $textepuissancenucleaire="Whether officially or in a secret manner, this country owns nuclear weapons. The nuclear arsenal of this country is really modest when compared to those of the superpowers but a single atomic bomb on Moscow or Washington is all what it takes to force you to consider it twice: the players cannot invade this country anymore!";
$textepuissancenucleaire="不管是官方宣称还是秘密，不管数量和质量，一颗核武器使得莫斯科和华盛顿无法预估入侵的后果——这个国家再也不能被入侵了!";

$titrepaystribal="部族社会";
/* Original: 
$textepaystribal="This country is comprised of several ethnic, tribal, linguistic or religious groups.
An ill-intentioned power or irresponsible politicians can take advantage of this characteristic to provoke armed conflicts. The actions to create a guerrilla are easier in such countries but encouraging violence can result in an endless circle...";
*/
$textepaystribal="这个国家由不同的民族群体，部落，宗教或是语言使用者组成.
可以轻而易举的挑动他们之间的争执和煽动武装冲突.创造游击队变得更容易了，但是鼓励暴力很有可能招致无休止的报复循环...";


$titreparanoiaque="偏执";
$texteparanoiaque="这个政府非常敏感于内部安全问题，创造反对派和政变几乎是不可能的.";

$titreong="非政府组织";
// Original: $texteong="NGOs are operating in this country and are very active. They notably increase the effect of economic aids. They can alert on massacres and crimes against humanity which could emerge in countries where they operate, possibly disturbing anti-guerrilla operations as a result.";
$texteong="非政府组织（NGO）活跃于这片地区，他们可以大幅度提升经济援助的效率，也会警告反人类罪行的发生，导致反游击队受阻碍";

$titreonu="蓝色贝雷帽";
$texteonu="一只蓝色贝雷帽在该地区维护和平，这会阻止交战双方的火并，直到他们认为维和部队是个有趣的目标.... ";

// Original: $titresinai="Occupation of Sinai";
$titresinai="占领西奈半岛";
/* Original: 
$textesinai="以色列占领了埃及宣称的领土.埃及也许会因此攻击以色列，如果他的实力足够的话（叙利亚也有可能加入，如果戈兰高地被占领）";
*/
$textesinai="以色列占领了埃及宣称的领土.埃及也许会因此攻击以色列，如果他的实力足够的话（叙利亚也有可能加入，如果戈兰高地被占领）.
";

$titregolan="占领戈兰高地";
/* Original:
$textegolan="以色列占领了叙利亚宣称的领土.叙利亚也许会因此攻击以色列，如果他的实力足够的话（埃及也有可能加入，如果西奈半岛被占领）";
*/
$textegolan="以色列占领了叙利亚宣称的领土.叙利亚也许会因此攻击以色列，如果他的实力足够的话（埃及也有可能加入，如果西奈半岛被占领）";

$titreideologies="意识形态";
// Original: $ideologiescommentaire="虽然也许不被本地政府接受，但这些意识形态在本地有强大的影响力.";
$ideologiescommentaire="虽然也许不被本地政府接受，但这些意识形态在本地有强大的影响力.";

$titrebaasisme="复兴主义";
// Original: $textebaasisme="Ba'athism is a lay Arab resurrection school of thought that combines Arab socialism and Panarabism. Ba'asthism is very critical toward Marxism but Western imperialism is the same boat. This is a serious ideological alternative that generates a disadvantage (-1) to the creation of oppositions.";
$textebaasisme="复兴主义是一个世俗的泛阿拉伯意识形态，包含了阿拉伯社会主义与民族主义元素，倾向于泛阿拉伯主义——其观点在反帝的同时也批评马克思主义.这是一个严肃的替代意识形态，使得有一个（-1）的组建反对派的惩罚.";

// Original: $titrefreresmusulmans="Muslim Brothers";
$titrefreresmusulmans="穆斯林兄弟会";
// Original: $textefreresmusulmans="The ideology of the Muslim Brothers is well rooted in this country. This movement advocates for an islamic rebirth. Born in the 1920s, this school od thought spreaded across the islamic world where it is a staunch opponent of the ruling lay governments. This is a serious ideological alternative to liberalism and Marxism, resulting in a disadvantage (-1) to the creation of oppositions.";
$textefreresmusulmans="穆斯林兄弟会在这个国家已经扎根了，起源于1920年代，穆斯林兄弟会的普遍目标是伊斯兰的第二次复兴，由于各种意义上与传统的自由主义理念和无神论的马克思主义冲突，所以导致（-1）创造反对派的惩罚.";

// Original: $titreislamrigoriste="Rigoristic Islam";
$titreislamrigoriste="原教旨主义";
/* Original: 
$texteislamrigoriste="This catch-all category hosts schools of thought, such as Wahhabism or Salafism, extolling a return to the origins of the Islamic faith.
These ideologies do not get along with Marxism and political liberalism, resulting in a disadvantage (-1) to the creation of oppositions.
";
*/
$texteislamrigoriste="包含了瓦哈比派和萨拉非派，这些狂热的伊斯兰思潮希望返回其原始时期的信仰。这些思潮与几乎一切世俗的思潮冲突，比如自由主义和马克思主义，这导致了（-1）创造反对派的惩罚
";


$titrenasserisme="纳赛尔主义";
/* Original: 
$textenasserisme="The nationalist and Panarabic ideal of Nasser fired the imagination of the Arab world. Gamal Abdel Nasser indeed let it glimpse a world where the Arab nations could oppose the former colonial powers and go up against Israel. This is a serious ideological alternative to liberalism and Marxism, resulting in a disadvantage (-1) to the creation of oppositions.
";
*/
$textenasserisme="民族主义和泛阿拉伯主义的理想在纳赛尔的许诺下看起来非常的真实了，这将会是一个阿拉伯国家反抗前帝国主义殖民者与以色列的联合体，这个思潮导致了其在阿拉伯地区的流行并且严肃的与其他意识形态分野——因此拥有（-1）对创造反对派的惩罚.
";


$titretheologieliberation="解放神学";
/* Original: 
$textetheologieliberation="Starting from Marxist statements and analysis, a theological school of thought emerged with a view to give back the poors their dignity. This is a theology of action which agitates the South and Centrak American societies; Washington considers this a serious threat. The USA gain a bonus to coup actions and the Soviets to their protest marches actions.
 ";
*/
$textetheologieliberation="流行于拉美，起源于马克思主义，主张基督教应以争取被压迫、被剥削而处于“非人”的贫困中的人们，获得物质和精神生活的解放为宗旨的基督教神学思潮.这是一个对于华盛顿在拉丁美洲利益严重影响的思潮，同时也使得拉美群众更容易被煽动.因此，华盛顿在这些国家获得政变加成而苏联获得组织示威加成
 ";


$titrepolitique="政体";

$titrerepublique="代议共和制";
// Original: $texterepublique="The most sensitive regime when facing subversion actions. Oppositions are easily created and protest marches are less difficult to encourage. The social contestation has a chance to be taken into account and addressed by the goverment.";
$texterepublique="由于宽容，这种政体在面对颠覆行动时显得脆弱——反对派可以被轻而易举的创建，游行很容易被煽动，但是这些行动有可能会导致政府认真考虑社会矛盾问题并且解决它们，增加大幅度稳定.";

$titremonarchieconsti="立宪君主制";
/* Original: 
$textemonarchieconsti="从游戏机制上来说，和共和制非常相似但较难鼓动人们参加示威<br>
 创建示威惩罚: 1";
*/
$textemonarchieconsti=""从游戏机制上来说，和共和制非常相似但较难鼓动人们参加示威<br>
 创建示威惩罚: 1";
*/";

$titremonarchie="绝对君主制";
/* Original: 
$textemonarchie="This is a sensibly \"tougher\" form of monarchy where criticising the monarch can lead you to a grim cell. This type of regime is not easily destabilised. The population is often better controlled by the regime than the various clans or the army; this leaves the government vulnerable to palace revolutions or creations of guerrillas.<br>
Disadvantage to creating opppositions: 2<br>
Disadvantage to organising protest marches: 2";
*/
$textemonarchie="这是严厉的，与立宪君主制有很大差距的另外一种古老的君主制.权力经常被封建家族或军阀掌控，个人口当中的微词有可能导致铁窗泪，但这让政府在面对宫廷革命或阻止游击队成立方面时非常脆弱.<br>
创建反对派惩罚: 2<br>
创建示威: 2";

$titredictature="威权独裁制";
/* Original: 
$textedictature="This is the default regime set by the USA when they overthrow a government. The dictatorship is fairly resilient to subervsion actions and can even use these opportunites to wipe the opponents, destroying the oppositions you control in the process.<br>
Disadvantage to creating opppositions: 2<br>
Disadvantage to creating guerrillas: 2<br>
Disadvantage to organising protest marches: 2<br>
Disadvantage to coup actions: 2";
*/
$textedictature="这是美国推翻一个政府时使用的体系，本质上威权主义与依赖官僚机关，这种政府不会轻易的屈服于颠覆活动，并且可以借各种机会肉体消灭其反对者，摧毁你的反对派<br>
创建反对派惩罚: 2<br>
创建游击队惩罚: 2<br>
创建示威惩罚: 2<br>
政变惩罚: 2";

$titrereppop="人民民主制";
/* Original: 
$textereppop="这是苏联推翻一个政府时使用的体系，和独裁类似但是因为个人崇拜草根民主和强大的意识形态教育等，会比一般的威权主义体制难以摧毁<br>
Disadvantage to creating opppositions: 4<br>
Disadvantage to creating guerrillas: 4<br>
Disadvantage to organising protest marches: 4<br>
Disadvantage to coup actions: 4<br>";
*/
$textereppop="这是苏联推翻一个政府时使用的体系，和独裁类似但是因为个人崇拜草根民主和强大的意识形态教育等，会比一般的威权主义体制难以摧毁.<br>
创建反对派惩罚: 4<br>
创建游击队惩罚: 4<br>
创建示威惩罚: 4<br>
政变惩罚: 4<br>";

$titreetatislamique="原教旨神权";
/* Original: 
$texteetatislamique="This regime believes you are the Great Satan himself and regurlarly reminds you they will not treat with the archenemy, what does not help keeping good diplomatic relations.<br>
Disadvantage to creating opppositions: 4<br>
Disadvantage to signing defence agreements: 2<br>
Disadvantage to signing economic treaties: 2<br>
Disadvantage to relations improvement via economic aids: 2<br>
Disadvantage to alignement actions: 4<br>
Disadvantage to installing military bases: 4<br>
Disadvantage to organising protest marches: 4<br>
Disadvantage to \"threaten\" actions: 4<br>
Disadvantage to coup actions: 4<br>";
*/
$texteetatislamique="这个原教旨政权认为你就是大撒旦本尊并且发誓绝对不会与恶魔有妥协，这导致了他们外交上的孤立和内政方面对于宗教律法的狂热.<br>
创造反对派惩罚: 4<br>
签署防御协议惩罚: 2<br>
签署经济协议惩罚: 2<br>
经济援助提升好感惩罚: 2<br>
结盟惩罚: 4<br>
设立军事基地惩罚: 4<br>
创建示威惩罚: 4<br>
威胁成功率惩罚: 4<br>
政变惩罚: 4<br>";


$titreadministrationmilitaire="军事管理区";
/* Original: 
$texteadministrationmilitaire="This territory is controlled by an occupation force. The political life here has not yet returned to normal.<br>
Bonus to economic aids (for the player administrating the territory) +4<br>";
*/
$texteadministrationmilitaire="这个地区处于外国的军事管理，还没有形成政治系统.<br>
经济援助加成 +4<br>";

$titrecolonie="殖民地与保护国";
$textecolonie="这个地区的主权属于一个殖民帝国
. <br> 在独立之前无法与其交互
. <br>
成功的游击队会导致国家的独立.";




$titrestabilite="稳定度";
/* Original: 
$textestabilite="
The higher the stability is, the stronger the country will be:<br>
- Its troops will put a better fight<br>
- It will be more resilient to subversion actions<br>
- The economic aids will be more efficient<br>
When the stability hits \"chaos\", the government can fall at any time.
On the contrary, a country with exceptional stability will feel so strong that it will be less inclined to sign defence agreements with a player (why would you need a protector when you are powerful?).<br>";
*/
$textestabilite="
稳定度越高，政权本身越稳固:<br>
- 他的部队会更强大<br>
- 他将更好的应对颠覆行动<br>
- 援助会更有效<br>
当稳定度到达低谷时，政府随时有可能终结
然而，一个政府越强大，其与玩家沟通的欲望也就越低，为什么需要无故祈求别人的帮助呢？
<br>";

$titrerichesse="财富";
/* Original: 
$texterichesse="
represents the level of economic development in the country. The poorer a country is, the more sensitive it is to your economic aids. The level of wealth also impacts the Traits of the guerrillas groups created in a country.<br>";
*/
$texterichesse="
代表了本地的发展程度，越贫困的国家对经济援助效果越明显，同时财富也影响着国家中游击队的特性.<br>";

$titreeconomie="经济";
/* Original: 
$texteeconomie="
Either market or collectivist, the economy is affected by economic aids. Collectivist economies benefitiate less from economic aids than their market counterparts. The USSR, thanks to the COMECON, has a bonus to aligning collectivist countries with which it has economic treaties.<br>";
*/
$texteeconomie="
不管黑猫白猫，经济都会收到援助的增援，然而市场经济对于外资的利用会更好，苏联的经互会使之在与苏联签订经济条约的集体经济国家开展结盟行动时获得加成。<br>";

$creerstaybehind="暗中密谋";
// Original: $titlecreerstaybehind="Create a secret army that will become active in case of communist regime";
$titlecreerstaybehind="制造一只当共产主义夺权时出来工作的秘密军队";

$guerillastaybehind="暗中密谋";
/* Original:
$guerillastaybehinddetail="This guerrilla group is a secret army trained to underground warfare.<br>
Its mission is to collect intelligence on communist forces activities, engage into sabotage actions and develop partisan networks. Thanks to its existence, this army grants the USA a bonus to the creation and funding of guerrillas. This army, because of its high level of compartmentalisation, is extremely difficult to eradicate.";
*/
$guerillastaybehinddetail="这只游击队是一只秘密的地下军队.<br>
他的任务是辅助其他游击队，收集情报，渗透机关，并且为美国在本地建立和资助游击队获得加成，并且本身也隐蔽度高，极难铲除。";


$staybehind="暗中密谋";
// Original: $staybehindtitle="A secret army is ready to come into operation should the communists seize power";
$staybehindtitle="一只秘密军队将会准备在共产主义者夺权时反攻";

$titrestaybehind="暗中密谋";
// Original: $textestaybehind="An anti-communist secret army will come into operation should the communists come to power.";
$textestaybehind="一只秘密军队将会准备在共产主义者夺权时反攻.";

// Original: $titleactiverstaybehind="Activtate this group in absence of an invasion is irresponsible";
$titleactiverstaybehind="没有入侵时要求激活暗中密谋是没有理由的";
$activerstaybehind="激活暗中密谋";

$syndicalismelibre="自由工会运动";
// Original: $syndicalismelibretitle="Some would call it company unionism: this Trait generates a disadvantage to the Soviets when it comes to organising protests marches";
$syndicalismelibretitle="有些人干脆称之为公司工会主义（黄色工会运动）。这一特质使苏联在组织示威游行方面受到惩罚";

$titresyndicalismelibre="\"黄色\" 工会运动";
// Original: $textesyndicalismelibre="The World Federation of Trade Unions is dominated by the communists. Their hegemony is challenged by trade unions seeking independence. This tendency led to the creation of an International Confederation of Free Trade Unions in 1949. Strongly influence by the American secret services, this movement will progressively become more independent and critical toward the American policy. The divisions among the trade unions generate a disadvantage for the USSR when it comes to organising protests marches.";
$textesyndicalismelibre="世界的工运组织大多同情与工团主义或者是共产主义，但是1949年创立了独立工会运动.这些工会被美国高度渗透并且拒绝参加马克思主义相关的罢工，这导致了苏联在本地创建示威的惩罚.";

$gaullisme="戴高乐主义";
// Original: $gaullismetitle="Disadvantage to threaten and alignement actions";
$gaullismetitle="威胁和结盟行动受到惩罚";

$titregaullisme="戴高乐主义";
/* Original: 
$textegaullisme="The influence of General de Gaulle on the French political life is such that it gave birth to word to summarise it: Gaullism.<br> Gaullism is a conservative pragmatic school of though promoting the unity of the nation and social cohesion. In-game, Gaullism will mostly be visible in its staunch refusal to compromise on national sovereignty; this ideology comes with heftu disadvantages to your \"Align\" and \"Threaten\" actions.
";
*/
$textegaullisme="这是法国的戴高乐对于法国政府的影响<br> 戴高乐主义是实用主义，保守主义，倾向于社会团结与国家团结的意识形态，在游戏中这将会成为法国主权维护的思想-你的结盟与威胁行动受到惩罚
";

$demochretienne="基督教民主主义";
// Original: $demochretiennetitle="The USA have a bonus to their aligment actions";
$demochretiennetitle="美国对该国的结盟行动获得加成";

$titredemochretienne="基督教民主主义";
/* Original: 
$textedemochretienne="Christian democracy draws its inspiration from the values of Christian humanism. Since the end of WW2, Christian democracy has a central role in the political life of many European countries. The fear of communism and the weakening of traditional right-wing parties (a 'side effect' of the war) provide a fertile ground for its political growth and stability. Communism and its perceived daemons made these parties strongly Atlanticist. The USA have a large bonus to the aligment actions in the countries where this ideology is present.";
*/
$textedemochretienne="基督教民主主义起源于基督教人道主义，自二战结束以来，基督教民主主义政党在许多欧洲国家的政治生活中发挥核心作用。对共产主义的恐惧和传统右翼政党的削弱（战争带来的“副作用”）为他们势力的增长和稳定提供了广阔的沃土。由于共产主义恶魔的威胁，这些政党具有强烈的亲美大西洋主义色彩——美国的结盟行动获得加成.";

// 1970
$escadronmort="死亡小队";
$escadronmortdetail="这只游击队擅长对抗异议人士与活动者.<br>
他会使用折磨恐吓，并且通过制造恐怖和暗杀达到其目的.<br>
";

$guerillaattentiste="观望";
$guerillaattentistedetail="这个国家的局势是如此混乱和令人困惑，以至于这只游击队决定采取观望等待局势下一步发展（或者它正在为新的进攻积蓄力量）";

// 1975 

$euromissiles="欧洲导弹";
$euromissilesdetail="在欧洲的威胁与示威获得加成";


//VUES GUERRE D'ALGERIE
// GUERRE D'ALGERIE

$titlesasalgerie="将会减少FLN的影响力";
$sasalgerie="特殊管理部门（SAS）";

$contingentalgerie="派遣特遣队";
$titlecontingentalgerie="将会大幅度加强你的部队数";


// MAJ MGS COTE URSS

$techinterrogatoire="ADVANCED INTERROGATION TECHNIQUES";

$txttechinterrogatoire="Ocelot is capable of collecting key information on the enemy presence.<br>
Ocelot efficiency: +1<br>
Ignores the trait Extra-territorial Base and Sanctuary <br>";

$equipmodulaire="MODULAR EQUIPEMENT";
$txtequipmodulaire="The GRU's research facilities developed a wide array of modular equipments, enabling a quick adapation of weaponry to a variety of situation.<br>
Ocelot efficiency: +1<br>
Ocelot efficiency: +3 against bosses<br>";


$formmediccbt="BATTLEFIELD MEDICINE TRAINING";
$txtformmediccbt="Ocelot can treat his injuries on his own during missions.<br> Major Ocelot also recovers faster between two missions when injured.<br>
==> Decreases the severity of Major Ocelot's injuries<br>
==> Major Ocelot recovers faster from his injuries.<br>";

$milmi24="MODIFIED MIL-MI 24";
$txtmilmi24="A specially modified combat helicopter lurks around and punctually supports Ocelot. Rather fuel-consuming, unfortunately equipped with small fuel tanks to save space, its autonomy is limited.<br>
==> Major Ocelot is more efficient against an enemy with the traits Heavy Weapons or Mafia (+2 chaque)<br>
==> Major Ocelot is less efficient against an enemy with the trait\"Underequipped\"";

$krokodil="KROKODIL TEAM";
$txtkrokodil="A second GRU intervention unit secretly supports Major Ocelot and his men.<br>
==> Major Ocelot is more efficient (+1)<br>
==> Major Ocelot has less chances to be captured and more chances to escape<br>";

$gidolocator="GIDOLOKATOR";
$txtgidolocator="With the Gidolokator technology, Ocelot will be able to spot enemy patrols and avoid them.<br>
What a shame its battery is so limited! <br>
==> Major Ocelot is more efficient (+3) but not beyond the first 3 stages of long missions<br>";

$rationsirp="IRP RATIONS";
$txtrationsirp="Going on mission with these rations enables a longer survival in hostile conditions, what Ocelot does not refuse.<br>
==> Major Ocelot is more efficient in rural areas (+3)<br>";

$bouclierhumain="HUMAN SHIELD";
$txtbouclierhumain="Ocelot is afraid of dishonourable tactics to accomplish his mission and has been specifically trained.<br>
==> Major Ocelot will be captured less often (-3)<br>";

$ocelotzerobonus="Ocelot has no bonus for the time being";

/* Original: $bioocelot="Ocelot is an elite agent of the GRU.<br>
He will wreak havoc in guerrilla groups you assign him.<br>
Ocelot however only becomes extremely efficient if you develop GRU technologie.<br>
 ";
 */

$bioocelot="Ocelot is an elite agent of the GRU.<br>
He will wreak havoc in guerrilla groups yo which you assign him.<br>
Ocelot however only becomes extremely efficient if you develop GRU technology.<br>
 ";
$bonusdeocelot="Ocelot's bonuses";

$ocelotcapture="Ocelot has been taken prisoner";
$ocelotcapturedetail="Ocelot is unavailable for missions";

$ocelotblesse="Ocelot is injured";
$ocelotblessedetail="Ocelot is unavailable for missions";

$krokodile="Ocelot Unit infiltration";
$ocelot="Send Major Revolver Ocelot";

$guerillaocelot="Infiltrated by Ocelot Unit";
$guerillaocelotdetail="Elite agents of the Ocelot Units infiltrated this guerrilla, donnant un très fort bonus à vos actions avec elle.";

$ocelotko="Ocelot is injured! He can continue his mission but will be less efficient!";
$agentcapture="Your agent has been captured! he can not continue the mission";

// FRANCE 1957+

$francecee="欧共体";
// Original: $franceceedetail="The country is a member of the European Economic Community and its reconstruction goes faster";

$franceceedetail="这个国家是欧共体的一员，经济重建速度增长加快了！";
$tentationputchiste="政变风险";
// Original: $tentationputchistedetail="When it reaches 100%, the militaries will attempt to seize power à 100%";
$tentationputchistedetail="当到达100时，法国军方将会发起政变夺权";

//1980 +

$roguestate="流氓国家";
$roguestatetitle="这个国家处于国际政治的边缘并且资助恐怖主义";

$titreroguestate="流氓国家";
$texteroguestate="这个国家处于国际政治的边缘并且资助恐怖主义，其在领土上训练恐怖分子并且扰乱邻国政治.<br>
忘了与他的协议了吧：他的局势诡秘多变.
只要这个政权还掌握权力，那么所有国家的国际计划都有可能被打乱.<br>";
$rss="苏维埃社会主义共和国";

$titrerss="苏维埃社会主义共和国";
/* Original: $texterss="This Republic belongs to USSR.<br>
If it appears on the maps, this means that separatists tensions are brewing.";
*/
$texterss="该国是苏联的加盟成员国.<br>
如果它出现在地图上，代表着民族矛盾在上升.";
$nationalismerss="民族矛盾";
// Original: $nationalismersstitle="This Republic is destabilised by nationalist unrest, the higher the Nationalism gauge is, the more likely are the troubles to spark.";

$nationalismersstitle="这个共和国因民族主义动乱而变得不稳定，，民族矛盾指数越高越容易导致问题。";

// Is this a duplicate?
$nationalismerss="民族矛盾";
// Original: $nationalismersstitle="This Republic is destabilised by nationalist unrest, the higher the Nationalism gauge is, the more likely are the troubles to spark.";

$nationalismersstitle="这个共和国因民族主义动乱而变得不稳定，民族矛盾指数越高越容易导致问题。";

$nondisponiblerss="因为这个国家是苏联的一个加盟共和国，所以不可能这么做.";

// Patch alt hist Elections US de 1964

$ciadistrust="中情局失信";
$ciadistrustdetail="颠覆行为受到-2惩罚";


//1991 -1993

$southernwatch="南部守望";



?>