﻿<?php


$annee51evt1="欧洲：欧洲煤钢共同体（ECSC）成立";
$annee51evt1detail="如果比利时、联邦德国、法国、意大利、卢森堡和荷兰不属于东方阵营，它们的稳定度将会提高";

$annee51evt2="亚洲：澳新美安全条约（ANZUS）成立";
$annee51evt2detail="美国和这两个国家签署防御协定";

$annee51evt3=" 该国加入澳新美安全条约";
$annee51evt3detail="与美国签署防御协议 ";

$annee51evt4="利比亚：独立！";
$annee51evt4detail="这个国家现在独立了";

$annee51evt5="旧金山对日和约";
$annee51evt5detail="结束盟军在日军事管制";


// EVT FRANCE

$annee51evt6="法国：新的政府更迭";
$annee51evt6detail="又一个……快速进入您的国家屏幕，看看它的新特质";

$annee51evt7="法国：政府更迭";
$annee51evt7detail="这真的重要吗？";

$annee51evt8="法国：首届博若莱新酒节开幕！荣誉+1000（不，这只是个玩笑。抱歉。）";
$annee51evt8detail="就算大战开打，我们仍可以喝一杯";

$annee51evt9="日本：警局遇袭";
$annee51evt9detail="一些共产主义者选择武力斗争";


?>