﻿<?php



$annee50evt1="中国：中苏友好同盟条约（苏联荣誉+100）";
$annee50evt1detail="苏联对华援助设为每月10$，苏联+100荣誉";


$annee50evt2="中国：土地改革";
$annee50evt2detail="稳定度下降（-2）";

$annee50evt3="韩国：屠杀共产主义反对派";
$annee50evt3detail="共产主义反对派消失";

$annee50evt4="西藏：中国进军西藏";
$annee50evt4detail="藏区地方政府武力对抗中央";

$annee50evt5="西藏：中国人民解放军解放西藏";
$annee50evt5detail="藏区地方政府武力对抗中央";

$annee50evt6="中国：镇压反革命运动";
$annee50evt6detail="中国反对派消失";

$annee50evt7="朝鲜：中国志愿军大规模入朝作战";
$annee50evt7="在朝鲜战场显著的中国援军";

$annee50evt8="印度支那：高平之战";
$annee50evt8detail="越盟现在得到中国援助，并获得境外基地和重武器特质";

$annee50evt9="缅甸：人民解放军入缅清剿国民党残军";
$annee50evt9detail="在该国新增一支游击队！";

$annee50evt10="中国：新疆和云南（来自缅甸）的国民党匪军仍在袭击中国";
$annee50evt10detail="两支游击队出现在中国";

$annee50evt11="科特迪瓦：骚乱和民族主义动荡";
$annee50evt11detail="稳定度下降";


$annee50evt12="几内亚大罢工";
$annee50evt12detail="稳定度下降";

$annee50evt13="肯尼亚大罢工";
$annee50evt13detail="稳定度下降";

$annee50evt14="尼泊尔：宫庭政变";
$annee50evt14detail="稳定度下降";

$annee50evt15="波兰-民主德国：格尔利茨条约（关于划定波德现有国家边界的协定）";
$annee50evt15detail="民主德国和波兰的稳定度上升";

$annee50evt16="印度尼西亚：一个独立共和国在摩鹿加成立";
$annee50evt16detail="一个伪国家出现";


$annee50evt17="法国：克耶政府";
$annee50evt17detail="政府的新领导人";

$annee50evt18="印度支那：塔西尼将军被任命为高级专员";
$annee50evt18detail="新锐精神激励我军（稳定度+2）";

$annee50evt19="法国：普利文政府";
$annee50evt19detail="政府的新领导人";









?>