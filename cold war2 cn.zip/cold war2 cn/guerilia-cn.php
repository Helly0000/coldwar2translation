﻿<?php
$madagascar47="马达加斯加叛军";

$apli="中国人民\解放军";

$commitealbanielibre="自由全国阿尔巴尼亚委员会";

$drapeaublanc="缅甸共产党（白旗派）";
$elas="希腊人民解放军";
$elas2="希腊民主军";
$huks="胡克军";

$karen='克伦民族解放军';
$kachin="克钦独立军";
$kokang="果敢军";
$pathet="巴特寮";

$insurgentskurdes="库尔德武装";
$partidocomunistaparaguayo="巴拉圭共产党";
$partidoliberalcolumbiano="哥伦比亚自由组织";
$partidocommunistacolumbiano="哥伦比亚共产党";
$paramilitairesxdroitecolombie="准军事武装";
$pemuda="印度尼西亚青年团";
$pcbirmanie="缅甸共产党（红旗派）";
$febreristes="革命二月党";

$irgoun="伊尔贡";
$lehi="莱希";
$haganah="哈加纳";
$mnla="马来亚解放军";
$muqaddas="圣战军";
$ala="阿拉伯解放军";
$legionarabe="阿拉伯军团";
$partisanspalestiniens="巴勒斯坦起义者";
$seigneurguerrebirman="匪帮";
$soldatsmaudits="波兰国民军";
$volontairescoreens="朝鲜志愿军";


$kmtbirmanie="国民革命军（李弥）";
$kmtxinjiang="国民党";

$fellagas="中东匪帮";
$maumau="茅茅起义";


// 1953

$flnalgerien="民族解放阵线";
$Anyanya="蛇毒";

// 1958

$pspliban="社会进步党";
$almourabitoun="纳赛尔独立运动";
$katateb="黎巴嫩长枪党";
$prri="印度尼西亚革命共和国";


// 1959

$frontliberitree="厄立特里亚解放阵线";

// 1963
$touaregs="图阿雷格人";
$kabyle="卡拜尔战士";
$somalisogaden="欧加登游击队";
$hmongs="苗族武装";
$simba="辛巴起义军";
$olp="巴勒斯坦解放组织";

// 1953

$flnalgerien="民族解放阵线";
$Anyanya="蛇毒";

// 1958

$pspliban="社会进步党";
$almourabitoun="纳赛尔独立运动";
$katateb="黎巴嫩长枪党";
$prri="印度尼西亚革命共和国";
$frontliberitree="厄立特里亚解放阵线";

// 1963
$touaregs="图阿雷格人";
$kabyle="卡拜尔战士";
$somalisogaden="欧加登游击队";
$hmongs="苗族武装";
$simba="辛巴起义军";
$olp="巴勒斯坦解放组织";
$frolinat="乍得民族解放阵线";
$constitutionalistes="建制派";

//1966

$samlaut="三洛起义";

// MODE FRANCE

$hoahao="和好教武装";
$kebele='村社民兵';

//1979
$theraneight="哈扎拉圣战者";

?>