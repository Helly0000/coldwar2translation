﻿<?php

$annee55evt1="联邦德国：建立联邦国防军（Bundeswehr）";
$annee55evt1detail="联邦德国军事力量增加（+10）";

$annee55evt2="巴西：民众骚乱";
$annee55evt2detail="稳定度下降";

$annee55evt3="北约配置核武器";
$annee55evt3detail="紧张局势上升";

$annee55evt4=": 该国加入巴格达条约";
$annee55evt4detail="美国和该国签署防御协定";

$annee55evt5="美国：民权运动开端";
$annee55evt5detail="美国抗议活动增长";

$annee55evt6="美国：抵制蒙哥马利巴士";
$annee55evt6detail="美国抗议活动增长";

$annee55evt7="喀麦隆：雅温得骚乱";
$annee55evt7detail="稳定度下降";

$annee55evt8="苏丹：南部暴动";
$annee55evt8detail="一支游击队出现";

$annee55evt9="埃塞俄比亚：海尔·塞拉西皇帝加冕庆典";
$annee55evt9detail="稳定度上升";

$annee55evt10="法国：动员预备役部队增兵阿尔及利亚";
$annee55evt10detail="军队力量增加，民族解放阵线消去小型游击队特质";

$annee55evt11="奥地利：奥地利国家条约";
$annee55evt11detail="当外国军队离开这个国家时，奥地利人再次掌握了自己的命运";


$annee55evt12=" ：该国加入华沙条约";
$annee55evt12detail="军事力量最大上限+5";

$annee55evt13="塞浦路斯民族主义暴动";
$annee55evt13detail="游击队出现";

//EVTS MINEURS FRANCE 55

$annee55evt14="法国：埃德加·富尔政府";
$annee55evt14detail="这届政府有能力在这样的动荡时期里领导国家吗？";

























?>