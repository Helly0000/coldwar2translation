﻿<?php

// EVTS MINEURS 1980

$annee80evt1="突尼斯：一名武装突击队员试图在加夫萨引发暴动";
$annee80evt1detail="突尼斯稳定度下降，人们视利比亚为此举幕后黑手。";

$zimbabwe="津巴布韦";

$annee80evt2="津巴布韦：自由选举与终结种族隔离";
$annee80evt2detail="游击队消失，该国对外关系与津巴布韦非洲民族联盟的对外关系相一致";

$annee80evt3="阿尔及利亚：柏柏尔之春";
$annee80evt3detail="稳定度下降";

$annee80evt4="马里：学生抗议";
$annee80evt4detail="稳定度下降";

$annee80evt5="乍得：内战以更大规模重启";
$annee80evt5detail="北方军从乍得民族解放阵线中分裂出来，企图独自夺取政权";

$annee80evt6="利比里亚：前政府成员遭屠杀";
$annee80evt6detail="该政权变得偏执和腐败";

$annee80evt7="利比里亚：新总统称赞美国对非政策";
$annee80evt7detail="对美关系急剧升温";

$annee80evt8="乍得：利比亚部队前来拯救政权";
$annee80evt8detail="利比亚部队前来支持政权";

$milicesdada="达达派民兵";

$annee80evt9="乌干达：争议选举后的新恐怖活动";
$annee80evt9detail="反对派的声音消失了，但农村到处都是武装团体";

$annee80evt10="伊拉克：什叶派抗议浪潮！";
$annee80evt10detail="稳定度下降2级";
$annee80evt11="伊拉克：血腥镇压什叶派抗议者";
$annee80evt11detail="稳定度下降2级";

$partisanschiites="什叶派革命者";
$annee80evt12="伊拉克：什叶派起义";
$annee80evt12detail="一场令人担忧的内战刚刚开始";

$annee80evt13="萨尔瓦多：马列主义游击队联盟";
$annee80evt13detail="马蒂民族解放阵线现在与政府战斗";

$annee80evt14="秘鲁：革命起义";
$annee80evt14detail="光辉道路行动！";

$annee80evt15="玻利维亚：资产阶级、毒贩和准军事组织的勾结";
$annee80evt15detail="在任何情况下，该国最终都会被国际孤立（腐败国家+与美苏关系恶化+长枪党组织出现）";

$annee80evt16="韩国：光州起义";
$annee80evt16detail="稳定度下降2级";

$rebelsvanuatu="瓦努阿图分离主义者";

$annee80evt17="巴布亚新几内亚：瓦努阿图暴动";
$annee80evt17detail="一支独立运动出现在巴布亚新几内亚";

$fulnl="老挝联合民族解放阵线";

$annee80evt18="老挝：老挝联合民族解放阵线成立";
$annee80evt18detail="一支新游击队出现在老挝";

$annee80evt19="叙利亚：阿勒颇暴动";
$annee80evt19detail="稳定度下降2级";

$annee80evt20="土耳其：针对阿列维少数民族的大屠杀";
$annee80evt20detail="稳定度下降2级";

$annee80evt21="叙利亚：清除和禁止伊斯兰反对派";
$annee80evt21detail="稳定度增长3级";
















?>