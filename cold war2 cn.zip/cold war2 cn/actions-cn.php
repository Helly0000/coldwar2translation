﻿<?php

// Original: $accordecosignes="This country agrees to sign economic treaties with you!<br> A new era of prosperity and profitable relations begins for our two nations.";
$accordecosignes="这个国家同意与你签署经济协议!<br> 一个繁荣和互利关系的新时代在我们两国间开启了。";
// Original: $accorddefsignes="This country agrees to sign defence agreements with you!<br> Our duty is now to protect our new allies.";
$accorddefsignes="这个国家同意与你签署防御协议!<br> 我们有义务保护我们新的盟友。";
$accorddeffensifs="防御协议";
$accordecononsignes="沟通正在停滞不前...";
$accorddefnonsignes="沟通正在停滞不前...";
$accordbasenonsignes="沟通正在停滞不前...";
// Original: $accordbasesignes="This country agrees to host a major military base";
$accordbasesignes="这个国家同意设立一个军事基地";
// Original: $accordbasemissilessignes="This country agrees to be protected by your nuclear umbrella";
$accordbasemissilessignes="这个国家同意被你的核防护伞保护";
$accordeconomique="经济协定";
$accorddef="防御协定";
$accordeco="经济协定";
// Original: $accusationputch="Government blames you for being involved in this attempted coup";
$accusationputch="政府谴责你参与这次未遂政变";
$aideeconomique="经济援助";
$aidemil='军事援助';
// Original: $aidemilvenduerebelles="Widespread corruption or gross incompetence? Part of weapons and ammunations shipped by you ended up in rebels' hands! ";
$aidemilvenduerebelles="究竟是普遍的腐败还是严重的无能？你送出的部分武器最终落入叛军的手里! ";
$aligner="外交结盟";
// Original: $armeeinsurectionnellede="Insurectional Army of ";
$armeeinsurectionnellede="起义军  ";
// Original: $apparitioncorruption="Large influx of capital generated greed and groups have organised to embezzle this godsend for their own profit.";
$apparitioncorruption="大规模的资本涌入导致了贪婪，政府里的官员们开始私吞这些援助来喂肥他们自己.";
$apres="之后";
$armeepatriotiquelibre="自由爱国军";
$armeepopulaire="人民军";
$armeepopulaireliberation="人民解放军";
$armeenationaleclandestine="地下国民军";
$armeerouge="赤军";
$armeerougemaoiste="赤军（毛主义）";
$armeesecrete="秘密军";
$avant="之前";
$basemilitaire="军事基地";
$basemissiles="核导弹";
// Original: $capacitemilitairemax="This country's armed forced reached their maximum level.";
$capacitemilitairemax="这个国家的军事力量已达到最大限度。";
// Original: $capacitemilitaireguerillamax="The strength of this guerilla reached its maximum level.";
$capacitemilitaireguerillamax="这个游击队的力量已经达到了最大限度";

// Original: $coalitionformee="Guerrilla groups just united! Together, they will overthrow the illegitimate power!";
$coalitionformee="游击队们联合起来了！他们将一起推翻现在的非法政府!";
$coalitionguerilla="创建联盟";
$coalitionratee="游击队们的矛盾使他们难以团结.. (至少现在)";

// Original: $concessionsmanifestations="Facing unprecedent unrest, the government organised negotiations that resulted in a new social pact. The majority of the population is satisfied with this new deal.";
$concessionsmanifestations="面对突发的社会躁动，政府决定组织谈判并且达成了一项新的社会协议，大多数示威者都对此心满意足.";

// Original: $contremanifestation="Extremist groups of all persuasions take to the street and start fighting; these are real pitched battles happening across the country but the government stands powerless to stop them! ";
// These don't really seem like battles
$contremanifestation="各种极端团体走上了街头！全国各地都在发生激烈的小规模冲突，而政府无力应对这种局面! ";

$coupetat="政变 ";
$creationguerilla="游击队";

// Original: $creationdissention="Your agents worked well: internal fights are paralysing the leadership of this movement!";
$creationdissention="你的间谍们做的很到位--内部的派系斗争使游击队动弹不得!";

// Original: $creationgroupedissident="This movement just splitted in two separate groups!";
$creationgroupedissident="这只游击队分裂成了两只力量!";

// Original: $desertionguerilla="Multiple desertions are crippling guerrilla's ranks!";
$desertionguerilla="大量逃兵逃出了游击队，游击队的纪律正在崩坏!";

$dissention="创造异议";

$economie="经济";

// Original: $echecdissention="Your attempts failed: this group stands united and focussed on its objectives.";
$echecdissention="你的尝试失败了：这个团体在其目标前团结一致.";

// Original: $envoitroupescoloniales="The metropole sends additional colonial troops to maintain law and order.";
$envoitroupescoloniales="这个殖民地的宗主国派出驻军来维持本地的秩序.";

// Original: $envoidetroupes="Your troops arrive in the country!";
$envoidetroupes="你的部队到达了这个国家!";
$envoitroupes="派遣部队";

// Original: $equilibrerelation="This country, concerned about its independence and global balance of power, multiplies initiatives to draw nearer to the other bloc.";
$equilibrerelation="这个国家，担忧于丧失自己的独立地位和全球力量平衡，开始向另外一个阵营靠拢.";

// Original: $equiparmeslourdes="Guerrilla is now equipped with heavy weapons.";
$equiparmeslourdes="这个游击队现在装备了重型武器.";

$factionarmeemarxiste="马克思主义旅";


$fermeturebase="你的军事基地关闭了";
// Original: $fermeturebasemissile="You removed your ballistic missiles from this country";
$fermeturebasemissile="你撤除了你在这里的导弹部署";

$fondationopposition="创造反对派";

$forcearmee="武装力量 ";
$frontpatriotique="爱国阵线";

// Original: $gouvernementrenverse="Country fell into chaos as government falls itself!";
$gouvernementrenverse="这个国家陷入了混乱，政府崩溃了!";
// Original: $guerillareussi="Your efforts have paid off: an armed group is ready to violently overthrow government";
$guerillareussi="你的努力有了回报-一个武装团体准备推翻政府";
// Original: $guerillarate="Opposition in this country prefers the political route...";

$guerillarate="本国的反对派更倾向于政治路线...";
$infiltration="渗透";

$ingerenceinterne=" 这个国家谴责境外势力干预";

// Original: $inquietuderetrait=" This country is worried about your withdrawal from this region (relations-1)";
$inquietuderetrait=" 这个国家担忧于你的撤军(关系 -1)";

// Original: $instructeursarrivent="Your military advisors arrived in this country, they will manage all training aspects of its army and support its general staff";
$instructeursarrivent="你的军事顾问到达了这个国家，他们会训练本地的部队和军事指挥层";
// Original: $instructeurspartent="Your military advisors are called back home: their mission is complete!";
$instructeurspartent=" 你的军事顾问被召回了，他们的使命完成了!";

// replaced putch with coup
$interventiontroupesursscontreputch="政变失败了!<br>俄国军队介入了，这场冒险结束了";
$interventiontroupesusacontreputch="政变失败了!<br>美国军队介入了，这场冒险结束了";

// Original: $invasionpays="Your troops invade this country!";
$invasionpays="你的部队入侵了这个国家!";

// This variable is about the Congress of the USA, correct?
//I think just congress will suffice
// Original: $lecongresditnon="The congress says No !";
$lecongresditnon="国会说：不!";

// Original: $knicenom="Korean National Youth Corps";
// I think this is what it is in English
$knicenom="韩国国家青年团";
// Original: $lacharite="This country refuses your aid! <br>Its rulers pretend they do not need your charity and claim your proposal is part of a hidden imperialist agenda to control their national economy...";
$lacharite="这个国家拒绝了你的援助! <br>他的统治者宣称不需要你的虚伪施舍，并声称你的提议是帝国主义控制其国民经济的隐秘议程的一部分……";
$lacorruption="腐败";
$larichesse="财富";
// Original: $lesopposition="Number opposition groups";
$lesopposition="反对派数目";

// Original: $manifsantibase="The announcement of the potential installation of a military base of yours in this country triggered massive and violent popular protest marches!";
$manifsantibase="你的基地计划导致了一系列的示威活动!";

// Original: $manifsantibasemissiles="The announcement of the potential installation of nuclear missiles of yours in this country triggered massive and violent popular protest marches!";
$manifsantibasemissiles="你在这个国家部署核导弹的计划导致了一系列的示威活动!";

// Original: $manifsantibasedegenere="Protests are worsening and spreading out accross the country: its regime is tottering!";
$manifsantibasedegenere="示威越来越严重了-政府摇摇欲坠!";
// Original: $manifsantibasemate="Suppression of the protest marches is merciless, the army fires into the crowd and all leaders of the opposition are arrested!";
$manifsantibasemate="镇压示威的举动非常无情，军队向人群开火，所有反对派领袖都被逮捕了!";
// Original: $manifestationreprimee="Protests marches were harshly suppressed and the main leaders of the opposition have been arrested";
$manifestationreprimee="示威被严厉的镇压了，而反对派领袖们也被逮捕";
$menace="Threat";

$milicespatriotiques="爱国民兵";

// Original: $negodissentions="The negotiations issue caused major dissensions within the movement.";
$negodissentions="是否与现政权谈判的问题在运动内部引起了重大分歧。";
$negoguerilla="推动谈判";

// Original: $negoreussie="Guerrilla accepts to open negotiations with the incumbent government, one cannot predict whether the regime will take advantage of this historical opportunity.";
$negoreussie="这只游击队决定和政府谈判，我们不能确定政权是否会利用这一历史机遇。";
// Original: $negoratee="The guerrilla is not yet ready to discuss with the regime.";
$negoratee="游击队还没有准备好与政府谈判.";

$nomrelation="关系";
$nomrichesse="财富";
// Original: $nomfinlandisation="finlandisation";
$nomfinlandisation="芬兰化";
// Original: $nomnonfinlandise="not subject to finlandisation";
$nomnonfinlandise="没有芬兰化";

$nomsplitusa="真国民阵线";
$nomspliturss="社会主义革命军";
$nomsplitautre="新爱国阵线";

$nwyanom="西北青年协会";
$oppositionreussi="反对派开始组织起来";
// Original: $oppositionratedictature="Secret police keeps its weather eye opened and any attempt from the opposition to organise itself is nipped in the bud.";
$oppositionratedictature="国家秘密警察密切关注民众，任何组织反对派的企图都被扼杀在萌芽状态。";
// Original: $oppositionrate="A herd of cats would be easier to line up than dissidents in this country.";
$oppositionrate="放养猫比在这个国家组织反对派要容易得多。";

$patriotesde="爱国者 ";

$particommunistecombattant="共产党武装";
$partimaoistecombattant="共产党（毛）武装";
$pccnom="朝鲜劳动党";

// Original: $prosperitesupprimeopposition="Economic prosperity deprives the opposition from any economic argument";
$prosperitesupprimeopposition="新的经济增长堵上了反对派的嘴巴";

// Original: $protestationaidemil="This country's government strongly protest against this military aid which could destabilise the entire region (relations-1)";
$protestationaidemil="这个国家认为这份军事援助会导致地区不稳定 (关系 -1)";


// Original: $putchmercenaire="Your war dogs overthrew the government! <br> A young captain from the presidential guard is called to power.<br> Counselled by his unpredictable foreign friends, he promises to lead the country outside its current turmoil.";
$putchmercenaire="战争的鹰犬夺去了政权! <br> 总统卫队的年轻队长是新的元首了.<br> 被他不可预料的伙伴援助，他承诺将把这个国家带回正轨";
// Original: $putchreussi="<br><br>Government was overthrown by a few ambitious young generals! <br> They intend to put the nation back on tracks.";
$putchreussi="<br><br> 这个国家的政府被一群野心勃勃的少壮派军官推翻了! <br> 他们希望把国家带回正轨.";

$rejointcoalition="这个团体加入了统一战线!";

$relationadversaires="关系 与 ";
// Original: $remaniementetatmajor="general staff is deeply reorganised";
$remaniementetatmajor="这个国家的领导层被洗牌";

// Original: $retraitkoree="Our withdrawal leaves a country in turmoil where the various factions immediately move to seize power by force.";
$retraitkoree="我们在朝鲜的撤军导致了混乱，数个派系立即组织起来以武力夺取政权。";

// Original: $retraitarmeerougeeurope="While we were in the process of withdrawing from the country, its population rose against the government!<br> This revolt rapidly reaches major cities and even gains support from certain units in the army.";
$retraitarmeerougeeurope="正当我们撤军时，一场叛乱爆发了!<br> 这场叛乱快速的传播，甚至军方也有了他的同情者.";

/* Original:
$retraitpologne="While our troops are leaving Poland, soldiers who have been hiding in the forests since the end of World War II suddenly put and end to their concealment and rally a crowd of patriots.<br>
 This crowd of supporters grows to the point of forming a real army determined to turn our retreat into a debacle and overthrow the government.";
*/
$retraitpologne="正当我们撤离波兰时，波兰第二共和国的支持者，那些抵抗运动突然在光天化日之下集结他们的部队<br>
他们将会运用这次机会来推翻波兰政府.";

$stability="稳定度";

// Original: $radicalisation="This group is now reduced to a handful of uncontrollable fanatics";
$radicalisation="这个团体现在只剩下一些无法控制的暴徒了";

$rappelneutralite="这个国家严守中立";
// Original: $rappelnonalign="This country claims to be a non aligned country";
$rappelnonalign="这个国家宣称自己是不结盟国家";
$relation="关系";
$richesse="财富";
$stabiliterate="你的经济援助将会帮助这个国家的经济增长";
// Original: $stabilitereussi="Your economic aid helped this country to develop: its stability rises!";
$stabilitereussi="你的经济援助将会帮助这个国家的经济增长：稳定度提升了!";

// Original: $aidemilreussie='Your military aid reinforced the armed forces of this country';
$aidemilreussie='你的军事援助加强了这个国家的军队';
// Original: $aidemilrate="Your military aid had no meaningful effect";

$aidemilrate="你的军事援助毫无意义";
// Original: $aideguerillareussie="Your aid reinforced the guerilla ";
$aideguerillareussie="你的援助加强了游击队 ";


$embargo="禁运";
// Original: $gainparanoia="Suppression is reaching unexpected highs as this country's leader sinks into paranoia";
$gainparanoia="当这个国家的领导层陷入偏执之时，怀疑与镇压开始贯穿整个国家";
$instructeurs="军事顾问";
$invasion="入侵";


$manifestationdestabilisatrices="破坏稳定示威";
// Original: $manifestationreussie="Major popular protests shakes the government!";
$manifestationreussie="大型示威冲击着政府!";
// Original: $manifestationrate="Opposition has major difficulties to rally supporters and cannot find more than a hundred of militants across the country to demonstrate...";
$manifestationrate="反对派很难找到他们的支持者，在全国难以找到大于一百人的游行队伍...";
// Original: $manifestationratedictature="The mad sign-bearer was sectioned...";
$manifestationratedictature="/疯狂/的示威者被送进了精神病院...";

$mercenaires="雇佣军";

// Original: $protestguerilla="This country believes your irresponsible behaviour will destabilise the region";
$protestguerilla="这个国家认为你不负责任的行动将会导致地区局势的混乱";

// Original: $protestputch=" This country protests against your interference in internal affairs of a soverign statece pays";
$protestputch=" 这个国家谴责你干预他国内政";
$protestretrait=" 这个国家担心你的撤军.";

// Original: $protestinvasion="This country vigorously blames your invasion!";
$protestinvasion="这个国家严厉谴责你的入侵行为";


// Original: $putchrate="Generals involved in the conspiracy are arrested and the planned coup fails miserably";
$putchrate="政变失败了，那些参与者们都被逮捕了.";
// Original: $putchraterepression="The coup failed and a merciless suppression strikes political opponents. Government intends to take charge of the country again!";
$putchraterepression="政变失败了，政府紧急的抓捕了他们的对手并且重掌大局!";

$reequilibrage=" 重新建立外交关系 ";
// Original: $relationreussi="Your relation with this country improved";
$relationreussi="你和这个国家的关系提升了";

$retraitdetroupes="我们的孩子要回家了!";
$retraittroupes="撤军";

// Original: $retraitarmeerougeeuropeindependence="This country's government takes advantage of our departure to announce timid liberalisation and initiate a political opening to the West (Stalinism-1)";
$retraitarmeerougeeuropeindependence="这个国家利用我们的离开开始宣布了它向自由化迈出的第一步并启动了对西方的政治开放(斯大林主义 -1)";

$retraitinquietretraiteurope="这个国家担忧你从欧洲撤军 (关系 -1)";

// Original: $richessereussi="This country is blessed with a period of strong economic growth: its wealth increases!";
$richessereussi="这个国家的经济像被祝福了一样，财富增长!";
// Original: $rapportanalystes="Analysis report from our services";
$rapportanalystes="情报部门汇报";
$rappelinstructeurs="召回军事顾问";
$lastabilite="稳定度";
$txtaccordeco="签署经济协定 与 ";
$txtaccorddef="签署军事协定 与 ";
$txtaccordbase=" 军事基地被建立 来自";
$txtaccordbasemissiles=" 核导弹基地被建立 来自";

// Original: $txtactionfinembargo="embargo has been lifted and relations between our two countries should start again on a good footing!";
$txtactionfinembargo="禁运被解除了，两国的经贸关系可以重新开始了!";
// Original: $txtactiondebutembargo="This nation is now under embargo: its economy should be slowly sinking...";
$txtactiondebutembargo="这个国家现在在禁运之下，他的经济会逐渐崩溃...";

$txtaideeco=" 经济援助 来自";
$txtaidemil=" 军事援助 来自";
// Original: $txtaidemilguerilla=" 游击队被资助 来自 ";
$txtaidemilguerilla=" 游击队被资助 来自 ";

$txtalignement=" 外交位置结盟 ";
// Original: $txtalignementrate="Our interference in this country's political life reawakened its national pride and climate between our two nations went considerably sour....";
$txtalignementrate="我们对于这个国家的政治进程干预导致了国家意识的警惕与愤怒，两国的关系下降了....";
$txtalignementsanseffet="两个国家正在建设性议题上进行讨论...";
// Original: $txtappelaide="Government seek support from the other superpower: will its call be heard?";
$txtappelaide="这个政府寻求另一个超级大国的支持——它的呼吁会被听到吗？";


// Original: $txtdesunion="Country falls into division regarding which attitude to adopt in front of your threats";
$txtdesunion="这个国家对你的威胁手足无措，政府内发生了多种观点的争吵";

$txtenvoidetroupes="派遣部队 来自 ";



// Original: $txtalignementreussi="The understanding of our two nations on world's affairs is more convergent than ever.";
$txtalignementreussi="两国达成了对世界议题一致的共识.";
// Original: $txtalignementservile="This country's government aligned on our positions with such haste and servility that your diplomats are surprised. ";
$txtalignementservile="这个国家是如此迅速的与你立场靠拢，我们的外交官都感到惊讶. ";

// Original: $txtconcessionsmanifestations=" government reacts to social unreast with a new social covenant (+stability)";
$txtconcessionsmanifestations=" 政府运用新政策解决社会危机 (+ 稳定)";
// Original: $txtcontremanifestation=" 极端团体在街头巷战!";

$txtcontremanifestation="极端团体在街头巷战! ";
$txtenvoitroupescoloniales="殖民地特遣队增援";

// Original: $txtquittecoalition="Following heated internal debates, this group leaves the anti-government coalition";
$txtquittecoalition="在激烈的争吵之后，这个团体离开了反政府同盟";

$txtguerillareussi="创建武装团体 来自";
$txtguerillareussi2="创建武装团体 来自 ";
$txtguerillarate="试图创建武装团体 来自 ";
$txtguerillarate2="试图创建武装团体 来自 ";

$infiltrationratee="你渗透的企图失败了";
// Original: $infiltrationreussie="Your agents infiltrated this group";
$infiltrationreussie="你的特工渗透了这个团体";

// Original: $txtinvasion="The country is invaded by ";
$txtinvasion="国家被入侵 来自 ";

$txtmanifestationrate=" 反对派陷入危机";
$txtmanifestationrate2=" 反对派陷入危机";
$txtmanifestationreprimee=" 一场严厉的对示威的镇压";
$txtmanifestationreprimee2="一场严厉的对示威的镇压";
$txtoppositionsorganise="反对派组织起来了";
$txtoppositionsorganise2="反对派组织起来了";

$txtoppositionsorganisepas="试图创建反对派 来自 ";
$txtoppositionsorganisepas2="试图创建反对派 来自 ";

$txtprotestationfinancementguerilla="你和该国的关系在恶化(如果还没有恶化到极点)";
// Original: $txtprotestationautresguerillas="this movement looks down its nose your financial support to a competing group";
$txtprotestationautresguerillas="这个组织对你财政支持他们的竞争对手感到不满";

$txtputchrate=" 未遂政变";
$txtputchrate2=" 未遂政变";

$txtdialogueconstructif="激烈的外交活动 来自 ";

// Original: $txttransfococo="This country decided to completely reform its institutions and economy: power is now held by the people and large chunks of economy are collectivised!";
$txttransfococo="这个国家决定进行彻底的改革！现在权力掌握在人民手中，经济开始大规模国有化!";
// Original: $txttransfocapitaliste="This country decided to completely reform its insitutions and economy which is now privatised!";
$txttransfocapitaliste="这个国家决定进行彻底的改革!市场和投资条件被开放，国有财产被私有化!";
// Original: $txttransfocapitalisteetat="This country decided to undertake a controlled liberalisation of its economy";
$txttransfocapitalisteetat="这个国家决定对其经济进行管制下的自由化";

$txtinstructeurs= "派遣军事顾问 来自 ";
$titlerappelinstructeurs="召回你的军事顾问并减少支出";
// Original: $txtmenace="Your threatening declarations caused a serious deplomatic crisis with this country.";
$txtmenace="你的威胁导致了该国的外交危机.";
$txtmenacetelex="国家被威胁 来自";
// Original: $txtrappelinstructeurs=" 军事顾问被召回 来自 ";

$txtrappelinstructeurs=" 军事顾问被召回 来自";
// Original: $txtretraitdetroupes=" withdraw their troops from the country";

$txtretraitdetroupes=" 撤军";

$txttentativeaccordeco=" 贸易谈判失败 与 ";
$txttentativeaccordbase=" 军事基地谈判失败 与";
// Original: $txttentativeaccordbasemissiles=" unsuccessful negotiations on the installation of ballistic missiles with";
$txttentativeaccordbasemissiles=" 战略导弹部署谈判失败 与";
// Original: $txtfermeturebase=" closure of military base ";
$txtfermeturebase=" 军事基地关闭 ";
$txtfermeturebasemissile=" 撤回战略导弹";

// Original: $txtfinlandisation="This country is now finlandised! (No military agreements can be signed with it)";
$txtfinlandisation="这个国家被芬兰化了！ (无法签署防御协议.)";

$txtalignementratetelex=" 联盟关系紧张 与  ";
$txtalignementratetelex2=" 联盟关系紧张 与 ";
$txttentativeaccorddef=" 不成功的外交沟通 与 ";
// Original: $textecorruption="Corruption plagues this country's economy: our aid will not be very efficient as long as this situation does not come to an end";
$textecorruption="腐败困扰着这个国家的经济——我们的援助不会非常有效果";
// Original: $txtfinembargo="end of the emarbgo by ";
$txtfinembargo="禁运结束 来自 ";
$txtdebutembargo="宣布禁运 来自 ";

// Original: $texteholdup="The ruling elites embezzled the entirety of your aid with such voracity that riots broke in several cities! ";
$texteholdup="统治阶级吞并你的援助的风声走漏，暴乱在各大城市里爆发了! ";

// Original: $txtmanifestations="massive popular protests (-stability)";
$txtmanifestations="大型示威(- 稳定)";

$txtmercenaires="雇佣军来到这个国家 (+1)";
// Original: $txtmobilisation="This country issued a general mobilisation order and put all its armed forced on high state of readiness!";
$txtmobilisation="这个国家的武装部队进入高度戒备状况，总动员令被签署了!";

$txtputchreussi="政府被政变推翻";
$txtputchreussi2="政府被政变推翻";
// Original: $txtputchraterepression="opposition is suppressed after an attempted coup";
$txtputchraterepression="未遂政变后反对派被镇压";
// Original: $textestabilitechaos="This country is in complete chaos, government should fall soon enough";
$textestabilitechaos="国家陷入完全混乱-政府很快就要倒台了";
// Original: $textestabilitefaible="This country is very unstable, which makes it vulnerable to subversion activities and hamper its economic development";
$textestabilitefaible="这个国家很不稳定，这阻碍其经济发展，并使其容易受到颠覆活动的影响";
// Original: $textestabiliteforte="This country is very stable and government authority is respected";
$textestabiliteforte="这个国家非常稳定，政府的权威受到尊敬";
// Original: $texteaccordeco="Our economic treaties with this country boost the impact of our action";
$texteaccordeco="我们的经济协议增加了行动的效率";

$texteabsenceaccordeco="我们应该与这个国家谈判签署经济协议";

// Original: $txtsoutiencause="this group appreciates your support to the cause: your relations improve";
$txtsoutiencause="这个团体欣赏你对其事业的支持-你们的关系上升了";


// Original: $txtunitenationale="Facing external threat, a sacred union is forming around the government";
$txtunitenationale="面对你的威胁，社会上出现了一股狂热的热诚，并且影响到了政府";

$txtverslecommunisme="经济集体化";
$txtverslecommunisme2="经济集体化";
$txtverslecapitalisme="经济私有化";
$txtverslecapitalisme2="经济私有化";
$txtverslecapitalismeetat="改革开放";
$txtverslecapitalismeetat2="改革开放";

$vosrelations="你的关系";
$votreprestige="你的荣誉";

// MAJ 50

// ACTIONS

/* Original: 
$textenapalm="残忍的轰炸让不少人感到不快(荣誉-5)<br>
敌方损失:<br>";
*/
$textenapalm="残忍的轰炸让不少人感到不快(荣誉-5)<br>
敌方损失:<br>";

$napalminefficace="你的轰炸没什么效果";

$txtbombardaviation="凝固汽油弹轰炸 来自 ";

$bombnapalm="凝固汽油弹!";

$bombardement="战略轰炸";
$txtbombardstrategique="战略轰炸 来自 ";
// Original: $textebombstrategique="The enemy territory suffers from terrible bombings! ";
$textebombstrategique="敌人的领土被全面轰炸了! ";

// Original: $diminutionstabilitebomb="Enemy infrastructures were hit hard (stability -1)";
$diminutionstabilitebomb="敌人的基础建设受到了打击 (稳定 -1)";
// Original: $diminutionrichessebomb="敌人的经济崩溃了! (经济 -1)";
$diminutionrichessebomb="敌人的经济崩溃了! (经济 -1)";

$diminutionforcearmee="损失";

// Original: $migalley="enemy MiGs dominate the sky and inflict us high losses! (prestige -5)";
$migalley="敌方的米格飞机主宰着领空，给我们造成了巨大损失！ (荣誉 -5)";


//MAJ CHINE

$vaguehumaine="人海战术!";
$textevaguehumaine="我们英勇的部队将用数量优势和热诚战胜他们!<br>
志愿军";
$txtvaguehumaine="大规模派遣部队 ";

/* Original: 
$projectionforcesimpossibles="我们的部队还没有能力入侵这个国家!<br>
";
*/
$projectionforcesimpossibles="我们的部队还没有能力入侵这个国家!<br>
"; 
$invasionimpossible="无法入侵!";
// Original: $txtinvasionimpossible="This country laugths at rumours of invasion by ";
$txtinvasionimpossible="这个国家嘲笑入侵的流言 来自 ";

/* Original: 
$maoisationreussie="在游击队控制的区域内，地主的土地被没收，土地被重新分配.<br>
工人纠察队被邀请参加自我批判与批判右派分子.<br>
许多特务与阶级敌人被处决或是劳改.
<br>游击队力量: -1";
*/
$maoisationreussie="在游击队控制区，土地被快速分配，农民群众不再受到贪婪地主的剥削.<br>
游击队领导人开始进行自我批评与谴责右倾思想.<br>
许多特务与阶级敌人被处决或是劳改.
<br>游击队力量: -1";


$gainmaoisme_A="<br>这个游击队获得了毛派特性!";
// Original: $gainmaoisme_B="<br>This guerrilla gains the trait Internal Dissents!";
$gainmaoisme_B="<br>这个游击队失去了内部分歧特性!";

// Original: $gainmaoisme_C="<br>This guerrilla loses the trait Corrupted!";
$gainmaoisme_C="<br>这个游击队失去了腐败特性!";
// Original: $gainmaoisme_D="<br>This guerrilla gains the trait Rural guerrilla!";
$gainmaoisme_D="<br>这个游击队获得了偏远游击队特性!";
// Original: $gainmaoisme_E="<br>This guerrilla gains the trait Popular support!";
$gainmaoisme_E="<br>这个游击队获得了民众支持特性!";
// Original: $gainmaoisme_F="<br>This guerrilla gains the trait Fanatism!";
$gainmaoisme_F="<br>这个游击队获得了狂热特性!";
// Original: $gainmaoisme_G="<br>Infiltrations by the USA and the USSR are eliminated!";
$gainmaoisme_G="<br>所有的美苏渗透被肃清了!";


$nommaoisation="毛主义化";

// Original: $maoisationguerilla="Maoising the guerrilla";

$maoisationguerilla="毛主义化游击队";
// 1963
 

// Original: $interventionchinoise="300 000 Chinese have just crossed the border to defend their neighbor!";
$interventionchinoise="300,000 志愿军跨过边境帮助他们的邻居!";

// 1968

/* Original: 
$maisoixantehuit="The students occupied the university and installed barricades!<br>
Workers and intellectuals joined them into a general strike across the country.<br>
The situation seems to be getting out of the authorities' control which requested the army to drive the students out of the university.
<br>(Stability decreases significantly)
";
*/
$maisoixantehuit="学生们占领了大学并且设下路障!<br>
工人们与知识分子加入了全国的罢工<br>
军队派出来重新恢复秩序，情况看起来失去了控制
<br>(稳定度大幅下降)
"; 

// MAJ FRANCE

/* Original: 
$txtpaxamericana="For this country, the European collective security is guaranteed in the West by a strategic alliance with the USA and, in the East, with the USSR.<br>
You need to face reality: you are no longer seen as power capable of guaranteeing the defence of your European partners.
";
*/ 
$txtpaxamericana="对于这个国家来说，欧洲的集体安全是由与美苏在东西方结成的战略联盟来保证的.<br>
你需要面对现实-保护你的邻居的好日子一去不复返了.
";


// Original: $troupescoloniales="The colonial contingent was just reinforced! Armed forces +";
$troupescoloniales="殖民地的驻军增加了! 武装力量 +";
$troupescol="殖民地部队";

$txttroupescoloniales=" 殖民地军队增加 来自 ";

/* Original: 
$occupartionrhur="Evacuating our occupation zone in Germany is out of a quetion! <br>
This privildege of the victors was wrested from the Allies and we must hold our rank.";
*/ 
$occupartionrhur="从我们在德国的占领区撤军是不成体统的! <br>
我们的第二次世界大战后得到的地位不能轻易放弃.";

// Original: $logistiqueus="<br>美国的逻辑学允许我们输送更多装备.";
$logistiqueus="<br>美国提供的后勤支持使我们能够输送更多装备.";

$milicesok="一个新的民间武装加入了我们: ";
// Original: $milicesechec="Influenced by the communist propaganda, the populations hesitate to join us.";
$milicesechec="受到共产主义宣传影响，这里的人不愿意加入我们.";

$txtcreationmilice="一个新的民兵被创立了 --> ";


// MOD MGS

/* Original: 
$infiltrationreussiefox="A FOX agent successfully infiltrated this group!<br>
All subversion actions will be more efficient on this guerrilla group";
*/ 
$infiltrationreussiefox="A FOX agent has successfully infiltrated this group!<br>
All subversion actions with this guerrilla group will be more efficient";

$agentsnake="Snake";

/* Original:
$infiltrationreussiefoxboss="Snake's mission scored a few points against the enemy organisation: one of their prominent henchmen has been eliminated.
<br>(A boss has been liquidated)
";
*/
$infiltrationreussiefoxboss="Snake's mission has scored a few points against the enemy organisation -- one of their most prominent henchmen has been eliminated.
<br>(A boss has been liquidated)
";
 
/* Original:
$infiltrationreussiefoxmaffieux="Snake managed to disorganise the traffickings supplying this organisation.
<br>(Loss of the trait Mafia)
";
*/
$infiltrationreussiefoxmaffieux="Snake has managed to disrupt the trafficking that supplies this organisation.
<br>(Loss of the trait Mafia)
"; 

/* Original: 
$infiltrationreussiefoxarmeslourdes="Snake destroyed the enemy heavy weapons: this is a great success!
<br>(Loss of the trait Heavy Weapons)
";
*/
$infiltrationreussiefoxarmeslourdes="Snake has destroyed the enemy's heavy weapons -- this is a great success!
<br>(Loss of the trait Heavy Weapons)
";

/* Original: 
$infiltrationreussiefoxsanctuaire="Snake blew up the enemy secret base!<br>
Deprived of its lair, the enemy room for manoeuvre will be dramatically reduced.<br>(Loss of the trait Sanctuary)";
*/
$infiltrationreussiefoxsanctuaire="Snake has blown up the enemy secret base!<br>
Deprived of its lair, the enemy's room for manoeuvring will be dramatically reduced.<br>(Loss of the trait Sanctuary)";


$infiltrationreussiefoxleadercharismatique="Snake killed the charismatic enemy leader, dealing a severe blow to this organisation. <br>(Loss of the trait Charismatic Leader)";

// Original: $infiltrationreussiefoxdiminueforce="Snake inflicts casualties in the enemy ranks! <br>(Guerilla strength -1)";
$infiltrationreussiefoxdiminueforce="Snake has inflicted casualties in the enemy ranks! <br>(Guerilla strength -1)";

/* Original: 
$infiltrationfoxratee="Snake's mission went wrong...<br>
He was expected! <br> Would there be a traitor in our organisation?";
*/ 
$infiltrationfoxratee="Snake's mission went wrong...<br>
He was expected!<br> ... Is there a traitor in our organisation?";

// Original: $foxcapture="<br>Unfortunately, there are even worse news: Snake has been captured and is within the hands of the enemy!";
$foxcapture="<br>Unfortunately, there is even worse news: Snake has been captured, and is in the hands of the enemy!";

// Original: $foxblesse="<br>Agent Snake sustained numerous injuries and his state of health is preoccupying: he will not be able to be deployed in operation anytime soon.";
$foxblesse="<br>Agent Snake has sustained numerous injuries, and his state of health is of major concern -- he cannot be deployed into operation anytime soon.";
// Original: $agentparamedic="Paramedic";
$agentparamedic="Para-Medic";
/* Original: 
$actionparamedic="Thanks to Paramedic's medical advice, Snake treated his injuries alone!<br>
Despite still being in a bad way, he is operational again.";
*/
$actionparamedic="Thanks to Para-Medic's medical training, Snake has treated his injuries by himself!<br>
Despite still being in a bad way, he is operational once again.";

$etapemission="Mission stage";


// MAJ FRANCE
// Some of these seem to be duplicates of earlier variables

/* Original: 
$txtpaxamericana="For this country, the European collective security is guaranteed by a strategic alliance with the USA in the West, and with the USSR in the East.<br>
One must acknowledge that you are no longer seen as a power capable of protecting your European partners.
";
*/
$txtpaxamericana="For this country, European collective security is guaranteed by strategic alliances with the USA and the USSR.<br>
You need to face reality -- you are no longer seen as a power capable of guaranteeing the defence of your European neighbors.
";

// Original: $troupescoloniales="The colonial contingent was just reinforced! Armed forces +";
$troupescoloniales="The colonial contingent has just been reinforced! Armed forces +";
$troupescol="Colonial troops";

$txttroupescoloniales=" reinforcement of the colonial contingent by ";


/* Original: 
$occupartionrhur="Evacuating our occupation zone is out of the question! <br>
This victor's privilege was wrested from the Allies and the USSR after a long struggle and we must maintain our position.";
*/ 
$occupartionrhur="Evacuating our occupation zone is out of the question! <br>
This victor's privilege was taken from the Allies and the USSR after a long struggle, and we must maintain our position.";

// Original: $logistiqueus="<br>The logistical means made available by the Americans allowed us to bring more equipment.";
$logistiqueus="<br>The logistics provided by the Americans have enabled us to transport more equipment.";

$milicesok="A new militia joins our struggle: ";

// Original: $milicesechec="Worked on by the communist propaganda, the people hesitate to join us.";
$milicesechec="Influenced by Communist propaganda, the people are hesitant to join us.";

$txtcreationmilice=" A militia has been created --> ";


（Not translating due to duplicate）

//1970

$lecongresditnon="国会说不!";
/* Original:
$casuffitlesconneries="As a senator accurately summarised it:\"enough with stupidity!\"<br>
It seems the Congress became allergic to the idea of dispatching American soldiers abroad.<br>
";
*/
$casuffitlesconneries="正如同参议员准确地概括那样: \"不要再蠢了!\"<br>
看上去国会对于士兵在国外作战的想法过敏了.<br>
";

//STAY BEHIND

$creationstaybehind="暗中密谋网络";
/* Original: 
$textereseaustaybehind="A group of anti-communist patriots was gathered in a highly compartmentalised secret network.<br>
They will form the vanguard of a secret army which will become active in case of communist invasion.<br>
They will receive the best commando trainings in sabotage and communications.<br>
Even the national government should not be aware of the existence of this network, to guarantee maximal protection to its members.";
*/
$textereseaustaybehind="一群反共斗士被集中在一个高度保密的秘密网络当中.<br>
他们将会成为共产主义夺权时反攻的桥头堡.<br>
他们会收到最好的秘密行动和暗中破坏训练技巧.<br>
为了保持绝对的计划安全，本地的政府也不应该知道这个秘密组织的存在.";

/* Original: 
$texteactiverreseaustaybehind="
The activation of the secret army without a communist power takeover causes debate within our secret services: but could we really remain idle when the communists are gaining influence every day? <br>
The lists of dangerous citizens to be dealt with are ready, let us move into action!
";
*/ 
$texteactiverreseaustaybehind="
立即激活秘密军队的行动遭到了争议-共产主义还没有在这里扎根，但是我们难道能漠视日益恶化的局势吗? <br>
不管如何，清单已经拉好了，让我们干活吧!
";


// Original: $telexactivationstaybehind="Violence and political assassinations: the government does all it can to identify the responsible parties";
$telexactivationstaybehind="政治暴力与暗杀：这个政府正在努力调查为此负责的极右团体 ";

// Original: $telexactivationstaybehind2="The oppposition accuses the government of covering up fascist groupsucules (stability -1)";
$telexactivationstaybehind2="反对派谴责政府暗藏极右法西斯暴力组织(稳定度 -1)";

//1980

$raidheliporte="直升机突袭";

$hiversafghan="天气情况不好，我们的行动受到阻碍.";

/* Original: 
$txtsuccesraid="Our forces managed to capture several strong points held by the rebels.<br>
The enemy has proven itself incapable of fighting back our shock troopers when our operations are well planned with an adequate level of intelligence.<br>
Rebel forces: -1";
*/
$txtsuccesraid="、我们的部队夺回了一些战略要地.<br>
敌人难以应对如此精密计划的攻击，我们的突击队势如破竹.<br>
叛军力量: -1";


// If this is not only for Russia, "Spetsnaz" should probably be changed to "special forces"
// Original:$txtsuccesraiddestructionarmeslourdes="Our Spetsnaz forays enabled the destruction of many caches of weapons and artillery guns.<br>
//The rebels lose the Trait Heavy Weapons";

$txtsuccesraiddestructionarmeslourdes="我们的突击队允许我们摧毁敌人的武器补给线和重型装备.<br>
叛军失去重型武器特质";
// Original: $txtnulraid="Our high impact operations were nothing more than flailing in the air: the enermy remains elusive... ";
$txtnulraid="我们的全方面扫荡行动效果不好... 敌人保持隐蔽而难以发现";

/* Original: 
$txtechecraid="Resistance was fierce and our troops fall into a real ambush!<br>
The Afghans obviously benefited from leaked intelligence on our moves. <br>Casualties and material losses are significant.
<br>Prestige -5";
*/ 
$txtechecraid="抵抗非常激烈，我们的部队陷入了圈套<br>
阿富汗军队一定是泄露了情报
. <br>人员伤亡和设备损失严重.
<br>荣誉 -5";

// Original: $txtsuccesraidattentisme="Our strikes disorganised the enemy and we set our pace! <br>- This guerrilla group adopts a 'Wait-and-see'";
$txtsuccesraidattentisme="我们的打击打乱了敌人的组织，我们定下了步调！<br>-这个游击队采取观望态度";

$creationstaybehind="暗中密谋网络";
/* Original: 
$textereseaustaybehind="A group of anti-communist patriots was gathered in a highly compartmentalised secret network.<br>
They will form the vanguard of a secret army which will become active in case of communist invasion.<br>
They will receive the best commando trainings in sabotage and communications.<br>
Even the national government should not be aware of the existence of this network, to guarantee maximal protection to its members.";
*/
$textereseaustaybehind="一群反共斗士被集中在一个高度保密的秘密网络当中.<br>
他们将会成为共产主义夺权时反攻的桥头堡.<br>
他们会收到最好的秘密行动和暗中破坏训练技巧.<br>
为了保持绝对的计划安全，本地的政府也不应该知道这个秘密组织的存在.";

/* Original:
$texteactiverreseaustaybehind="
The activation of the secret army without a communist power takeover causes debate within our secret services: but could we really remain idle when the communists are gaining influence every day? <br>
The lists of dangerous citizens to be dealt with are ready, let us move into action!
";
*/ 
$texteactiverreseaustaybehind="
立即激活秘密军队的行动遭到了争议-共产主义还没有在这里扎根，但是我们难道能漠视日益恶化的局势吗? <br>
不管如何，清单已经拉好了，让我们干活吧!
";

// Original: $telexactivationstaybehind="Violence and political assassinations: the government does all it can to identify the responsible parties";
$telexactivationstaybehind="政治暴力与暗杀：这个政府正在努力调查为此负责的极右团体 ";

// Original: $telexactivationstaybehind2="The oppposition accuses the government of covering up fascist groupsucules (stability -1)";
$telexactivationstaybehind2="反对派谴责政府暗藏极右法西斯暴力组织(稳定度 -1)";



//Not translating as a duplicate


//Guerre Algérie
$creationsas="发展特殊管理部门（SAS） +1";

/* Original: 
$saspertesoutienpop="The healthcare and social progresses achieved by the Sections Administratives Spécialisées (SAS) demonstrate the benefits of the French presence in a very concrete manner to the local populations, who are becoming more and more reluctant to support the FLN's bloody actions.<br>
	==> The FLN loses the Trait 'Popular support'";
*/
$saspertesoutienpop="SAS提供的医保与社会支持表示了法国存在的好处，这使得阿尔及利亚人开始摇摆，当地居民越来越不愿意支持FLN的血腥行动.<br>
	==> FLN失去民众支持特性'";	

/* Original: 
$sasperterurale="Our soldiers and civil servants are winning the hearts and minds of the local populations by protecting them from the FLN rebels. The villagers are no longer coerced into helping the terrorists and the Algerian countryside is no longer a safe haven for those murderers.<br>
	==> The FLN loses the Trait 'Rural'";
*/
$sasperterurale="我们的士兵与公务员通过保护他们不受FLN叛军的攻击，正在赢得偏远地区本地人的信任，阿尔及利亚农村不再是那些凶手的避风港.<br>
	==> FLN失去偏远特性";

/* Original:
$sasrenseignement="The trust we are building with the population leads people to talk without fear of reprisals: the intelligence gathered through these conversations allowed us to neutralise a significant number of terrorists.<br>
==> FLN strength -1";
*/
$sasrenseignement="我们建立的谈话系统让本地人开始更自由的发布观点：情报与绥靖导致了我们可以消灭或招安一群恐怖分子.<br>
==> FLN力量 -1";

/* Original: 
$sasstabilite="<br>The SAS are now implemented over the majoritity of the Algerian territory and their work begins to bear spectacular fruits.<br>
==> Stability +1
";
*/ 
$sasstabilite="<br>SAS逐渐占领了阿尔及利亚全境，现在有利可图的结果开始产生了.<br>
==> 稳定度+1
";

// Original: $sasras="<br>This little seed sown in the Algerian countryside will need time and lots of effort to develop and eventually bear its fruits.";
$sasras="<br>这些撒在阿尔及利亚农村的小的种子需要时间和大量的努力才能开花结果.";

// Original: $sastextedebase="A new Section Administrative Spécialisée (SAS) has been implemented in a fortified farm: this structure will help the local populations in accessing education, healthcare and advice from our agronomist.<br> Protected by valiant Moghaznis, it will be an important asset in fighting the terrorists.<br>";
$sastextedebase=一个新的项目被实施了：要塞农场，这可以帮助区域内的人活动医保教育和农学建议.<br> 由于被辅助军团保护，这个设施可以自我抵御恐怖分子<br>";

$telexsas="发展SAS (+1)";

$nomsas="特殊管理部门（SAS）";

$contingent="派遣特遣队";

$txtcontingentalgerie="派遣特遣队";

/* Original: 
$contingentalgeriedetail="Called up, kept in the ranks, recalled, the State is having it both ways to send the young Frenchmen to Algeria.<br>
They will help holding the ground while the paratroopers will hunt down terrorists.<br>
Armed forces + ";
*/ 
$contingentalgeriedetail="一个招兵计划，法国正在全面计划将老兵和年轻人派往阿尔及利亚.<br>
当伞兵追逐恐怖分子的时候，他们将会帮助我们防守阵线.<br>
武装力量 + ";

/* Original: 
$oppositioncontingent="<br><br>These departures for Algeria however generate a growing resistance. Many conscripts are refusing to embark for what appears to be a dirty colonial war. They must often be coerced by force or judicial proceedings into obeying.<br>
==> Prestige -5";
*/
$oppositioncontingent="<br><br>然而，这些新兵拒绝为了一场不人道的殖民地战争而战，法国内部的反战运动需要通过法律程序和强制征招来解决.<br>
==> 荣誉 -5";

/* Original: 
$economiecontingent="<br><br>The Ministry of Labour is getting worried over the departure of many specialised workers for Algeria. Their absence will undoubtedly weigh upon the French economy.<br>
==> Reconstruction -3%";
*/
$economiecontingent="<br><br>劳工部长为阿尔及利亚的优秀劳工的离开感到担忧，这些人的失去会让法国经济受到打击.<br>
==> 重建进度 -3%";

$numberofsas="活动的SAS:";

//MGS SOVIET

$infiltrationreussiekrokodile="Ocelot Unit is at work!<br>
All actions are more efficient.";

$actionparamedicurss="Thanks to his medical knowledge, Ocelot managed to treat his injuries on his own!<br>
Although still unwell, he is operational once again.";

$agentparamedicurss="Battlefield medicine";

$ocelotblesse="<br>Agent Ocelot sustained numerous injuries and his state of health is preoccupying: he will not be able to be deployed in operation anytime soon..";
$ocelotcapture="<br>Even worse: agent Ocelot has been captured by the enemy!";
$infiltrationreussieocelotdiminueforce="Ocelot inflicts casualties in the enemy ranks! <br>(Guerrilla -1)";
$infiltrationreussieocelotboss="Ocelot's mission scored a few points against the enemy organisation: one of their prominent henchmen has been eliminated.
<br>(A boss has been liquidated)
";
$infiltrationreussieocelotmaffieux="Ocelot managed to disorganise the traffickings supplying this organisation.
<br>(Loss of the trait Mafia)
";

$infiltrationreussieocelotarmeslourdes="Ocelot destroyed the enemy heavy weapons: this is a great success!
<br>(Loss of the trait Heavy Weapons)
";

$infiltrationreussieocelotsanctuaire="Ocelot blew up the enemy secret base!<br>
Deprived of its lair, the enemy room for manoeuvre will be dramatically reduced.<br>(Loss of the trait Sanctuary)<br>";



$infiltrationreussieocelotleadercharismatique="Ocelot killed the charismatic enemy leader, dealing a severe blow to this organisation. <br>(Loss of the trait Charismatic Leader)";

$infiltrationocelotratee="Ocelot's mission went wrong...<br>
He was expected! <br> Would there be a traitor in our organisation?";



$agentocelot="Revolver Ocelot";


//1986

$txtechecraidstingers="中情局向圣战者提供的毒刺飞弹造成了严重的打击.<br>
直升机突袭已经不再是一个好办法了，每天都有大量的直升机被打下来，看来是中了他们的计策..
<br荣誉 -10
<br>(Nda: 图上的导弹不是毒刺而是SA-7)";

$nousquittonsafghanistan="我们决定撤军了，我们不能再派兵";
$noushesitonsafghanistan="政治局决定撤离阿富汗：我们在那里的影响力早已江河日下.";


// 1990

$batirecoalition="组建联合国军";
$batirecoalitiontexte="我们正在组建一支联合国军来正当化我们的军事行为. <br>
耐心点，我们很快就可以出击，在此之前一定要训练部队以防护萨达姆的生化毒气.";



?>