﻿<?php


$afghanistan="阿富汗";
$afriquedusud="南非";
$albanie="阿尔巴尼亚";
$algerie="阿尔及利亚";
$angola="安哥拉";
$arabie="沙特阿拉伯";
$argentine='阿根廷';
$australie="澳大利亚";
$autriche='奥地利';
$azi='南阿塞拜疆';
$bahamas='巴哈马群岛';
$bangladesh="孟加拉国";
$belgique='比利时';
$belize='伯利兹';
$benin="贝宁";
$birmanie="缅甸";
$bolivie='玻利维亚';
$botswana="博兹瓦纳";
//Original: $bouthan="Buthan";
$bouthan="不丹";
$bresil='巴西';
$brunei='文莱';
$bulgarie="保加利亚";
$burkinafaso='布基纳法索';
$burundi="布隆迪";
$cambodge="柬埔寨";
// Original:$cameroun="Camerun";
$cameroun="喀麦隆";
$canada="加拿大";
$centrafrique="中非共和国";
$ceylan="斯里兰卡";
$chili='智利';
$chine="中国";
$chypre='塞浦路斯';
$colombie='哥伦比亚';
$congo="刚果（布）";
$coree="高丽";
$coreenord="朝鲜";
$coreesud="韩国";
$costarica="哥斯达黎加";
$coteivoire="科特迪瓦";
$cuba="古巴";
$danemark='丹麦';
$djibouti="吉布提";
$dominique='多米尼加共和国';
$egypte="埃及";
$equateur='厄瓜多尔';
$emiratarabesunis='阿拉伯联合酋长国';
$espagne='西班牙';
$ethiopie="埃塞俄比亚";
$finlande="芬兰";
$france='法国';
$gabon="加蓬";
$gambie="冈比亚";
$ghana="加纳";
$grece='希腊';
$guatemala='危地马拉';
$guinee="几内亚";
$guineebissau="几内亚比绍";
$guineeequatoriale="赤道几内亚";
$guyana="圭亚那";
$guyane="法属圭亚那";
$haiti='海地';
$hautevolta="上沃尔特";
$honduras='洪都拉斯';
$hongrie='匈牙利';

$inde="印度";
$indonesie="印度尼西亚";
$irak='伊拉克';
$iran="伊朗";
$italie='意大利';
$irlande="爱尔兰";
// Orginal: $islande="Island";
$islande="冰岛";
$israel="巴勒斯坦托管地";
$jamaique="牙买加";
$japon="日本";
$transjordanie="外约旦";
$jordanie="约旦";
$katanga="加丹加";
$kenya="肯尼亚";
$koweit="科威特";
$laos="老挝";
$lesotho="莱索托";

$lesusa="美利坚合众国";

//Original: $lurss="苏维埃社会主义共和国联盟";
$lurss="苏维埃社会主义共和国联盟";
$lachine="中华人民共和国";


$liban="黎巴嫩";
$liberia="利比里亚";
$libye="利比亚";
$luxembourg="卢森堡";
$madagascar="马达加斯加";
$mahabad="马哈巴德";
$malaisie="马来西亚";
$malawi="马拉维";
$mali="马里";
$mandchourie="满洲";
$maroc="摩洛哥";
$mauritanie="毛里塔尼亚";

$merc="雇佣军";


$mexique="墨西哥";
$mongolie="蒙古";
$mozambique="莫桑比克";
$namibie="纳米比亚";
$nepal="尼泊尔";
$nicaragua="尼加拉瓜";
$niger="尼日尔";
$nigeria="尼日利亚";

$norvege="挪威";
$nouvellezelande="新西兰";
$oman="阿曼";
$ouganda="乌干达";
$papouasie="巴布亚新几内亚";
$papouasieoccidentale="西巴布亚";
$pakistan="巴基斯坦";
$palestine="巴勒斯坦";
$panama="巴拿马";
$paraguay='巴拉圭';
$paysbas="尼德兰";
$perou="秘鲁";
$philippines="菲律宾";
$pologne="波兰";
$portugal="葡萄牙";
$quatar="卡塔尔";

// Original: $rda="German Democratic Republic";
$rda="民主德国";
// Original: $rfa="German Federal Republic";
$rfa="联邦德国";
$roumanie='罗马尼亚';
$royaumeuni='联合王国';
$rwanda="卢旺达";
$borneonord="沙巴砂拉越";
$salvador='萨尔瓦多';
$senegal="萨内加尔";
$sierraleone="塞拉利昂";
$somalie="索马里";
$somaliland="索马里兰";
$soudan="苏丹";
$suede="瑞典";
// Original: $suisse='Swiss Confederacy';
$suisse='瑞士';
$suriname='苏里南';
$swaziland="斯威士兰";
$syrie='叙利亚';
$taiwan="台湾";
$tanzanie="坦桑尼亚";
$tchad="乍得";
$tchecoslovaquie="捷克斯洛伐克";
$thailande="泰国";
$tibet="西藏";
$togo="多哥";
$tunisie="突尼斯";
$turquie="土耳其";
$uruguay='乌拉圭';
$venezuela='委内瑞拉';
$vietnam="越南";
$vietnamnord="北越";
$vietnamsud="南越";

$volnc="朝鲜志愿军";

$yemen='南也门';
$yemennord='北也门';
$yougoslavie="南斯拉夫";
$zaire="刚果（利）";
$zambie="北罗得西亚";
$zimbabwe="南罗得西亚";


// AJOUT 1950

$volchinois="中国志愿军";
$saharaoccidental="西撒哈拉";
// Original: $onu="UNO";

$onu="UN";
// MAJ 1953-1956

$francelibre="自由法国";

$troupescoloniales="殖民地步兵";

// Original: $kreta="Kreta";


$kreta="克里特";
//ex urss

$estonie="爱沙尼亚";
$lituanie="立陶宛";
//Original: $lettonie="Lettonia";
$lettonie="拉脱维亚";
//Original: $bielorussie="Bielorussia";
$bielorussie="白俄罗斯";
$ukraine="乌克兰";
//Original: $moldavie="摩尔达维亚";
$moldavie="摩尔多瓦";
$georgie="格鲁吉亚";
$armenie="亚美尼亚";
$azerbaidjan="阿塞拜疆";
$kazakstan="哈萨克斯坦";
//Original: $ouzbekistan="Ouzbekistan";
$ouzbekistan="乌兹别克斯坦";
$turkmenistan="土库曼斯坦";
$tadjikistan="塔吉克斯坦";
//Original: $kirghizistan="Kirghizistan";
$kirghizistan="吉尔吉斯斯坦";

// ex yougoslavie

$slovenie="斯洛文尼亚";
$croatie="克罗地亚";
$bosnie="波斯尼亚";
$montenegro="黑山";
$kossovo="科索沃";
$serbie="塞尔维亚";
$macedonia="马其顿";

?>