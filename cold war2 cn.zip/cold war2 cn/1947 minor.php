﻿<?php


$annee47evt1="巴拉圭：内战！";

$annee47evt2="中国：美国切断对国民党的援助";
$annee47evt2b="中国：美国加大对国民党的援助！";
$annee47evt2bdetail="美国每月对华援助预算增长到10$";

$annee47evt3detail="美国每月预算增加25$";
$annee47evt3="美国：杜鲁门将以武力驱逐共产主义！";

$annee47evt3bdetail="美国在经济援助时获得加成";
$annee47evt3b="美国：杜鲁门诠释遏制主义";

$annee47evt4="缅甸：独立";

$annee47evt5="美国：欧洲复苏计划（马歇尔计划）";

$annee47evt6detail="美国与这个国家签订经济协定";
$annee47evt6="这个国家接受马歇尔计划";

$annee47evt7="美国：建立中央情报局（CIA）";
$annee47evt7detail="不幸的是，这不会给美国玩家任何加成";

$annee47evt8="美国：一个不明飞行物在新墨西哥州坠毁";
$annee47evt8detail="真相在别处……";

$annee47evt9="印度：独立！";
$annee47evt9detail="你现在可以和这个国家签订协议了";

$annee47evt10="印巴战争";
$annee47evt10detail="一个新国家出现在游戏中：巴基斯坦";

$annee47evt11="印巴边境两侧的屠杀和流亡";
$annee47evt11detail="印巴两国的稳定度下降";

$annee47evt12="苏联：日丹诺夫提出世界已分裂为两大不可调和阵营的理论";
$annee47evt12detail="苏联在结盟行动中获得额外加成";

$annee47evt13="苏联：对西方善意姿态和征兆的涌现";
$annee47evt13detail="战备等级降低";

$annee47evt14="泰国：政变";
$annee47evt14detail="该国转变为独裁政体，稳定度增长，与美国的关系改善。与其他国家关系恶化";

$annee47evt15="巴勒斯坦：英军无力遏制频发的多起暴力事件";
$annee47evt16="巴勒斯坦：阿拉伯志愿者涌入";
$annee47evt16detail="一支新的阿拉伯游击队出现在巴勒斯坦";

$annee47evt17="签署关贸总协定（美国荣誉+25）";
$annee47evt17detail="自由主义经济体制壮大";

$annee47evt18="肯尼亚：总罢工";
$annee47evt18detail="稳定度下降";

$annee47evt19="马达加斯加：民众起义";
$annee47evt19detail="稳定度下降，出现一支游击队";
$madagascar47="马达加斯加叛军";

$annee47evt20="坦桑尼亚：达累斯萨拉姆码头工人罢工";
$annee47evt21="尼日尔：铁路工人罢工";

$annee47evt22="智利：共产党人被驱逐出政府。总统指责他们制造事端";
$annee47evt22detail="智利与苏联的关系恶化，稳定度下降";

$annee47evt23="巴西：禁止共产党";
$annee47evt23detail="恶化与苏联的关系，共产主义反对派消失了";
$annee47evt24="厄瓜多尔：政变";
$annee47evt24detail="稳定度下降，该国转变为独裁政体，与美国和苏联的关系恶化";

$annee47evt25="印度支那：越盟尝试谈判";
$annee47evt25detail="游击队获得谈判特质";

$annee47evt26="美国：爆发通货膨胀！";
$annee47evt26detail="急剧增长社会抗议";

$annee47evt27="美国：国会实现全面复员（终于！）";
$annee47evt27detail="美国转入和平预算 (-$25)";

// EVT FRANCE

$annee47evt28="法国：第一个五年设备现代化计划";
$annee47evt28detail="法国重建进度+1";

$annee47evt29="法国：罢工蔓延！(-$5)";
$annee47evt29detail="-$5";

$annee47evt30="法国：罢工蔓延！ (-$10)";
$annee47evt30detail="PCF的高影响力会更严重地打击你的预算: -$10";

$annee47evt31="法国：总工会CGT分裂";
$annee47evt31detail="法共影响力-2";

$annee47evt32="法国：樊尚·奥里奥尔当选第四共和国第一任总统";
$annee47evt32detail="这并没有改变什么，共和国总统在第四共和国中几乎没有权力";

$annee47evt33="法国：保罗·拉马迪尔组阁";
$annee47evt33detail="你的新领袖：请注意，只要你有三党政府特质，你的领袖在核对峙中就不会高效";

$annee47evt34="越南：和好教战士决定为法国服务";
$annee47evt34detail="你得到一个新的盟友，他们是一群不可靠的狂热分子";

$annee47evt35="法国：严冬与煤炭进口激增(-$5)";
$annee47evt35detail="一月的巴黎气温是-14摄氏度！";

$annee47evt36="法国：严冬与煤炭进口激增(-$10)";
$annee47evt36detail="为什么我们不从德国那拿更多煤呢？";

?>