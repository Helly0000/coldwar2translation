﻿<?php


$annee45evt1='中共进入东北';
$annee45evt1title='满洲消失，共产党游击队得到加强（+10）';
$annee45evt2='委内瑞拉民主政变';
$annee45evt2title='稳定度上升，政体更迭为民主政府，与苏联关系改善，与美国关系恶化';
$annee45evt2b='委内瑞拉民主政变失败';
$annee45evt2btitle='稳定度上升';

$annee45evt3='巴西：政府被推翻';
$annee45evt3title='稳定度下降';

$annee45evt4="匈牙利大选：共产党在政府中占据多数";
$annee45evt4title="提升与苏联的关系";

$annee45evt5="保加利亚大选：共产党获得75%的选票";
$annee45evt5title="提升与苏联的关系";

$annee45evt6="纽伦堡审判：纳粹分子因其反人类罪受审";
$annee45evt6title="平庸之恶";

$annee45evt7="捷克斯洛伐克：贝纳斯法令";
$annee45evt7title="稳定度上升";

$annee45evt8="伊朗-伊拉克：库尔德起义";
$annee45evt8title="一支新的游击队出现在这两个国家！";

$annee45evt9="印度尼西亚：英印泗水之战";
$annee45evt9detail="游击战争重启";

$annee45evt10="世界银行和国际货币基金组织创立（美国荣誉 +25）";
$annee45evt10detail="自由经济体系已经落实到位";





?>