﻿<?php

$annee75evt1="西撒哈拉：35万摩洛哥人绿色进军";
$annee75evt1detail="西撒哈拉变成摩洛哥领土，摩洛哥稳定度急剧增长";

$annee75evt2="马达加斯加民主共和国宣告成立";
$annee75evt2detail="马达加斯加希望加入非洲社会主义阵营，该国政体转变为人民民主制，并改善与苏联的关系";

$annee75evt3="安哥拉：内战重燃";
$annee75evt3detail="这场战争可能会持续很久";

$annee75evt4="安哥拉：南非军队介入";
$annee75evt4detail="祖鲁行动";

$annee75evt5="安哥拉：安哥拉人民共和国宣告独立";
$annee75evt5detail="该国可能成为非洲的火药桶";

$annee75evt6="安哥拉：古巴军队前往该国战斗";
$annee75evt6detail="2古巴军队抵达安哥拉";

$annee75evt7="洪都拉斯：金融丑闻";
$annee75evt7detail="稳定度下降";

$annee75evt8="印度：政局动荡";
$annee75evt8detail="稳定度下降";

$annee75evt9="澳大利亚：宪法危机";
$annee75evt9detail="稳定度下降";

$annee75evt10="印度尼西亚：该国以武力回应东帝汶独立运动";
$annee75evt10detail="帝汶游击队隐匿起来";

$annee75evt11="两伊边界划定协议";
$annee75evt11detail="库尔德游击队开始谈判，伊拉克和伊朗的稳定度上升";

$annee75evt12="黎巴嫩：基督教民兵和巴勒斯坦人间的血腥冲突";
$annee75evt12detail="稳定度下降";

$annee75evt13="黎巴嫩火药桶爆炸";
$annee75evt13detail="内战正如火如荼";

$annee75evt14="西班牙：极左翼组织袭击警察官员";
$annee75evt14detail="一支马列主义恐怖组织开始武装斗争";

$annee75evt15="中国：现任领导人逝世，毛主席掌握党的领导权";
$annee75evt15detail="我们敬爱的舵手回归";
$maozedong="毛泽东";

$annee75evt16="埃塞俄比亚：提格雷人民解放阵线创立";
$annee75evt16detail="一支新游击队出现";

$annee75evt17="台湾：立法选举";
$annee75evt17detail="台湾政体转变为代议共和制;














?>