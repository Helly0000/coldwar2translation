﻿<?php



$_SESSION['janvier']="一月";
$_SESSION['février']="二月";
$_SESSION['mars']="三月";
$_SESSION['avril']="四月";
$_SESSION['mai']="五月";
$_SESSION['juin']="六月";
$_SESSION['juillet']="七月";
$_SESSION['août']="八月";
$_SESSION['septembre']="九月";
$_SESSION['octobre']="十月";
$_SESSION['novembre']="十一月";
$_SESSION['décembre']="十二月";



$nomAdjectifusa="美国";
$nomAdjectifurss="苏联";
$nomAdjectifchine="中国";

$lesusa="美利坚合众国";
$lurss="苏维埃社会主义共和国联盟";
$lachine="中华人民共和国";

$nomusa="美国";
$nomurss="苏联";

$staline="约瑟夫·斯大林";
$truman="哈里·杜鲁门";
$mao="毛泽东";


// maj 1953

$youwin="胜利 !";
$youlose="你输了";
$prestigeusa="美国荣誉分数:";
$prestigeurss="苏联荣誉分数:";
$scoredebase="基本分数 (你的分数-你的对手的 ) : ";
$malusdifficultefacile="简单难度罚分 : ";
$bonusdifficulte="困难难度奖分 : ";
$bonusdifficultehardcore="硬核难度奖分 : ";
$bonusdifficultegulag="古拉格难度奖分 : ";
$scorefinal="最终分数 : ";
$bienvenuehalloffame="进入高分榜";
$typeyourpseudo="你的名字 ";
$sauvegarder="保存分数";

// MAJ CHINE

$prestigechine="中国分数: ";

// 1963

$mortsubitevietnam="<strong>西贡的陷落!</strong><br>北越军队包围着这座城市，美国和他的盟友们惊慌失措的逃离了.<br>"
;

// FRANCE 

$lafrance="法国";
$prestigefrance="法国名誉:";

$mortsubiteindochine="印度支那落入了共产党手里!";

$putchalgerie="军队夺取了政权 : 法兰西不再是共和国了... <br>你输了.";
$mortsubitealgerie="阿尔及利亚陷落 !";
?>