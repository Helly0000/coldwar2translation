﻿<?php

$annee59evt1="古巴：政府在总统富尔亨西奥·巴蒂斯塔逃离古巴后崩溃";
$annee59evt1detail="稳定度设定为混乱，古巴军事力量减半";

$annee59evt2="古巴：土地改革";
$annee59evt2detail="稳定度上升，与美国关系恶化，该政权转变为独裁政体";

$annee59evt3="中国：西藏暴动";
$annee59evt3detail="加强的藏独游击队出现，并获得民众支持特质";

$annee59evt4="伊拉克：军事政变后，该国加入阿拉伯联合共和国";
$annee59evt4detail="伊拉克与埃及联合";

$annee59evt5="古巴：菲德尔·卡斯特罗于选举中大获全胜！";
$annee59evt5detail="稳定度显著增长";

$annee59evt6="土耳其：美国部署核弹道导弹";
$annee59evt6detail="弹道导弹从土耳其领土直接指向苏联";

$annee59evt7="刚果（利）：利奥波德维尔的血腥骚乱";
$annee59evt7detail="稳定度急剧下降";

$annee59evt8="马里：与塞内加尔建立马里联邦";
$annee59evt8detail="这个联邦有很多反对者";

$annee59evt8bis="塞内加尔独立";
$annee59evt8bisdetail="一个新国家来了！";

$annee59evt8ter="马里独立";
$annee59evt8terdetail="一个新国家来了！";

$annee59evt9="马拉维：宣布针对分离主义动乱的紧急状态";
$annee59evt9detail="稳定度下降";

$annee59evt10="南罗得西亚：宣布进入紧急状态";
$annee59evt10detail="稳定度下降";

$annee59evt11="安哥拉：解放安哥拉人民运动的激进分子被捕";
$annee59evt11detail="稳定度和军事力量下降";

$annee59evt12="几内亚比绍：血腥镇压码头工人罢工";
$annee59evt12detail="稳定度下降";

$annee59evt13="几内亚比绍：反对派拿起武器";
$annee59evt13detail="独立斗争开始！";

$annee59evt14="卢旺达：针对图西族的种族屠杀";
$annee59evt14detail="稳定度下降";

$annee59evt15="老挝：内战";
$annee59evt15detail="一支游击队出现";

$annee59evt16="越南：胡志明小道开通";
$annee59evt16detail="越共获得境外基地特质，如果巴特寮存在，其最大实力上限+2";

$annee59evt17="以色列：一个巴勒斯坦解放阵线建立";
$annee59evt17detail="一支新的游击队出现";

$annee59evt18="西班牙：埃塔诞生";
$annee59evt18detail="一支新的游击队出现";

?>