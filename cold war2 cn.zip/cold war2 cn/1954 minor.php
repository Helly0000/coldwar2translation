﻿<?php

$annee54evt1="苏联：处女地运动";
$annee54evt1detail="苏维埃人开始耕种那些交通不便和贫瘠的土地";

$annee54evt2="苏联：建立国安委（KGB）";
$annee54evt2detail="无效果 ^^， 苏联特勤部门已经很高效了";

$annee54evt3="危地马拉：土地改革";
$annee54evt3detail="与苏联关系改善，与美国关系恶化";

$annee54evt4="美国：杜勒斯主义";
$annee54evt4detail="美国在其政变行动中获得额外加成";

$annee54evt5="美国：麦卡锡退休……";
$annee54evt5detail="结束麦卡锡主义事件";

$annee54evt6="摩洛哥：要求苏丹回归的骚乱";
$annee54evt6detail="稳定度下降";

$annee54evt7="阿尔及利亚：武装斗争争取独立";
$annee54evt7detail="一支游击队出现在阿尔及利亚";

$annee54evt8="埃及：政府和穆斯林兄弟会之间的血腥对抗";
$annee54evt8detail="稳定度下降";

$annee54evt9="埃及：大罢工和反民主抗议";
$annee54evt9detail="稳定度下降";

$annee54evt10="叙利亚：暴力抗议反对政权";
$annee54evt10detail="稳定度下降";

$annee54evt11="埃及：穆斯林兄弟会流亡沙特阿拉伯";
$annee54evt11detail="稳定度上升";

$annee54evt12="印度支那：法军狼狈逃离奠边府包围圈";
$annee54evt12detail="这场战争远未结束！";

$annee54evt13="台湾海峡：解放军炮击马祖诸岛（-5$）";
$annee54evt13detail="无缘无故";

$annee54evt14="法国：皮埃尔·孟戴斯-弗朗斯组建新政府";
$annee54evt14detail="这一个会持续多久？";

$annee54evt15="印度支那：奠边府岿然不动！（法国荣誉+25） ";
$annee54evt15detail="多么英勇！";






















?>