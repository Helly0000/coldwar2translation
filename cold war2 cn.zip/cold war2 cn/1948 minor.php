﻿<?php


$annee48evt1="哥斯达黎加：选举结果作废";
$annee48evt1detail="稳定度下降";

$annee48evt2="朝鲜民主主义人民共和国宣告成立";
$annee48evt2detail="这个国家现在是人民共和国";

$annee48evt3="北朝鲜：结束苏联军事管制";
$annee48evt3detail="苏军撤离";

$annee48evt4="哥斯达黎加：内战！";
$annee48evt4detail="一支游击队出现在这个国家";

$annee48evt5="缅甸：独立";
$annee48evt5detail="缅甸独立";

$annee48evt6="缅甸：内战！";
$annee48evt6detail="数支游击队出现在这个国家";

$annee48evt7="哥伦比亚：暴力！";
$annee48evt7detail="一场残酷的内战开始了";

$annee48evt8="以色列国宣告成立";
$annee48evt8detail="一个犹太国家建立，并与其阿拉伯邻国开战";

$annee48evt9="以阿战争";
$annee48evt9detail="一个犹太国家建立，并与其阿拉伯邻国开战";

$annee48evt10="以色列获得重武器";
$annee48evt10detail="军事力量+3";

$annee48evt11="铁托与斯大林的分裂";
$annee48evt11detail="恶化南斯拉夫与苏联关系(-2等级)";

$annee48evt12="越南：保大皇帝回归";
$annee48evt12detail="无效果";

$annee48evt13="越南：临时政府成立";
$annee48evt13detail="新国旗和共和国";

$annee48evt14="大韩民国宣告成立";
$annee48evt14detail="这个国家现在是共和国";

$annee48evt15="南韩：结束美国军事管制";
$annee48evt15detail="美军撤离";

$annee48evt16="菲律宾：胡克军战士重新开始游击战";
$annee48evt16detail="胡克军游击队再次出现";

$annee48evt17="中国：人民解放军收复延安";
$annee48evt17detail="人民解放军重获秘密根据地特质，中国稳定度下降";

$annee48evt18="中国：苏联大规模援助中共";
$annee48evt18detail="游击队获得重武器特质";

$annee48evt19="马来西亚：共产党起义";
$annee48evt19detail="一支新的游击队出现在这个国家";

$annee48evt20="以色列：第三帝国大规模援助阿拉伯军队";
$annee48evt20detail="叙利亚和埃及军力增强";

$israel="以色列";

$annee48evt21="法国：罢工蔓延！(-$10)";
$annee48evt21detail="PCF的高影响力会更严重地打击你的预算: -$10";

$annee48evt22="法国：仍有相当数量的罢工者罢工(-$5)";
$annee48evt22detail="幸运的是，PCF的影响力并不处于最高点！";

$annee48evt23="法国：马里政府开始";
$annee48evt23detail="政府更迭，一切照旧！";

$annee48evt24="法国：罢工浪潮 (预算-5$)";
$annee48evt24detail="这个季节正适合搞这个";

$annee48evt25="法国：政府华尔兹";
$annee48evt25detail="第四共和国似乎相当不稳";

$annee48evt26="法国：比道尔特政府";
$annee48evt26detail="这个似乎能比上一个更持久……";

?>